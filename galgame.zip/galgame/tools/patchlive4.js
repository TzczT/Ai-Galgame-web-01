const fs=require('fs');
const P='D:\\3333\\7117\\galgame\\tools\\live.js';
let s=fs.readFileSync(P,'utf8');
// 用 evaluate 直接点击按钮（避开坐标换算问题）
const a=s.indexOf("  const tb = JSON.parse");
const b=s.indexOf("await sleep(600);", a);
if(a>0 && b>a){
  const rep=[
"  await ex('(function(){var b=document.querySelector(\".t-btn.primary\");if(b)b.click();return 1;})()');",
"  await sleep(700);"
].join("\n");
  s=s.slice(0,a)+rep+s.slice(b);
}
// 姓名确定按钮也改为 evaluate 点击
const a2=s.indexOf("const box = await ex(");
const b2=s.indexOf("await sleep(800);", a2);
if(a2>0 && b2>a2){
  s=s.slice(0,a2)+"    await ex('(function(){var o=document.getElementById(\"name-ok\");if(o)o.click();return 1;})()');\n    "+s.slice(b2);
}
fs.writeFileSync(P,s,'utf8');
console.log('ok',s.indexOf("t-btn.primary\").click")>0 || s.indexOf(".t-btn.primary\\\").click")>0, s.indexOf('name-ok')>0);

const fs=require('fs');
const R='D:\\3333\\7117\\galgame\\src\\';
const s=[R+'script0.js',R+'script1.js',R+'script2.js'].map(f=>fs.readFileSync(f,'utf8')).join('\n');
// 粗略把每个对象节点按 '{ ' 行计数，模拟引擎的节点序列
const lines=s.split('\n');
let idx=0, out=[];
lines.forEach((l,i)=>{
  const t=l.trim();
  if(t.startsWith('{') && t.endsWith('},' ) || t.startsWith('{') && t.endsWith('}')) { out.push([idx, (i+1), t.slice(0,70)]); idx++; }
  else if(t.startsWith('{')) { out.push([idx, (i+1), t.slice(0,70)]); idx++; }
});
console.log('total approx nodes', idx);
[48,49,50,51,205,206,366,367,368].forEach(k=>{const o=out[k]; console.log(k, o? o[2] : 'N/A', '| line', o?o[1]:'');});

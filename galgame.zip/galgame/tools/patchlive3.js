const fs=require('fs');
const P='D:\\3333\\7117\\galgame\\tools\\live.js';
let s=fs.readFileSync(P,'utf8');
const oldA="  await c.send('Input.dispatchMouseEvent', { type: 'mousePressed', x: 200, y: 288, button: 'left', clickCount: 1 });";
if(s.indexOf('const tb =')<0){
  const idx=s.indexOf(oldA);
  if(idx<0){console.log('MISS A');process.exit(1);}
  const end=s.indexOf("clickCount: 1 });", idx)+"clickCount: 1 });".length;
  const block=s.slice(idx,end);
  const rep=[
"  const tb = JSON.parse(await ex('JSON.stringify((document.querySelector(\".t-btn.primary\")||{getBoundingClientRect:function(){return {x:-99,y:-99,width:0,height:0}}}).getBoundingClientRect())'));",
"  if (tb.width > 0) {",
"    const tx = Math.round(tb.x + tb.width / 2), ty = Math.round(tb.y + tb.height / 2);",
"    await c.send('Input.dispatchMouseEvent', { type: 'mousePressed', x: tx, y: ty, button: 'left', clickCount: 1 });",
"    await c.send('Input.dispatchMouseEvent', { type: 'mouseReleased', x: tx, y: ty, button: 'left', clickCount: 1 });",
"  }"
  ].join('\n');
  s=s.slice(0,idx)+rep+s.slice(end);
}
s=s.replace("if (st.idx === lastIdx && !st.cc) repeat++; else repeat = 0;",
            "if (st.idx === lastIdx && !st.cc && !st.cl && !st.end && st.txt) repeat++; else repeat = 0;");
fs.writeFileSync(P,s,'utf8');
console.log('ok', s.indexOf('const tb =')>0);

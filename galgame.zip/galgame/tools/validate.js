const fs=require('fs'),path=require('path'),vm=require('vm');
const ROOT=path.resolve(__dirname,'..');
const sandbox={console,window:{},document:{},location:{search:''},localStorage:{getItem(){return null},setItem(){}}};
sandbox.window=sandbox; sandbox.globalThis=sandbox;
vm.createContext(sandbox);
['svg.js','art.js'].forEach(f=>vm.runInContext(fs.readFileSync(path.join(ROOT,'src',f),'utf8'),sandbox,{filename:f}));
['script0.js','script1.js','script2.js'].forEach(f=>vm.runInContext(fs.readFileSync(path.join(ROOT,'src',f),'utf8'),sandbox,{filename:f}));
const S=[].concat(sandbox.SCRIPT_0,sandbox.SCRIPT_1,sandbox.SCRIPT_2);
const labels=new Set(); S.forEach(n=>{if(n&&n.label)labels.add(n.label)});
const problems=[];
S.forEach((n,i)=>{
  if(!n||typeof n==='string'){if(typeof n==='string')problems.push(i+': 裸字符串节点');return;}
  if(n.t==='jump'&&!labels.has(n.label))problems.push(i+': jump -> 未定义标签 '+n.label);
  if(n.t==='if'){if(n.then&&!labels.has(n.then))problems.push(i+': if->then 未定义 '+n.then);if(n.else&&!labels.has(n.else))problems.push(i+': if->else 未定义 '+n.else);}
  if(n.t==='choice')n.options.forEach((o,k)=>{if(!labels.has(o.goto))problems.push(i+': choice['+k+'] -> 未定义标签 '+o.goto)});
  if(n.text===undefined&&n.s===undefined&&!n.t)problems.push(i+': 节点无类型');
});
let chars=0; S.forEach(n=>{if(n&&n.text)chars+=String(n.text).replace(/\{name\}/g,'江知远').length;});
const stat={nodes:S.length,labels:labels.size,textChars:chars,bgCmds:S.filter(n=>n&&n.t==='bg').length,
  cgs:[...new Set(S.filter(n=>n&&n.t==='cg').map(n=>n.name))],
  musics:[...new Set(S.filter(n=>n&&n.t==='music').map(n=>n.name))],
  choices:S.filter(n=>n&&n.t==='choice').length,
  endings:S.filter(n=>n&&n.t==='ending').map(n=>n.kind)};
// 校验美术键
const keys=new Set(Object.keys(sandbox.ARTWORK.SCENES));
const artMissing=[];
S.forEach(n=>{
  if(!n)return;
  if(n.t==='bg'&&!keys.has(n.name))artMissing.push('bg '+n.name);
  if(n.t==='cg'&&!sandbox.ARTWORK.get&&false){}
});
console.log(JSON.stringify({stat,problems:problems.slice(0,20),problemCount:problems.length,artMissing},null,1));

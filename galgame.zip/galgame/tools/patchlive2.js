const fs=require('fs');
const P='D:\\3333\\7117\\galgame\\tools\\live.js';
let s=fs.readFileSync(P,'utf8');
s=s.replace("if (stuck) out.push(stuck);","if (stuck) { out.push(stuck); out.push('T=' + await ex('document.body.getAttribute(\"data-t\")')); out.push('J=' + await ex('document.body.getAttribute(\"data-j\")')); out.push('NODE=' + await ex('JSON.stringify(window.__S&&window.__S[Game.state.idx])')); }");
s=s.replace("await sleep(2500);","await sleep(3000);");
fs.writeFileSync(P,s,'utf8');console.log('patched');

const fs=require('fs');
const P='D:\\3333\\7117\\galgame\\tools\\live.js';
let s=fs.readFileSync(P,'utf8');
if(s.indexOf('data-ct')<0){
  s=s.replace("out.push('T=' + await ex('document.body.getAttribute(\"data-t\")'));",
    "out.push('T=' + await ex('document.body.getAttribute(\"data-t\")'));\n        out.push('CT=' + await ex('document.body.getAttribute(\"data-ct\")'));");
}
fs.writeFileSync(P,s,'utf8');console.log('ok');

const fs=require('fs');
const R='D:\\3333\\7117\\galgame\\src\\';
const files=['script0.js','script1.js','script2.js'];
const seen=new Set(); const removed=[];
files.forEach(function(f){
  const p=R+f;
  const lines=fs.readFileSync(p,'utf8').split('\n');
  const out=[];
  lines.forEach(function(line,i){
    const m=/^\s*\{\s*t:\s*'label'\s*,\s*label:\s*'([a-zA-Z0-9_]+)'\s*\}\s*,?\s*$/.exec(line);
    if(m){
      if(seen.has(m[1])){ removed.push(f+':'+(i+1)+' '+m[1]); return; }
      seen.add(m[1]);
    }
    out.push(line);
  });
  fs.writeFileSync(p,out.join('\n'),'utf8');
});
console.log('removed duplicate label DEFINITIONS: '+(removed.join(', ')||'none'));

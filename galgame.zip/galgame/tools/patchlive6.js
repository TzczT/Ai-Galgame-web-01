const fs=require('fs');
const P='D:\\3333\\7117\\galgame\\tools\\live.js';
let s=fs.readFileSync(P,'utf8');
if(s.indexOf('__RUNERR')<0){
  s=s.replace("out.push('errors=' + await ex('JSON.stringify((window.__bootErr||\"\")+\"\")'));",
    "out.push('errors=' + await ex('JSON.stringify(window.__bootErr||\"\")'));\n  out.push('runErr=' + await ex('String(window.__RUNERR||\"none\").slice(0,400)'));");
}
fs.writeFileSync(P,s,'utf8');console.log('ok');

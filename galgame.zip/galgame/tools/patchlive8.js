const fs=require('fs');
const P='D:\\3333\\7117\\galgame\\tools\\live.js';
let s=fs.readFileSync(P,'utf8');
if(s.indexOf('data-tr')<0){
  s=s.replace("out.push('CT=' + await ex('document.body.getAttribute(\"data-ct\")'));",
   "out.push('CT=' + await ex('document.body.getAttribute(\"data-ct\")'));\n        out.push('TR=' + await ex('document.body.getAttribute(\"data-tr\")'));");
}
fs.writeFileSync(P,s,'utf8');console.log('ok');

const fs=require('fs');
const ROOT='D:\\3333\\7117\\galgame\\';
let h=fs.readFileSync(ROOT+'preview\\_http.html','utf8');
// 在最末尾追加一个同步标记脚本，验证注入脚本是否真的执行
h=h.replace('</body>','<'+'script>document.body.setAttribute("data-probe-ran","YES");</'+'script></body>');
fs.writeFileSync(ROOT+'preview\\_http2.html',h,'utf8');
console.log('ok');

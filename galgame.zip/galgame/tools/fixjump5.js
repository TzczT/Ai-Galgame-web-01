const fs=require('fs');
const R='D:\\3333\\7117\\galgame\\src\\';
let s=fs.readFileSync(R+'script1.js','utf8');
s=s.replace(/target: 'ch3'/g,"target: 'ch3_body'");
fs.writeFileSync(R+'script1.js',s,'utf8');
console.log('fixed script1 ch3 jump');

const fs=require('fs');
const s=fs.readFileSync('D:\\3333\\7117\\galgame\\tools\\mkicon.js','utf8');
const cut=s.indexOf('// PNG');
const head=s.slice(0,cut);
// 在纯 head 末尾插入探针
const probe=head + "\nfunction P(x,y){const i=(y*S+x)*4;return [buf[i],buf[i+1],buf[i+2],buf[i+3]];}\nconsole.log('probe', P(256,300).join(','), P(180,315).join(','), P(256,382).join(','));\n";
fs.writeFileSync('D:\\3333\\7117\\galgame\\tools\\probe.js', probe, 'utf8');
console.log('probe len', probe.length, 'hasBodyCall', probe.indexOf('roundRect(256,300')>0);

const fs=require('fs');
const ROOT='D:\\3333\\7117\\galgame\\';
const dist=fs.readFileSync(ROOT+'dist/index.html','utf8');
const scripts=dist.slice(dist.indexOf('<script>'), dist.lastIndexOf('</script>')+9);
const scenes=['lib','studio','road','canteen','field','lake','roof','hall','classroom','archive','dorm','balcony','snowRoad','repair','libSeat','title'];
const cgs=['seat','rec','food','snow','autumn','autumn2'];
const sprites=['calm','serious','smile','troubled','solemn'];
const css='body{margin:0;background:#241f1b;color:#f2e8d5;font-family:"Noto Serif SC",serif}'+
'.wrap{padding:24px 28px}h2{font-weight:400;letter-spacing:.2em;color:#e0b84c;border-bottom:1px solid #5a4b32;padding-bottom:8px;margin:36px 0 16px}'+
'.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(330px,1fr));gap:14px}'+
'.cell{background:#2e2721;border:1px solid #55483a;border-radius:6px;overflow:hidden}'+
'.cell .art{aspect-ratio:16/9;overflow:hidden}.cell .art>svg{width:100%;height:100%;display:block}'+
'.cell .sp{aspect-ratio:620/1130;display:flex;justify-content:center;overflow:hidden;background:#e9dfc8}'+
'.cell .sp>svg{height:100%;width:auto;display:block}'+
'.cap{padding:7px 10px;font-size:13px;letter-spacing:.1em;color:#d9cba8}';
const html='<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8"><title>长耳听见的那一年 · 美术总览</title><style>'+css+'</style></head><body><div class="wrap">'+
'<h1 style="font-weight:400;letter-spacing:.14em">长耳听见的那一年 · 美术总览</h1>'+
'<p style="color:#b3a488">全部资源由程序化水彩 SVG 现场绘制。此页仅供开发预览。</p>'+
'<h2>场景 BACKGROUNDS</h2><div class="grid" id="g1"></div>'+
'<h2>CG</h2><div class="grid" id="g2"></div>'+
'<h2>立绘 SPRITES</h2><div class="grid" id="g3"></div>'+
'</div>'+scripts+'<script>'+
'function fill(id,keys,cls){var g=document.getElementById(id);keys.forEach(function(k){var d=document.createElement("div");d.className="cell";d.innerHTML="<div class=\\""+cls+"\\">"+ARTWORK.get(k)+"</div><div class=\\"cap\\">"+k+"</div>";g.appendChild(d);});}'+
'fill("g1",'+JSON.stringify(scenes)+',"art");'+
'fill("g2",'+JSON.stringify(cgs)+',"art");'+
'var g3=document.getElementById("g3");'+JSON.stringify(sprites)+'.forEach(function(e){var d=document.createElement("div");d.className="cell";d.innerHTML="<div class=\\"sp\\">"+ARTWORK.spriteSVG(e)+"</div><div class=\\"cap\\">"+e+"</div>";g3.appendChild(d);});'+
'<\/script></body></html>';
fs.writeFileSync(ROOT+'preview/gallery.html', html, 'utf8');
console.log('gallery written', (html.length/1024).toFixed(1)+' KB');

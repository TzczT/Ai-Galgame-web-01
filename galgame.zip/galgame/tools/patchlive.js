const fs=require('fs');
const P='D:\\3333\\7117\\galgame\\tools\\live.js';
let s=fs.readFileSync(P,'utf8');
if(s.indexOf('const FULL')<0){
  s=s.replace("const steps = parseInt(process.argv[3] || '8', 10);",
    "const steps = parseInt(process.argv[3] || '8', 10);\nconst FULL = process.argv[4] === 'full';");
}
const marker="  // 连续真实点击对话框区域";
const fullMode = [
"  if (FULL) {",
"    let n = 0, lastIdx = -1, repeat = 0, ch = 0, stuck = '';",
"    const t0 = Date.now();",
"    while (Date.now() - t0 < 420000) {",
"      const st = JSON.parse(await ex('JSON.stringify({idx:Game.state.idx,end:document.getElementById(\"ending-card\").classList.contains(\"on\"),cl:document.getElementById(\"choice-layer\").classList.contains(\"on\"),cc:document.getElementById(\"chapter-card\").classList.contains(\"on\"),txt:document.getElementById(\"text\").textContent.slice(0,14),endTxt:document.getElementById(\"ending-card\").textContent.replace(/\\\\s+/g,\" \").slice(0,20),lock:!!Game.state.endingLock})'));",
"      if (st.end) { out.push('ENDING=' + st.endTxt + ' idx=' + st.idx + ' choices=' + ch); break; }",
"      if (st.cl) {",
"        const b = JSON.parse(await ex('JSON.stringify(document.querySelector(\".choice\").getBoundingClientRect())'));",
"        await c.send('Input.dispatchMouseEvent', { type: 'mousePressed', x: Math.round(b.x + 80), y: Math.round(b.y + b.height / 2), button: 'left', clickCount: 1 });",
"        await c.send('Input.dispatchMouseEvent', { type: 'mouseReleased', x: Math.round(b.x + 80), y: Math.round(b.y + b.height / 2), button: 'left', clickCount: 1 });",
"        ch++; repeat = 0; await sleep(120); continue;",
"      }",
"      await c.send('Input.dispatchMouseEvent', { type: 'mousePressed', x: 700, y: 700, button: 'left', clickCount: 1 });",
"      await c.send('Input.dispatchMouseEvent', { type: 'mouseReleased', x: 700, y: 700, button: 'left', clickCount: 1 });",
"      n++;",
"      if (st.idx === lastIdx && !st.cc) repeat++; else repeat = 0;",
"      lastIdx = st.idx;",
"      if (repeat > 400) { stuck = 'STUCK@' + st.idx + ' txt=' + st.txt + ' lock=' + st.lock; break; }",
"      if (n % 400 === 0) out.push('..progress idx=' + st.idx + ' clicks=' + n + ' ch=' + ch);",
"      await sleep(25);",
"    }",
"    if (stuck) out.push(stuck);",
"    out.push('totalClicks=' + n);",
"    console.log(out.join('\\n')); c.close(); proc.kill(); process.exit(0);",
"  }",
""
].join("\n");
if(s.indexOf('if (FULL) {')<0){ s=s.replace(marker, fullMode+marker); }
fs.writeFileSync(P,s,'utf8');
console.log('ok', s.indexOf('if (FULL) {')>0);

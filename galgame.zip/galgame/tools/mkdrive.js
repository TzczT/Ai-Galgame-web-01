const fs=require('fs');
const ROOT='D:\\3333\\7117\\galgame\\';
const page='<!DOCTYPE html><html><head><meta charset="utf-8"><title>drive</title><style>html,body{margin:0;height:100%}iframe{width:1440px;height:810px;border:0}</style></head><body>'+
'<iframe id="f" src="../dist/index.html"></iframe>'+
'<'+'script>'+
'var f=document.getElementById("f"),W=null,frames=0,lastIdx=-1,repeat=0,ch=0,stuck="",done="";'+
'function boot(){W=f.contentWindow;var d=f.contentDocument;'+
' try{localStorage.clear();}catch(e){}'+
' var b=d.querySelector(".t-btn.primary");if(b)b.click();'+
' setTimeout(function(){var o=d.getElementById("name-ok");if(o)o.click();try{W.Game.state.settings.speed=0;W.Game.state.settings.effect=false;}catch(e){}setTimeout(step,300);},250);}'+
'function step(){try{frames++;var d=f.contentDocument,G=W.Game.state;'+
' var gs=d.getElementById("game-screen"),cl=d.getElementById("choice-layer"),cc=d.getElementById("chapter-card"),ec=d.getElementById("ending-card");'+
' if(ec&&ec.classList.contains("on")){done="END "+ec.textContent.replace(/\s+/g," ").slice(0,20);document.title="FINAL:"+done+" idx="+G.idx+" ch="+ch;return;}'+
' if(cl&&cl.classList.contains("on")){var e=cl.querySelectorAll(".choice");if(e.length){e[0].click();ch++;}repeat=0;}'+
' else if(cc&&!cc.classList.contains("on")&&gs&&gs.classList.contains("active")){gs.click();}'+
' if(G.idx===lastIdx)repeat++;else{repeat=0;lastIdx=G.idx;}'+
' if(repeat>600&&!stuck)stuck="STUCK@"+G.idx+" txt="+(d.getElementById("text").textContent||"").slice(0,16);'+
' if(stuck||frames>100000){document.title="FINAL:"+(stuck||("OK end idx="+G.idx+" ch="+ch));return;}'+
' setTimeout(step,3);}catch(e){document.title="STEPERR:"+e.message;}}'+
'window.addEventListener("load",function(){setTimeout(boot,500);});'+
'<'+'/script></body></html>';
fs.writeFileSync(ROOT+'preview\\_drive.html', page,'utf8');
console.log('ok');

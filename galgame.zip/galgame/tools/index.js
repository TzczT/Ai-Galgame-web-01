const fs=require('fs'),path=require('path'),vm=require('vm');
const ROOT='D:\\3333\\7117\\galgame';
const sandbox={console,window:{},document:{},localStorage:{getItem(){return null},setItem(){}}};sandbox.window=sandbox;sandbox.globalThis=sandbox;
vm.createContext(sandbox);
['svg.js','art.js','script0.js','script1.js','script2.js'].forEach(f=>vm.runInContext(fs.readFileSync(path.join(ROOT,'src',f),'utf8'),sandbox,{filename:f}));
const S=[].concat(sandbox.SCRIPT_0,sandbox.SCRIPT_1,sandbox.SCRIPT_2);
[74,85,93,169,170,205,216,230,354,366,376,377,476,485,486,555,570,616,624,633,634,654,688,719,722].forEach(function(i){
  const n=S[i];
  console.log(i, JSON.stringify(n).slice(0,90));
});

const fs=require('fs');
let h=fs.readFileSync('D:\\3333\\7117\\galgame\\dist\\index.html','utf8');
const tag='<'+'script>' + [
"localStorage.clear();",
"window.__err=[];window.addEventListener('error',function(e){window.__err.push(String(e.message))});",
"var f=0;function step(){f++;var gs=document.getElementById('game-screen');var cl=document.getElementById('choice-layer');",
" if(cl&&cl.classList.contains('on')){var e=cl.querySelectorAll('.choice');if(e.length)e[0].click();}",
" else if(gs&&gs.classList.contains('active'))gs.click();",
" if(f>26000){var keys=[];for(var i=0;i<localStorage.length;i++){if(localStorage.key(i).indexOf('save_v1_end')===0)keys.push(localStorage.key(i));}",
"  document.title='END:'+keys.join(',')+':state='+JSON.stringify(Game.state.ending)+':err='+window.__err.length+':'+(window.__err[0]||'');return;}",
" setTimeout(step,3);}",
"window.addEventListener('load',function(){setTimeout(function(){if(window.Game)Game.state.settings.speed=0;setTimeout(step,60);},250);});"
].join('\n')+'<'+'/script>';
fs.writeFileSync('D:\\3333\\7117\\galgame\\preview\\_clean.html', h.replace('</body>', tag+'</body>'), 'utf8');
console.log('ok');
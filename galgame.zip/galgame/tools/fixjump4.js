const fs=require('fs');
const R='D:\\3333\\7117\\galgame\\src\\';
let s0=fs.readFileSync(R+'script0.js','utf8');
s0=s0.replace(/target: 'ch3'/g,"target: 'ch3_body'");
fs.writeFileSync(R+'script0.js',s0,'utf8');
console.log('ch3 jump -> ch3_body');

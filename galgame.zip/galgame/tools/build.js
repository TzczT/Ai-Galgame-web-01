/* tools/build.js —— 把 src/* 打成单文件 dist/index.html */
const fs = require('fs');
const path = require('path');
const ROOT = path.resolve(__dirname, '..');
const SRC = path.join(ROOT, 'src');
const DIST = path.join(ROOT, 'dist');
function read(p) { return fs.readFileSync(path.join(SRC, p), 'utf8'); }
const html = read('index.html');
const css = read('style.css');
const js = [
  read('svg.js'), read('art.js'), read('audio.js'),
  read('script0.js'), read('script1.js'), read('script2.js'),
  read('engine.js'),
  "\n/* ---- 剧本装配与启动 ---- */\n" +
  "var SCRIPT = [].concat(SCRIPT_0, SCRIPT_1, SCRIPT_2);\n" +
  "window.__S = SCRIPT;\n" +
  "Game.boot({ script: SCRIPT, title: META_TITLE, musiclist: META_MUSIC, cglist: META_CG, version: '1.0' });\n"
].join('\n\n');
let out = html.replace('<link rel="stylesheet" href="style.css"/>', '<style>\n' + css + '\n</style>');
if (out === html) { // 兼容没有 link 的情况
  out = html.replace('</head>', '<style>\n' + css + '\n</style>\n</head>');
}
out = out.replace('</body>', '<script>\n' + js + '\n</script>\n</body>');
if (out.indexOf('Game.boot') < 0) throw new Error('注入失败');
if (!fs.existsSync(DIST)) fs.mkdirSync(DIST, { recursive: true });
const target = path.join(DIST, 'index.html');
fs.writeFileSync(target, out, 'utf8');

// 同步一份到项目根，方便直接双击
fs.writeFileSync(path.join(ROOT, 'index.html'), out, 'utf8');
console.log('build ok:', target, (out.length / 1024).toFixed(1) + ' KB');

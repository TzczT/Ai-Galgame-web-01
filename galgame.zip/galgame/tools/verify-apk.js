const fs=require('fs');
const ROOT='D:\\3333\\7117\\galgame\\';
// 1) APK 复制到项目根，方便直接取用
fs.copyFileSync(ROOT+'android/out/LongerHeard-v1.0.apk', ROOT+'长耳听见的那一年-v1.0.apk');
// 2) 校验：APK 内 index.html 与 dist 一致
const {execSync}=require('child_process');
const crypto=require('crypto');
const a=fs.readFileSync(ROOT+'dist/index.html');
const apk=fs.readFileSync(ROOT+'长耳听见的那一年-v1.0.apk');
function extract(zipPath, entry){
  // 用 .NET 解压
  return execSync('powershell -NoProfile -Command "Add-Type -AssemblyName System.IO.Compression.FileSystem; $z=[System.IO.Compression.ZipFile]::OpenRead(\'' + zipPath + '\'); $e=$z.Entries | Where-Object { $_.FullName -eq \'' + entry + '\' }; $s=$e.Open(); $ms=New-Object System.IO.MemoryStream; $s.CopyTo($ms); [Convert]::ToBase64String($ms.ToArray()); $z.Dispose()"', {maxBuffer: 20*1024*1024}).toString().trim();
}
const b64=extract(ROOT+'长耳听见的那一年-v1.0.apk','assets/www/index.html');
const inner=Buffer.from(b64,'base64');
const h1=crypto.createHash('sha256').update(a).digest('hex');
const h2=crypto.createHash('sha256').update(inner).digest('hex');
const h3=crypto.createHash('sha256').update(apk).digest('hex');
console.log('dist/index.html    bytes='+a.length+' sha256='+h1.slice(0,16));
console.log('APK 内 index.html  bytes='+inner.length+' sha256='+h2.slice(0,16));
console.log('两者一致:', h1===h2 ? 'YES' : 'NO');
console.log('APK 大小 = '+(apk.length/1024).toFixed(1)+' KB  sha256='+h3.slice(0,16));

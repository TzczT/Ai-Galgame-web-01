const fs=require('fs');
const ROOT='D:\\3333\\7117\\galgame\\';
let base=fs.readFileSync(ROOT+'preview\\_rt6.html','utf8');
base=base.replace("window.addEventListener('load',function(){","window.__mErr=[];window.addEventListener('error',function(e){window.__mErr.push(String(e.message));});window.addEventListener('load',function(){");
base=base.replace("if(n<16)setTimeout(once,500);","if(n<16)setTimeout(once,500); else document.title='M-END:'+document.title;");
base=base.replace("setTimeout(once,800);},200);},300);});","setTimeout(function(){try{once();}catch(e){document.title='BOOTERR:'+e.message;}},800);},200);},300);});");
fs.writeFileSync(ROOT+'preview\\_rt7.html', base, 'utf8');
console.log('ok');

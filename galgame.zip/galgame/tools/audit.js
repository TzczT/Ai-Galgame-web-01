const fs=require('fs'),path=require('path'),vm=require('vm');
const ROOT='D:\\3333\\7117\\galgame';
const sandbox={console,window:{},document:{},localStorage:{getItem(){return null},setItem(){}}};sandbox.window=sandbox;sandbox.globalThis=sandbox;
vm.createContext(sandbox);
['svg.js','art.js','script0.js','script1.js','script2.js'].forEach(f=>vm.runInContext(fs.readFileSync(path.join(ROOT,'src',f),'utf8'),sandbox,{filename:f}));
const S=[].concat(sandbox.SCRIPT_0,sandbox.SCRIPT_1,sandbox.SCRIPT_2);
const L={};
S.forEach((n,i)=>{ if(n&&n.t==='label'&&n.label&&L[n.label]===undefined)L[n.label]=i; });
const bad=[];
S.forEach((n,i)=>{
  if(!n)return;
  const targets=[];
  if(n.t==='jump') targets.push(['jump', n.target||n.label]);
  if(n.t==='choice') n.options.forEach((o,k)=>targets.push(['choice'+k, o.goto]));
  if(n.t==='if'||n.t==='route'){ if(n.then)targets.push(['then',n.then]); if(n.else)targets.push(['else',n.else]); }
  targets.forEach(function(t){ const nm=t[1]; if(nm===undefined) bad.push(i+' '+t[0]+' 缺少目标'); else if(L[nm]===undefined) bad.push(i+' '+t[0]+' -> 不存在的标签 '+nm); });
});
console.log('labels: '+Object.keys(L).length);
console.log('bad targets: '+(bad.length?('\n'+bad.join('\n')):'none'));
// 逐条分支可达性：从每个 branch 标签走到下一个 choice/ending
function walk(start,max){let idx=start,out=[],g=0;const seen={};
 while(g++<max&&idx>=0&&idx<S.length){ if(seen[idx]){out.push('LOOP@'+idx);break;} seen[idx]=1;
  const n=S[idx]; if(!n){out.push('EOF');break;}
  if(n.t==='label'){idx++;continue;}
  if(n.text!==undefined){idx++;continue;}
  if(n.t==='jump'){const t=L[n.target||n.label];out.push('J->'+t);idx=t;continue;}
  if(n.t==='choice'){out.push('CHOICE');break;}
  if(n.t==='ending'){out.push('ENDING:'+n.kind);break;}
  if(n.t==='chapter'){out.push('CH:'+n.name);idx++;continue;}
  idx++;
 } return out.join(' ');}
['p_go','p_stay','p_copy','b_fix','b_report','b_ask','c_finish','c_cure','c_none','d_open','d_close','d_ear','d_simple','d_umbrella'].forEach(function(k){
  console.log(k+' => '+walk(L[k],60));
});

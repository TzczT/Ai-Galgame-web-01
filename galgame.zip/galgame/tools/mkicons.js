const fs=require('fs'),zlib=require('zlib');
const src=fs.readFileSync('D:\\3333\\7117\\galgame\\preview\\icon.png');
// 解码原图
function decodePng(b){
  let o=8,idat=[],W=0,H=0;
  while(o<b.length){const len=b.readUInt32BE(o);const t=b.slice(o+4,o+8).toString('ascii');
    if(t==='IHDR'){W=b.readUInt32BE(o+8);H=b.readUInt32BE(o+12);}
    if(t==='IDAT')idat.push(b.slice(o+8,o+8+len));
    o+=12+len;}
  return {W:W,H:H,raw:zlib.inflateSync(Buffer.concat(idat))};
}
function encPng(W,H,pix){
  function chunk(type,data){const len=Buffer.alloc(4);len.writeUInt32BE(data.length,0);const t=Buffer.from(type,'ascii');
    let c=0xffffffff;const cb=Buffer.concat([t,data]);for(let i=0;i<cb.length;i++){c^=cb[i];for(let k=0;k<8;k++)c=(c>>>1)^(0xEDB88320&-(c&1));}c=(c^0xffffffff)>>>0;
    const cr=Buffer.alloc(4);cr.writeUInt32BE(c,0);return Buffer.concat([len,t,data,cr]);}
  const ih=Buffer.alloc(13);ih.writeUInt32BE(W,0);ih.writeUInt32BE(H,4);ih[8]=8;ih[9]=6;
  const raw=Buffer.alloc(H*(W*4+1));
  for(let y=0;y<H;y++){raw[y*(W*4+1)]=0;pix.copy(raw,y*(W*4+1)+1,y*W*4,(y+1)*W*4);}
  return Buffer.concat([Buffer.from([137,80,78,71,13,10,26,10]),chunk('IHDR',ih),chunk('IDAT',zlib.deflateSync(raw,{level:9})),chunk('IEND',Buffer.alloc(0))]);
}
const img=decodePng(src);
const S=img.W;
function getPix(x,y){const i=y*(S*4+1)+1+x*4;return [img.raw[i],img.raw[i+1],img.raw[i+2],img.raw[i+3]];}
function resize(N){
  const out=Buffer.alloc(N*N*4);
  for(let y=0;y<N;y++)for(let x=0;x<N;x++){
    // 盒式采样
    const x0=Math.floor(x*S/N), x1=Math.max(x0+1,Math.floor((x+1)*S/N));
    const y0=Math.floor(y*S/N), y1=Math.max(y0+1,Math.floor((y+1)*S/N));
    let r=0,g=0,b=0,a=0,n=0;
    for(let yy=y0;yy<y1;yy++)for(let xx=x0;xx<x1;xx++){const p=getPix(xx,yy);r+=p[0];g+=p[1];b+=p[2];a+=p[3];n++;}
    const i=(y*N+x)*4;out[i]=Math.round(r/n);out[i+1]=Math.round(g/n);out[i+2]=Math.round(b/n);out[i+3]=Math.round(a/n);
  }
  return out;
}
const dens=[['mdpi',48],['hdpi',72],['xhdpi',96],['xxhdpi',144],['xxxhdpi',192]];
const base='D:\\3333\\7117\\galgame\\android\\app\\src\\main\\res\\';
dens.forEach(function(d){
  const dir=base+'mipmap-'+d[0];
  fs.mkdirSync(dir,{recursive:true});
  const png=encPng(d[1],d[1],resize(d[1]));
  fs.writeFileSync(dir+'/ic_launcher.png',png);
  console.log('mipmap-'+d[0]+'/ic_launcher.png  '+d[1]+'x'+d[1]+'  '+(png.length/1024).toFixed(1)+' KB');
});
// 圆角图标（同图）
dens.forEach(function(d){
  fs.copyFileSync(base+'mipmap-'+d[0]+'/ic_launcher.png', base+'mipmap-'+d[0]+'/ic_launcher_round.png');
});
console.log('round icons copied');

const fs=require('fs');
const R='D:\\3333\\7117\\galgame\\src\\';
// 1) 在章节节点前加跳转落点标签
let s1=fs.readFileSync(R+'script1.js','utf8');
s1=s1.replace("  { t: 'chapter', name: '第 2 章'","  { t: 'label', label: 'ch2_body' },\n  { t: 'chapter', name: '第 2 章'");
fs.writeFileSync(R+'script1.js',s1,'utf8');
let s2=fs.readFileSync(R+'script2.js','utf8');
s2=s2.replace("  { t: 'chapter', name: '第 3 章'","  { t: 'label', label: 'ch3_body' },\n  { t: 'chapter', name: '第 3 章'");
fs.writeFileSync(R+'script2.js',s2,'utf8');
// 2) 修正 script0 中三条错误跳转
let s0=fs.readFileSync(R+'script0.js','utf8');
const before=(s0.match(/target: 'ch2'/g)||[]).length;
s0=s0.replace(/target: 'ch2'/g,"target: 'ch2_body'");
fs.writeFileSync(R+'script0.js',s0,'utf8');
console.log('ch2 jumps fixed:', before, '->', (s0.match(/target: 'ch2_body'/g)||[]).length);

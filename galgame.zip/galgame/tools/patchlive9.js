const fs=require('fs');
const P='D:\\3333\\7117\\galgame\\tools\\live.js';
let s=fs.readFileSync(P,'utf8');
if(s.indexOf('const CHOICE_IDX')<0){
  s=s.replace("const FULL = process.argv[4] === 'full';","const FULL = process.argv[4] === 'full';\nconst CHOICE_IDX = parseInt(process.argv[5] || '0', 10);");
  s=s.replace('document.querySelector(".choice").getBoundingClientRect()','document.querySelectorAll(".choice")[Math.min(CHOICE_IDX, document.querySelectorAll(".choice").length-1)].getBoundingClientRect()');
}
fs.writeFileSync(P,s,'utf8');console.log('ok');

const fs=require('fs');
const ROOT='D:\\3333\\7117\\galgame\\';
// 直接从 src 重建 dist 并给 boot 加 try/catch
const SRC=ROOT+'src\\';
const order=['svg.js','art.js','audio.js','script0.js','script1.js','script2.js','engine.js'];
let h=fs.readFileSync(SRC+'index.html','utf8');
h=h.replace('<link rel="stylesheet" href="style.css"/>','<style>\n'+fs.readFileSync(SRC+'style.css','utf8')+'\n</style>');
let code=order.map(f=>fs.readFileSync(SRC+f,'utf8')).join('\n\n');
code+="\nvar SCRIPT=[].concat(SCRIPT_0,SCRIPT_1,SCRIPT_2);\nwindow.__S=SCRIPT;\ntry{Game.boot({script:SCRIPT,title:META_TITLE,musiclist:META_MUSIC,cglist:META_CG,version:'1.0'});}catch(e){window.__bootErr=String(e&&e.stack||e);}\n";
h=h.replace('</body>','<script>\n'+code+'\n</script>\n</body>');
fs.writeFileSync(ROOT+'dist/index.html',h,'utf8');

const probe=[
"window.addEventListener('load',function(){setTimeout(function(){",
" var btn=document.querySelector('.t-btn.primary');",
" document.title='BOOT:'+(window.__bootErr?('ERR '+window.__bootErr.slice(0,240)):('OK btn='+!!btn+' art='+(document.getElementById('title-art').innerHTML.length)));",
"},600);});"
].join("\n");
fs.writeFileSync(ROOT+'preview\\_bo.html', h.replace('</body>','<'+'script>'+probe+'<'+'/script></body>'),'utf8');
console.log('ok');

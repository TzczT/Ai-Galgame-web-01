const fs=require('fs');
let s=fs.readFileSync('D:\\3333\\7117\\galgame\\tools\\mkicon.js','utf8');
// 把 px() 的写入改稳：先算再截断写入
s=s.replace(
"function px(x,y,r,g,b,a){ if(x<0||y<0||x>=S||y>=S)return; const i=(y*S+x)*4; const na=(a===undefined?255:a)/255; buf[i]=Math.round(buf[i]*(1-na)+r*na); buf[i+1]=Math.round(buf[i+1]*(1-na)+g*na); buf[i+2]=Math.round(buf[i+2]*(1-na)+b*na); buf[i+3]=255; }",
"function clamp255(v){ return v<0?0:(v>255?255:Math.round(v)); }\nfunction px(x,y,r,g,b,a){ if(x<0||y<0||x>=S||y>=S)return; const i=(y*S+x)*4; const na=(a===undefined?255:a)/255; buf[i]=clamp255(buf[i]*(1-na)+r*na); buf[i+1]=clamp255(buf[i+1]*(1-na)+g*na); buf[i+2]=clamp255(buf[i+2]*(1-na)+b*na); buf[i+3]=255; }");
fs.writeFileSync('D:\\3333\\7117\\galgame\\tools\\mkicon.js',s,'utf8');
console.log('px hardened:', s.indexOf('clamp255')>0);

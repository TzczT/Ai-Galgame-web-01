const fs=require('fs');
const R='D:\\3333\\7117\\galgame\\src\\';
const files=['script0.js','script1.js','script2.js'];
let n=0;
files.forEach(function(f){
  const p=R+f;
  let txt=fs.readFileSync(p,'utf8');
  // 只改 "jump" 节点里的 label 字段名 -> target
  txt=txt.replace(/(\{\s*t:\s*'jump'\s*,\s*)label(\s*:)/g, '$1target$2');
  fs.writeFileSync(p,txt,'utf8');
});
console.log('jump.label -> jump.target done');

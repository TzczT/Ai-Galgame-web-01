/* tools/mkicon.js —— 用 zlib 手写 PNG，生成水彩风安卓图标 */
const fs=require('fs'), zlib=require('zlib'), path=require('path');
const ROOT='D:\\3333\\7117\\galgame\\';
const S=512;
const buf=Buffer.alloc(S*S*4);
function clamp255(v){ return v<0?0:(v>255?255:Math.round(v)); }
function px(x,y,r,g,b,a){ if(x<0||y<0||x>=S||y>=S)return; const i=(y*S+x)*4; const na=(a===undefined?255:a)/255; buf[i]=clamp255(buf[i]*(1-na)+r*na); buf[i+1]=clamp255(buf[i+1]*(1-na)+g*na); buf[i+2]=clamp255(buf[i+2]*(1-na)+b*na); buf[i+3]=255; }
function lerp(a,b,t){return a+(b-a)*t;}
function noise(x,y){ // 简易纸纹噪声
  const s=Math.sin(x*12.9898+y*78.233)*43758.5453; return s-Math.floor(s);
}
// 背景：藏青渐变圆角
for(let y=0;y<S;y++){
  for(let x=0;x<S;x++){
    const t=(x*0.35+y*0.65)/S;
    let r=lerp(0x3d,0x16,t), g=lerp(0x50,0x20,t), b=lerp(0x80,0x3a,t);
    // 纸纹
    const n=(noise(x*0.9,y*0.9)-0.5)*14;
    r+=n; g+=n; b+=n;
    // 圆角裁切（圆角半径 92）
    const rad=92, cx=Math.min(Math.max(x,rad),S-rad), cy=Math.min(Math.max(y,rad),S-rad);
    const d=Math.hypot(x-cx,y-cy);
    const a=d<=rad?1:Math.max(0,1-(d-rad));
    buf[(y*S+x)*4]=Math.round(r); buf[(y*S+x)*4+1]=Math.round(g); buf[(y*S+x)*4+2]=Math.round(b); buf[(y*S+x)*4+3]=Math.round(255*a);
  }
}
// 暖金光晕
for(let y=0;y<S;y++)for(let x=0;x<S;x++){
  const d=Math.hypot(x-360,y-150);
  if(d<300){ const a=Math.max(0,1-d/300)*0.5; px(x,y,0xe0,0xb8,0x4c,a); }
}
// 磁带机身（米白圆角矩形）
function roundRect(cx,cy,w,h,rad,col,a){
  for(let y=Math.floor(cy-h/2);y<=cy+h/2;y++)for(let x=Math.floor(cx-w/2);x<=cx+w/2;x++){
    const dx=Math.max(Math.abs(x-cx)-(w/2-rad),0), dy=Math.max(Math.abs(y-cy)-(h/2-rad),0);
    if(Math.hypot(dx,dy)<=rad) px(x,y,col[0],col[1],col[2],a);
  }
}
roundRect(256,300,330,210,26,[0xf6,0xf0,0xe0],1);
roundRect(256,300,330,210,26,[0xc9,0xbd,0xa4],0.25);
// 两个磁带轮
function ring(cx,cy,r,col,lw){
  for(let a=0;a<Math.PI*2;a+=0.004){
    for(let rr=r-lw/2;rr<=r+lw/2;rr+=0.5){
      px(Math.round(cx+Math.cos(a)*rr),Math.round(cy+Math.sin(a)*rr),col[0],col[1],col[2],1);
    }
  }
}
ring(180,315,52,[0x2b,0x3a,0x63],14);
ring(332,315,52,[0x2b,0x3a,0x63],14);
ring(180,315,20,[0x2b,0x3a,0x63],10);
ring(332,315,20,[0x2b,0x3a,0x63],10);
// 磁带窗
for(let y=290;y<=340;y++)for(let x=140;x<=372;x++){
  if((x-256)*(x-256)/(118*118)+(y-315)*(y-315)/(26*26)<=1) px(x,y,0x8a,0x7c,0x64,0.25);
}
// 金色"耳朵"暖金横杠（呼应 longer）
for(let y=372;y<=392;y++)for(let x=120;x<=392;x++){
  const t=(x-120)/272;
  px(x,y,Math.round(lerp(0xe0,0xc9,t)),Math.round(lerp(0xb8,0xa2,t)),Math.round(lerp(0x4c,0x3c,t)),1);
}

function P(x,y){const i=(y*S+x)*4;return [buf[i],buf[i+1],buf[i+2],buf[i+3]];}
console.log('probe', P(256,300).join(','), P(180,315).join(','), P(256,382).join(','));

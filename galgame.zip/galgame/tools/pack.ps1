Add-Type -AssemblyName System.IO.Compression.FileSystem
$root='D:\3333\7117\galgame'
# 1) 游戏 + 安卓工程（排除 SDK 与临时文件）
$zip1='D:\3333\7117\galgame.zip'
if(Test-Path $zip1){Remove-Item $zip1 -Force}
$z=[System.IO.Compression.ZipFile]::Open($zip1,'Create')
Get-ChildItem $root -Recurse -File | Where-Object {
  $_.FullName -notmatch '\\sdk\\' -and $_.Name -notlike '_*' -and $_.Extension -ne '.zip' -and $_.Name -ne 'jdk17.zip'
} | ForEach-Object {
  $rel=$_.FullName.Substring($root.Length+1).Replace('\','/')
  [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($z,$_.FullName,('galgame/'+$rel)) | Out-Null
}
$z.Dispose()
'galgame.zip   = ' + [math]::Round((Get-Item $zip1).Length/1MB,2) + ' MB'
# 2) 只含 APK 的分发包
$zip2='D:\3333\7117\长耳听见的那一年-APK.zip'
if(Test-Path $zip2){Remove-Item $zip2 -Force}
$z2=[System.IO.Compression.ZipFile]::Open($zip2,'Create')
[System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($z2,(Join-Path $root '长耳听见的那一年-v1.0.apk'),'长耳听见的那一年-v1.0.apk') | Out-Null
[System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($z2,(Join-Path $root 'README.md'),'安装说明.txt') | Out-Null
$z2.Dispose()
'APK 分发包    = ' + [math]::Round((Get-Item $zip2).Length/1MB,2) + ' MB'
$ErrorActionPreference='Stop'
$Root='D:\3333\7117\galgame\android'
$dl=Join-Path $Root '_dl'
$sdk=Join-Path $Root 'sdk'
$javaHome='D:\1\PyCharm 2025.1.6.1\jbr'
New-Item -ItemType Directory -Force -Path $sdk | Out-Null
$env:JAVA_HOME=$javaHome
$env:PATH=(Join-Path $javaHome 'bin') + ';' + $env:PATH

$cmdZip=Join-Path $dl 'cmdline-tools.zip'
if(-not (Test-Path $cmdZip)){ throw 'cmdline-tools.zip 还没下载完' }
Write-Host ('zip = ' + [math]::Round((Get-Item $cmdZip).Length/1MB,1) + ' MB')
$ctRoot=Join-Path $sdk 'cmdline-tools'
if (-not (Test-Path (Join-Path $ctRoot 'latest\bin\sdkmanager.bat'))) {
  Write-Host 'extracting cmdline-tools ...'
  New-Item -ItemType Directory -Force -Path $ctRoot | Out-Null
  & tar.exe -xf $cmdZip -C $ctRoot
  if (Test-Path (Join-Path $ctRoot 'cmdline-tools')) { Move-Item (Join-Path $ctRoot 'cmdline-tools') (Join-Path $ctRoot 'latest') -Force }
}
$sdkmanager = Join-Path $ctRoot 'latest\bin\sdkmanager.bat'
if (-not (Test-Path $sdkmanager)) { throw '找不到 sdkmanager.bat' }
Write-Host 'sdkmanager =' $sdkmanager
& $sdkmanager --version
Write-Host '--- installing SDK packages (may take a few minutes) ---'
$y = ('y' + [Environment]::NewLine) * 60
$y | & $sdkmanager --sdk_root=$sdk 'build-tools;34.0.0' 'platforms;android-34' 'platform-tools' 2>&1 | Select-Object -Last 10
Write-Host '--- installed ---'
Get-ChildItem (Join-Path $sdk 'build-tools') -Directory -ErrorAction SilentlyContinue | ForEach-Object { 'build-tools ' + $_.Name }
Get-ChildItem (Join-Path $sdk 'platforms') -Directory -ErrorAction SilentlyContinue | ForEach-Object { 'platform    ' + $_.Name }
const fs=require('fs');
const ROOT='D:\\3333\\7117\\galgame\\';
fs.copyFileSync(ROOT+'dist/index.html', ROOT+'index.html');
console.log('synced index.html', (fs.statSync(ROOT+'index.html').size/1024).toFixed(1)+' KB');

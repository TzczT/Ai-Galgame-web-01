/* tools/live.js —— 用 CDP 真实驱动浏览器（Node 内置 WebSocket） */
const { spawn } = require('child_process');
const http = require('http');
const path = require('path');
const EDGE = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';
const PORT = 9411;
const url = process.argv[2] || 'file:///D:/3333/7117/galgame/dist/index.html';
const steps = parseInt(process.argv[3] || '8', 10);
const FULL = process.argv[4] === 'full';
const CHOICE_IDX = parseInt(process.argv[5] || '0', 10);
const sleep = ms => new Promise(r => setTimeout(r, ms));
const get = p => new Promise((res, rej) => {
  http.get({ host: '127.0.0.1', port: PORT, path: p }, r => { let d = ''; r.on('data', c => d += c); r.on('end', () => res(d)); }).on('error', rej);
});
function cdpOpen(wsUrl) {
  return new Promise((resolve, reject) => {
    const u = new URL(wsUrl);
    const key = Buffer.from(String(Math.random())).toString('base64');
    const req = http.request({
      host: u.hostname, port: u.port, path: u.pathname + u.search, method: 'GET',
      headers: { 'Connection': 'Upgrade', 'Upgrade': 'websocket', 'Sec-WebSocket-Version': '13', 'Sec-WebSocket-Key': key }
    });
    req.on('upgrade', (res, socket) => {
      let buf = Buffer.alloc(0);
      const pending = new Map(); let id = 0; const events = [];
      socket.on('data', chunk => {
        buf = Buffer.concat([buf, chunk]);
        while (buf.length >= 2) {
          const fin = (buf[0] & 0x80) !== 0, op = buf[0] & 0x0f;
          let len = buf[1] & 0x7f, off = 2;
          if (len === 126) { if (buf.length < 4) return; len = buf.readUInt16BE(2); off = 4; }
          else if (len === 127) { if (buf.length < 10) return; len = Number(buf.readBigUInt64BE(2)); off = 10; }
          if (buf.length < off + len) return;
          const payload = buf.slice(off, off + len); buf = buf.slice(off + len);
          if (op === 1) {
            try {
              const m = JSON.parse(payload.toString('utf8'));
              if (m.id && pending.has(m.id)) { pending.get(m.id)(m); pending.delete(m.id); }
              else if (m.method) events.push(m);
            } catch (e) { }
          }
        }
      });
      const send = (method, params) => new Promise(res => {
        const i = ++id; pending.set(i, res);
        const body = Buffer.from(JSON.stringify({ id: i, method, params: params || {} }), 'utf8');
        const head = Buffer.alloc(2 + (body.length > 125 ? 2 : 0));
        head[0] = 0x81;
        if (body.length <= 125) { head[1] = body.length | 0x80; }
        else { head[1] = 126 | 0x80; head.writeUInt16BE(body.length, 2); }
        const mask = Buffer.from([1, 2, 3, 4]);
        const masked = Buffer.alloc(body.length);
        for (let i2 = 0; i2 < body.length; i2++) masked[i2] = body[i2] ^ mask[i2 % 4];
        socket.write(Buffer.concat([head, mask, masked]));
      });
      resolve({ send, events, close: () => socket.destroy() });
    });
    req.on('error', reject); req.end();
  });
}
(async () => {
  const proc = spawn(EDGE, ['--headless=new', '--disable-gpu', '--remote-debugging-port=' + PORT, '--user-data-dir=' + require('os').tmpdir() + '\\edge-live-gal', '--no-first-run', '--window-size=1440,810', 'about:blank'], { stdio: 'ignore' });
  let list = null;
  for (let i = 0; i < 50; i++) { await sleep(400); try { list = JSON.parse(await get('/json/list')); if (list && list.length) break; } catch (e) { } }
  if (!list) { console.log('NO-DEVTOOLS'); proc.kill(); process.exit(1); }
  const page = list.find(t => t.type === 'page');
  const c = await cdpOpen(page.webSocketDebuggerUrl);
  await c.send('Runtime.enable'); await c.send('Page.enable');
  const ev = async (expr) => { const r = await c.send('Runtime.evaluate', { expression: expr, returnByValue: true }); return r.result && r.result.result ? r.result.result.value : undefined; };
  const ex = e => ev(e).then(v => v === undefined ? '' : String(v));
  await c.send('Page.navigate', { url });
  await sleep(3000);
  const out = [];
  out.push('boot=' + await ex('typeof Game+"|"+typeof SOUND+"|"+(window.Game?Game.state.idx:"-")'));
  // 真实点击标题按钮
  await ex('(function(){var b=document.querySelector(".t-btn.primary");if(b)b.click();return 1;})()');
  await sleep(700);await sleep(600);
  out.push('afterTitleClick screen=' + await ex('document.querySelector(".screen.active").id'));
  out.push('nameScreenActive=' + await ex('document.getElementById("name-screen").classList.contains("active")'));
  if (await ex('document.getElementById("name-screen").classList.contains("active")')) {
    await c.send('Input.dispatchKeyEvent', { type: 'char', text: '林砚' });
    await sleep(200);
        await ex('(function(){var o=document.getElementById("name-ok");if(o)o.click();return 1;})()');
    await sleep(800);
  }
  out.push('afterName screen=' + await ex('document.querySelector(".screen.active").id') + ' idx=' + await ex('Game.state.idx'));
  if (FULL) {
    let n = 0, lastIdx = -1, repeat = 0, ch = 0, stuck = '';
    const t0 = Date.now();
    while (Date.now() - t0 < 420000) {
      const st = JSON.parse(await ex('JSON.stringify({idx:Game.state.idx,end:document.getElementById("ending-card").classList.contains("on"),cl:document.getElementById("choice-layer").classList.contains("on"),cc:document.getElementById("chapter-card").classList.contains("on"),txt:document.getElementById("text").textContent.slice(0,14),endTxt:document.getElementById("ending-card").textContent.replace(/\\s+/g," ").slice(0,20),lock:!!Game.state.endingLock})'));
      if (st.end) { out.push('ENDING=' + st.endTxt + ' idx=' + st.idx + ' choices=' + ch); break; }
      if (st.cl) {
        const b = JSON.parse(await ex('JSON.stringify((function(){var q=document.querySelectorAll(".choice");var i=Math.min(' + CHOICE_IDX + ',q.length-1);return q[i].getBoundingClientRect();})())'));
        await c.send('Input.dispatchMouseEvent', { type: 'mousePressed', x: Math.round(b.x + 80), y: Math.round(b.y + b.height / 2), button: 'left', clickCount: 1 });
        await c.send('Input.dispatchMouseEvent', { type: 'mouseReleased', x: Math.round(b.x + 80), y: Math.round(b.y + b.height / 2), button: 'left', clickCount: 1 });
        ch++; repeat = 0; await sleep(120); continue;
      }
      await c.send('Input.dispatchMouseEvent', { type: 'mousePressed', x: 700, y: 700, button: 'left', clickCount: 1 });
      await c.send('Input.dispatchMouseEvent', { type: 'mouseReleased', x: 700, y: 700, button: 'left', clickCount: 1 });
      n++;
      if (st.idx === lastIdx && !st.cc && !st.cl && !st.end && st.txt) repeat++; else repeat = 0;
      lastIdx = st.idx;
      if (repeat > 80) { stuck = 'STUCK@' + st.idx + ' txt=' + st.txt + ' lock=' + st.lock; break; }
      if (n % 400 === 0) out.push('..progress idx=' + st.idx + ' clicks=' + n + ' ch=' + ch);
      await sleep(110);
    }
    if (stuck) { out.push(stuck); out.push('T=' + await ex('document.body.getAttribute("data-t")'));
        out.push('CT=' + await ex('document.body.getAttribute("data-ct")'));
        out.push('TR=' + await ex('document.body.getAttribute("data-tr")')); out.push('J=' + await ex('document.body.getAttribute("data-j")')); out.push('NODE=' + await ex('JSON.stringify(window.__S&&window.__S[Game.state.idx])')); }
    out.push('totalClicks=' + n);
    console.log(out.join('\n')); c.close(); proc.kill(); process.exit(0);
  }
  // 连续真实点击对话框区域
  const seq = [];
  for (let i = 0; i < steps; i++) {
    await c.send('Input.dispatchMouseEvent', { type: 'mousePressed', x: 700, y: 700, button: 'left', clickCount: 1 });
    await c.send('Input.dispatchMouseEvent', { type: 'mouseReleased', x: 700, y: 700, button: 'left', clickCount: 1 });
    await sleep(650);
    const cl = await ex('document.getElementById("choice-layer").classList.contains("on")');
    if (cl === true) {
      const b = JSON.parse(await ex('JSON.stringify(document.querySelector(".choice").getBoundingClientRect())'));
      await c.send('Input.dispatchMouseEvent', { type: 'mousePressed', x: Math.round(b.x + 60), y: Math.round(b.y + b.height / 2), button: 'left', clickCount: 1 });
      await c.send('Input.dispatchMouseEvent', { type: 'mouseReleased', x: Math.round(b.x + 60), y: Math.round(b.y + b.height / 2), button: 'left', clickCount: 1 });
      await sleep(500);
    }
    seq.push(i + ':idx=' + await ex('Game.state.idx') + ':txt=' + (await ex('document.getElementById("text").textContent')).slice(0, 12) + ':choice=' + cl);
  }
  out.push('clicks:\n  ' + seq.join('\n  '));
  out.push('errors=' + await ex('JSON.stringify(window.__bootErr||"")'));
  out.push('runErr=' + await ex('String(window.__RUNERR||"none").slice(0,400)'));
  console.log(out.join('\n'));
  c.close(); proc.kill(); process.exit(0);
})();

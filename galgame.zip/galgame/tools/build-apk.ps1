$ErrorActionPreference = 'Stop'
$Root = 'D:\3333\7117\galgame\android'
$Game = 'D:\3333\7117\galgame'
$Main = Join-Path $Root 'app\src\main'
$Work = Join-Path $Root 'build'
$Out  = Join-Path $Root 'out'
$javaHome = 'D:\1\PyCharm 2025.1.6.1\jbr'
$env:JAVA_HOME = $javaHome
$env:PATH = (Join-Path $javaHome 'bin') + ';' + $env:PATH
$javac = Join-Path $javaHome 'bin\javac.exe'
$keytool = Join-Path $javaHome 'bin\keytool.exe'
New-Item -ItemType Directory -Force -Path $Work, $Out | Out-Null
$sdk = Join-Path $Root 'sdk'
$bt = (Get-ChildItem (Join-Path $sdk 'build-tools') -Directory | Sort-Object Name -Descending | Select-Object -First 1).FullName
$aapt2 = Join-Path $bt 'aapt2.exe'
$d8 = Join-Path $bt 'd8.bat'
$zipalign = Join-Path $bt 'zipalign.exe'
$apksigner = Join-Path $bt 'apksigner.bat'
$androidJar = Join-Path $sdk 'platforms\android-34\android.jar'
Write-Host '[1/6] tools ready'

# 资源编译与链接（assets 稍后手动写入，保证 ZIP 路径用正斜杠）
$flat = Join-Path $Work 'res.zip'
if (Test-Path $flat) { Remove-Item $flat -Force }
& $aapt2 compile --dir (Join-Path $Main 'res') -o $flat
if ($LASTEXITCODE -ne 0) { throw 'aapt2 compile 失败' }
$base = Join-Path $Work 'base.apk'
if (Test-Path $base) { Remove-Item $base -Force }
& $aapt2 link -o $base -I $androidJar --manifest (Join-Path $Main 'AndroidManifest.xml') -R $flat --auto-add-overlay --java (Join-Path $Work 'gen') --min-sdk-version 24 --target-sdk-version 34 --version-code 1 --version-name 1.0
if ($LASTEXITCODE -ne 0) { throw 'aapt2 link 失败' }
Write-Host '[2/6] resources linked'

# Java -> dex
$classes = Join-Path $Work 'classes'
Remove-Item -Recurse -Force $classes -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Force -Path $classes | Out-Null
$srcs = @(Get-ChildItem (Join-Path $Main 'java') -Recurse -Filter *.java | Select-Object -ExpandProperty FullName)
if (Test-Path (Join-Path $Work 'gen')) { $srcs += @(Get-ChildItem (Join-Path $Work 'gen') -Recurse -Filter *.java | Select-Object -ExpandProperty FullName) }
& $javac --release 8 -nowarn -classpath $androidJar -d $classes $srcs
if ($LASTEXITCODE -ne 0) { throw 'javac 失败' }
$dexDir = Join-Path $Work 'dex'
Remove-Item -Recurse -Force $dexDir -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Force -Path $dexDir | Out-Null
$classFiles = @(Get-ChildItem $classes -Recurse -Filter *.class | Select-Object -ExpandProperty FullName)
& $d8 --lib $androidJar --min-api 24 --output $dexDir $classFiles
if ($LASTEXITCODE -ne 0) { throw 'd8 失败' }
Write-Host '[3/6] dex ok'

# 组装：base.apk 里的资源 + 正斜杠的 assets + classes.dex
$stage = Join-Path $Work 'stage'
Remove-Item -Recurse -Force $stage -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Force -Path (Join-Path $stage 'assets\www') | Out-Null
Copy-Item (Join-Path $Game 'dist\index.html') (Join-Path $stage 'assets\www\index.html') -Force
Copy-Item (Join-Path $dexDir 'classes.dex') (Join-Path $stage 'classes.dex') -Force
Add-Type -AssemblyName System.IO.Compression.FileSystem
$inZip = [System.IO.Compression.ZipFile]::OpenRead($base)
$inZip.Entries | ForEach-Object {
  $dest = Join-Path $stage ($_.FullName -replace '/', '\')
  New-Item -ItemType Directory -Force -Path (Split-Path $dest) | Out-Null
  [System.IO.Compression.ZipFileExtensions]::ExtractToFile($_, $dest, $true)
}
$inZip.Dispose()
$unsigned = Join-Path $Work 'unsigned.apk'
if (Test-Path $unsigned) { Remove-Item $unsigned -Force }
$outZip = [System.IO.Compression.ZipFile]::Open($unsigned, 'Create')
Get-ChildItem $stage -Recurse -File | Sort-Object FullName | ForEach-Object {
  $rel = $_.FullName.Substring($stage.Length + 1).Replace('\', '/')
  [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($outZip, $_.FullName, $rel, [System.IO.Compression.CompressionLevel]::Optimal) | Out-Null
}
$outZip.Dispose()
Write-Host '[4/6] staged & zipped'

# 对齐 + 签名（先对齐再签，兼容 Android 11+ 的 v2 校验）
$aligned = Join-Path $Work 'aligned.apk'
if (Test-Path $aligned) { Remove-Item $aligned -Force }
& $zipalign -f -p 4 $unsigned $aligned
if ($LASTEXITCODE -ne 0) { throw 'zipalign 失败' }
$ks = Join-Path $Root 'longer-debug.jks'
if (-not (Test-Path $ks)) {
  & $keytool -genkeypair -keystore $ks -storepass longer7117 -keypass longer7117 -alias longer -keyalg RSA -keysize 2048 -validity 10950 -dname 'CN=Longer, OU=Galgame, O=Longer, L=Campus, ST=CN, C=CN' | Out-Null
}
$apk = Join-Path $Out 'LongerHeard-v1.0.apk'
if (Test-Path $apk) { Remove-Item $apk -Force }
& $apksigner sign --ks $ks --ks-pass pass:longer7117 --key-pass pass:longer7117 --v1-signing-enabled true --v2-signing-enabled true --out $apk $aligned
if ($LASTEXITCODE -ne 0) { throw 'apksigner 失败' }
Write-Host '[5/6] signed'
& $apksigner verify --print-certs $apk
& (Join-Path $bt 'zipalign.exe') -c -v 4 $apk
Write-Host '[6/6] aligned verify done'
Add-Type -AssemblyName System.IO.Compression.FileSystem
$z = [System.IO.Compression.ZipFile]::OpenRead($apk)
$z.Entries | Select-Object -ExpandProperty FullName | Sort-Object | ForEach-Object { Write-Host ('  entry: ' + $_) }
$z.Dispose()
Write-Host ('APK OK  ' + $apk + '  ' + [math]::Round((Get-Item $apk).Length/1MB,2) + ' MB')
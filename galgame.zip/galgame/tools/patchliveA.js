const fs=require('fs');
const P='D:\\3333\\7117\\galgame\\tools\\live.js';
let s=fs.readFileSync(P,'utf8');
const bad = s.split('\n')[93];
const good = "        const b = JSON.parse(await ex('JSON.stringify((function(){var q=document.querySelectorAll(\".choice\");var i=Math.min(' + CHOICE_IDX + ',q.length-1);return q[i].getBoundingClientRect();})())'));";
const lines=s.split('\n');
lines[93]=good;
fs.writeFileSync(P,lines.join('\n'),'utf8');
console.log('patched line 94');

const fs=require('fs');
const ROOT='D:\\3333\\7117\\galgame\\';
const SRC=ROOT+'src\\';
const order=['svg.js','art.js','audio.js','script0.js','script1.js','script2.js','engine.js'];
let h=fs.readFileSync(SRC+'index.html','utf8');
h=h.replace('<link rel="stylesheet" href="style.css"/>','<style>\n'+fs.readFileSync(SRC+'style.css','utf8')+'\n</style>');
let code=order.map(f=>fs.readFileSync(SRC+f,'utf8')).join('\n\n');
code+="\nvar SCRIPT=[].concat(SCRIPT_0,SCRIPT_1,SCRIPT_2);\nwindow.__S=SCRIPT;\nwindow.__TR=[];\nGame.boot({script:SCRIPT,title:META_TITLE,musiclist:META_MUSIC,cglist:META_CG,version:'1.0'});\n";
h=h.replace('</body>','<script>\n'+code+'\n</script>\n</body>');
fs.writeFileSync(ROOT+'preview\\_instr.html',h,'utf8');
// 专用 probe：自己循环点击，每 150ms 记录 idx
const probe=[
"window.__L=[];",
"function pc(){var el=document.elementFromPoint(700,700)||document.body;",
" ['mousedown','mouseup','click'].forEach(function(t){el.dispatchEvent(new MouseEvent(t,{bubbles:true,cancelable:true,clientX:700,clientY:700,view:window,button:0}));});}",
"function choose(){var cl=document.getElementById('choice-layer');if(cl.classList.contains('on')){var e=cl.querySelectorAll('.choice');if(e.length){e[0].click();return 'CH';}}return '';}",
"function loop(i){",
" var G=Game.state;var tag=choose();",
" if(!tag){pc();}",
" var n=window.__S[G.idx];var d=(n&&n.label)?('L:'+n.label):((n&&n.t)||'say');",
" window.__L.push(G.idx+':'+d+(tag?'*':''));",
" if(window.__L.length<70){setTimeout(function(){loop(i+1);},150);}else{document.title='TRACE='+window.__L.join(' ');}",
"}",
"window.addEventListener('load',function(){setTimeout(function(){var b=document.querySelector('.t-btn.primary');if(b)b.click();setTimeout(function(){var o=document.getElementById('name-ok');if(o)o.click();setTimeout(function(){loop(0);},400);},200);},300);});"
].join("\n");
fs.writeFileSync(ROOT+'preview\\_trace2.html',h.replace('</body>','<'+'script>'+probe+'<'+'/script></body>'),'utf8');
console.log('ok');

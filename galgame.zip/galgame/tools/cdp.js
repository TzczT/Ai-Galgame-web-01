/* tools/cdp.js —— 用 CDP 打开游戏、自动推进、抓取控制台与最终状态 */
const { spawn } = require('child_process');
const http = require('http');
const EDGE = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';
const PORT = 9333;
const url = process.argv[2] || 'file:///D:/3333/7117/galgame/dist/index.html';
const maxMs = parseInt(process.argv[3] || '40000', 10);

function get(path) {
  return new Promise((res, rej) => {
    const req = http.get({ host: '127.0.0.1', port: PORT, path }, r => {
      let d = ''; r.on('data', c => d += c); r.on('end', () => res(d));
    });
    req.on('error', rej);
  });
}
const sleep = ms => new Promise(r => setTimeout(r, ms));

(async () => {
  const proc = spawn(EDGE, [
    '--headless=new', '--disable-gpu', '--remote-debugging-port=' + PORT,
    '--user-data-dir=' + require('os').tmpdir() + '\\edge-cdp-gal',
    '--no-first-run', '--window-size=1440,810', url
  ], { stdio: 'ignore' });
  let tabs = null;
  for (let i = 0; i < 60; i++) {
    await sleep(400);
    try {
      const j = JSON.parse(await get('/json/list'));
      if (j && j.length) { tabs = j; break; }
    } catch (e) { }
  }
  if (!tabs) { console.log('NO TABS'); proc.kill(); process.exit(1); }
  const page = tabs.find(t => t.type === 'page') || tabs[0];
  const WebSocket = require('ws');
  let ws;
  try { ws = new WebSocket(page.webSocketDebuggerUrl); } catch (e) { console.log('WS MODULE MISSING'); proc.kill(); process.exit(2); }
  let id = 0; const pending = new Map(); const logs = [];
  const send = (method, params) => new Promise((res) => { const i = ++id; pending.set(i, res); ws.send(JSON.stringify({ id: i, method, params: params || {} })); });
  ws.on('message', d => {
    const m = JSON.parse(d);
    if (m.id && pending.has(m.id)) { pending.get(m.id)(m.result); pending.delete(m.id); }
    else if (m.method === 'Runtime.consoleAPICalled') { logs.push('LOG ' + (m.params.args || []).map(a => a.value || a.description).join(' ')); }
    else if (m.method === 'Runtime.exceptionThrown') { logs.push('EXCEPTION ' + (m.params.exceptionDetails && m.params.exceptionDetails.text) + ' ' + ((m.params.exceptionDetails.exception || {}).description || '').slice(0, 200)); }
  });
  await new Promise(r => ws.on('open', r));
  await send('Runtime.enable'); await send('Page.enable');
  await sleep(1500);
  const ev = async (expr) => {
    const r = await send('Runtime.evaluate', { expression: expr, returnByValue: true, awaitPromise: true });
    return r && r.result ? r.result.value : undefined;
  };
  const out = [];
  out.push('TITLE=' + JSON.stringify(await ev('document.title')));
  out.push('hasGame=' + await ev('typeof Game + "/" + typeof ARTWORK + "/" + typeof SOUND'));
  out.push('errs=' + await ev('(window.__err||[]).length'));
  // 自动推进
  await ev('(function(){window.__ev=[];window.__cards=[];if(window.Game)Game.state.settings.speed=0;' +
    'window.__t=setInterval(function(){try{' +
    'var ec=document.getElementById("ending-card");if(ec&&ec.classList.contains("on")&&window.__cards.length<3){window.__cards.push(ec.textContent.replace(/\\s+/g," ").slice(0,26));}' +
    'var cl=document.getElementById("choice-layer");' +
    'if(cl&&cl.classList.contains("on")){var e=cl.querySelectorAll(".choice");if(e.length){e[0].click();window.__ev.push("choice@"+Game.state.idx);}}' +
    'else{var gs=document.getElementById("game-screen");if(gs&&gs.classList.contains("active"))gs.click();}' +
    'if(Game&&Game.state.idx>720){clearInterval(window.__t);window.__done=1;}' +
    '}catch(e){window.__ev.push("ERR:"+e.message);}},2);' +
    'setTimeout(function(){var b=document.querySelector(".t-btn.primary");if(b)b.click();var o=document.getElementById("name-ok");if(o)o.click();},100);' +
    '})()');
  for (let i = 0; i < maxMs / 500; i++) { await sleep(500); if (await ev('!!window.__done')) break; }
  out.push('cards=' + JSON.stringify(await ev('window.__cards')));
  out.push('events=' + JSON.stringify(await ev('(window.__ev||[]).slice(0,10)')));
  out.push('idx=' + await ev('Game.state.idx'));
  out.push('ending=' + await ev('JSON.stringify(Game.state.ending)'));
  out.push('flags=' + await ev('JSON.stringify(Game.state.flags)'));
  out.push('love=' + await ev('Game.state.love'));
  out.push('errsAfter=' + await ev('(window.__err||[]).length'));
  out.push('console=' + JSON.stringify(logs.slice(0, 12)));
  console.log(out.join('\n'));
  try { proc.kill(); } catch (e) { }
  process.exit(0);
})();

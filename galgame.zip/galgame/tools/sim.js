const fs=require('fs'),path=require('path'),vm=require('vm');
const ROOT='D:\\3333\\7117\\galgame';
const sandbox={console,window:{},document:{},localStorage:{getItem(){return null},setItem(){}}};sandbox.window=sandbox;sandbox.globalThis=sandbox;
vm.createContext(sandbox);
['svg.js','art.js','script0.js','script1.js','script2.js'].forEach(f=>vm.runInContext(fs.readFileSync(path.join(ROOT,'src',f),'utf8'),sandbox,{filename:f}));
const S=[].concat(sandbox.SCRIPT_0,sandbox.SCRIPT_1,sandbox.SCRIPT_2);
const L={};
S.forEach((n,i)=>{ if(n&&n.t==='label'&&n.label&&L[n.label]===undefined) L[n.label]=i; });
const labelIndex=name=>L[name]===undefined?-1:L[name];
console.log('duplicate label defs:', Object.keys(L).length, 'labels; ch1='+L.ch1+' ch2='+L.ch2+' ch3='+L.ch3+' c_after='+L.c_after+' d_poster='+L.d_poster+' final_lake='+L.final_lake+' end_normal='+L.end_normal);
console.log('jumps:', S.map((n,i)=>n&&n.t==='jump'?i+'->'+n.target:null).filter(Boolean).join(' '));
// 走一遍第一条选项后的路径
function walk(start, max){
  let idx=start, out=[], guard=0;
  while(guard++<max && idx>=0 && idx<S.length){
    const n=S[idx];
    if(!n){ out.push(idx+':EOF'); break; }
    if(n.t==='label'){ idx++; continue; }
    if(n.text!==undefined){ out.push(idx+':say'); idx++; if(out.length>max-2) break; continue; }
    if(n.t==='jump'){ const t=labelIndex(n.target); out.push(idx+':J->'+n.target+'='+t); idx=t; continue; }
    if(n.t==='chapter'){ out.push(idx+':chapter'); idx++; continue; }
    if(n.t==='choice'){ out.push(idx+':CHOICE'); break; }
    if(n.t==='ending'){ out.push(idx+':ENDING('+n.kind+')'); break; }
    idx++;
  }
  return out.join(' ');
}
console.log('FROM p_go(39):', walk(39, 90));
console.log('FROM 74:', walk(74, 12));
console.log('FROM ch2 label:', walk(L.ch2, 12));

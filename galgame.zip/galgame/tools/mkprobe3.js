const fs=require('fs');
let s=fs.readFileSync('D:\\3333\\7117\\galgame\\tools\\mkicon.js','utf8');
s=s.replace("    if(Math.hypot(dx,dy)<=rad) px(x,y,col[0],col[1],col[2],a);",
"    if(x===256&&y===300) console.log('HIT', dx, dy, rad, col, a, 'cond', Math.hypot(dx,dy)<=rad);\n    if(Math.hypot(dx,dy)<=rad) px(x,y,col[0],col[1],col[2],a);");
fs.writeFileSync('D:\\3333\\7117\\galgame\\tools\\probe3.js', s, 'utf8');
console.log('ok');

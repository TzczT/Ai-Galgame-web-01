const fs=require('fs');
const R='D:\\3333\\7117\\galgame\\src\\';
// 1) 把三条指向不存在目标的 jump 改为正确的分支标签
let s0=fs.readFileSync(R+'script0.js','utf8');
s0=s0.replace("{ t: 'jump', target: 'ch2' },\n\n  { t: 'label', label: 'b_report' },","{ t: 'jump', target: 'b_report' },\n\n  { t: 'label', label: 'b_report' },");
fs.writeFileSync(R+'script0.js',s0,'utf8');
console.log('script0 ch2 jumps left:', (s0.match(/target: 'ch2'/g)||[]).length);

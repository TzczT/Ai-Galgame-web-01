const fs=require('fs');
const P='D:\\3333\\7117\\galgame\\tools\\live.js';
let s=fs.readFileSync(P,'utf8');
s=s.replace("await sleep(25);","await sleep(110);");
s=s.replace("if (repeat > 400)","if (repeat > 80)");
fs.writeFileSync(P,s,'utf8');console.log('ok');

const fs=require('fs');
const t = [
"const S=8; const buf=Buffer.alloc(S*S*4);",
"function clamp255(v){ return v<0?0:(v>255?255:Math.round(v)); }",
"function px(x,y,r,g,b,a){ if(x<0||y<0||x>=S||y>=S)return; const i=(y*S+x)*4; const na=(a===undefined?255:a)/255; buf[i]=clamp255(buf[i]*(1-na)+r*na); buf[i+1]=clamp255(buf[i+1]*(1-na)+g*na); buf[i+2]=clamp255(buf[i+2]*(1-na)+b*na); buf[i+3]=255; }",
"buf[(3*S+3)*4]=10; buf[(3*S+3)*4+1]=20; buf[(3*S+3)*4+2]=30;",
"console.log('before', buf[(3*S+3)*4], buf[(3*S+3)*4+1], buf[(3*S+3)*4+2]);",
"px(3,3,246,240,224,1);",
"console.log('after ', buf[(3*S+3)*4], buf[(3*S+3)*4+1], buf[(3*S+3)*4+2]);",
"buf[(3*S+3)*4]=9;",
"console.log('direct', buf[(3*S+3)*4]);"
].join("\n");
fs.writeFileSync('D:\\3333\\7117\\galgame\\tools\\minipx.js', t, 'utf8');
console.log('ok');

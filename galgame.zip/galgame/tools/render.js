/* tools/render.js —— 用 Edge headless 把美术资源渲染成 PNG 供检查 */
const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');
const ROOT = path.resolve(__dirname, '..');
const SRC = path.join(ROOT, 'src');
const OUT = path.join(ROOT, 'preview');
if (!fs.existsSync(OUT)) fs.mkdirSync(OUT, { recursive: true });
const EDGE = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';
function read(p) { return fs.readFileSync(path.join(SRC, p), 'utf8'); }
const libs = [read('svg.js'), read('art.js')].join('\n');

const target = process.argv[2] || 'sheet';
const tiles = [];
if (target === 'sheet') {
  ['seat', 'rec', 'food', 'snow', 'autumn', 'autumn2', 'lib', 'studio', 'road', 'canteen', 'field', 'lake', 'roof', 'hall', 'title', 'classroom', 'archive', 'dorm', 'balcony', 'snowRoad', 'repair', 'libSeat'].forEach(k => tiles.push({ k, svg: 'ARTWORK.get("' + k + '")' }));
} else if (target === 'sprite') {
  ['calm', 'serious', 'smile', 'troubled', 'solemn'].forEach(e => tiles.push({ k: 'sp_' + e, svg: '(function(){var s=ARTWORK.bust("' + e + '");return "<svg xmlns=\\"http://www.w3.org/2000/svg\\" viewBox=\\"140 0 700 1000\\">"+s+"</svg>";})()' }));
}
const cols = target === 'sprite' ? 5 : 4;
const cellW = target === 'sprite' ? 300 : 400, cellH = target === 'sprite' ? 430 : 235;
const rows = Math.ceil(tiles.length / cols);
const body = tiles.map(function (t, i) {
  const x = (i % cols) * cellW, y = Math.floor(i / cols) * cellH;
  return '<div class="cell" style="left:' + x + 'px;top:' + y + 'px;width:' + cellW + 'px;height:' + cellH + 'px"><div class="art" data-key="' + t.k + '"></div><div class="cap">' + t.k + '</div></div>';
}).join('\n');
const page = '<!DOCTYPE html><html><head><meta charset="utf-8"><style>' +
  'body{margin:0;background:#2a2724;font-family:sans-serif}' +
  '.wrap{position:relative;width:' + (cols * cellW) + 'px;height:' + (rows * cellH) + 'px}' +
  '.cell{position:absolute;box-sizing:border-box;border:1px solid #555}' +
  '.cell .art{position:absolute;inset:0;overflow:hidden}.cell .art>svg{width:100%;height:100%;display:block}' +
  '.cap{position:absolute;left:0;bottom:0;background:rgba(0,0,0,.6);color:#ffd;font-size:13px;padding:2px 6px;z-index:5}' +
  '</style></head><body><div class="wrap">' + body + '</div>' +
  '<script>' + libs + '<\/script>' +
  '<script>' + tiles.map(function (t, i) {
    return 'document.querySelectorAll(".art")[' + i + '].innerHTML=' + t.svg + ';';
  }).join('\n') + '<\/script></body></html>';

const pagePath = path.join(OUT, '_page.html');
fs.writeFileSync(pagePath, page, 'utf8');
const shot = path.join(OUT, (target === 'sprite' ? 'sprites' : 'scenes') + '.png');
const args = ['--headless=new', '--disable-gpu', '--hide-scrollbars', '--force-device-scale-factor=1',
  '--virtual-time-budget=3000', '--window-size=' + (cols * cellW) + ',' + (rows * cellH),
  '--screenshot=' + shot, 'file:///' + pagePath.replace(/\\/g, '/')];
const r = spawnSync(EDGE, args, { encoding: 'utf8', timeout: 120000 });
console.log('exit', r.status, 'shot', shot, fs.existsSync(shot) ? fs.statSync(shot).size + ' bytes' : 'MISSING');
if (r.stderr) console.log(String(r.stderr).split('\n').slice(-4).join('\n'));

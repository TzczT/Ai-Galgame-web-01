const fs=require('fs'),zlib=require('zlib');
function decode(file){
  const b=fs.readFileSync(file); let o=8, idat=[];
  while(o<b.length){ const len=b.readUInt32BE(o); const t=b.slice(o+4,o+8).toString('ascii');
    if(t==='IDAT') idat.push(b.slice(o+8,o+8+len));
    if(t==='IHDR'){ var W=b.readUInt32BE(o+8), H=b.readUInt32BE(o+12); }
    o+=12+len; }
  const raw=zlib.inflateSync(Buffer.concat(idat));
  return {W:W,H:H,raw:raw};
}
const r=decode('D:\\3333\\7117\\galgame\\preview\\icon.png');
const S=r.W;
function P(x,y){const i=y*(S*4+1)+1+x*4;return [r.raw[i],r.raw[i+1],r.raw[i+2],r.raw[i+3]];}
console.log('W,H=',r.W,r.H);
[['BG',20,20],['GLOW',380,120],['BODY',256,300],['REEL',180,315],['GOLD',256,382],['CENTER',256,350]].forEach(a=>console.log(a[0],P(a[1],a[2]).join(',')));

const fs=require('fs');
const s=fs.readFileSync('D:\\3333\\7117\\galgame\\tools\\mkicon.js','utf8');
const probe = s.replace('roundRect(256,300,330,210,26,[0xf6,0xf0,0xe0],1);',
  'roundRect(256,300,330,210,26,[0xf6,0xf0,0xe0],1);\nconsole.log("AFTER-BODY", buf[(300*S+256)*4], buf[(300*S+256)*4+1], buf[(300*S+256)*4+2]);');
fs.writeFileSync('D:\\3333\\7117\\galgame\\tools\\probe2.js', probe, 'utf8');
console.log('ok');

const fs=require('fs');
const ROOT='D:\\3333\\7117\\galgame\\';
const SRC=ROOT+'src\\';
const order=['svg.js','art.js','audio.js','script0.js','script1.js','script2.js','engine.js'];
let h=fs.readFileSync(SRC+'index.html','utf8');
const css=fs.readFileSync(SRC+'style.css','utf8');
h=h.replace('<link rel="stylesheet" href="style.css"/>','<style>\n'+css+'\n</style>');
let js2=order.map(f=>fs.readFileSync(SRC+f,'utf8')).join('\n\n');
js2+="\nvar SCRIPT=[].concat(SCRIPT_0,SCRIPT_1,SCRIPT_2);\nwindow.__S=SCRIPT;\nGame.boot({script:SCRIPT,title:META_TITLE,musiclist:META_MUSIC,cglist:META_CG,version:'1.0'});\n";
h=h.replace('</body>','<script>\n'+js2+'\n</script>\n</body>');
fs.writeFileSync(ROOT+'dist/index.html',h,'utf8');

const probe = [
"try{localStorage.clear();}catch(e){}",
"window.__log=[];var lastIdx=-1,lastEng=-1,stuck=0;",
"function tick(){",
" var G=Game.state; var gs=document.getElementById('game-screen').classList.contains('active');",
" if(G.clicks!==lastEng){",
"   if(lastIdx>=0){var d=G.idx-lastIdx; if(d>0){window.__log.push(lastIdx+'>'+G.idx);}else{stuck++;window.__log.push('STUCK@'+G.idx);}}",
"   lastIdx=G.idx; lastEng=G.clicks;",
" }",
" document.title='P:idx='+G.idx+':eng='+(G.clicks||0)+':stuck='+stuck+':lock='+(G.endingLock?'1':'0')+':txt='+document.getElementById('text').textContent.slice(0,12)+':log='+window.__log.slice(-8).join(',')+':act='+gs;",
" setTimeout(tick,200);",
"}",
"function boot(){var b=document.querySelector('.t-btn.primary');if(b)b.click();var ok=document.getElementById('name-ok');if(ok)ok.click();setTimeout(tick,300);}",
"window.addEventListener('load',function(){setTimeout(boot,200);});"
].join("\n");
fs.writeFileSync(ROOT+'preview\\_rt.html', h.replace('</body>', '<'+'script>'+probe+'<'+'/script></body>'), 'utf8');

const auto = [
"try{localStorage.clear();}catch(e){}",
"window.__err=[];window.addEventListener('error',function(e){window.__err.push(String(e.message))});",
"var f=0,lastIdx=-1,stuckAt='';function step(){f++;var G=Game.state;",
" var gs=document.getElementById('game-screen'),cl=document.getElementById('choice-layer'),cc=document.getElementById('chapter-card'),ec=document.getElementById('ending-card');",
" if(cl.classList.contains('on')){var e=cl.querySelectorAll('.choice');if(e.length)e[0].click();}",
" else if(!ec.classList.contains('on')&&!cc.classList.contains('on')&&gs.classList.contains('active'))gs.click();",
" if(lastIdx===G.idx&&!ec.classList.contains('on')&&!cc.classList.contains('on')&&!cl.classList.contains('on')&&G.clicks>80&&!stuckAt){stuckAt='STUCK@idx='+G.idx+':txt='+document.getElementById('text').textContent.slice(0,18)+':lock='+(G.endingLock?1:0)+':total='+window.__S.length;}",
" lastIdx=G.idx;",
" if(f>20000){document.title='A:'+(stuckAt||('OK end='+G.idx))+' err='+window.__err.length;return;}",
" setTimeout(step,4);}",
"window.addEventListener('load',function(){setTimeout(function(){Game.state.settings.speed=0;var b=document.querySelector('.t-btn.primary');if(b)b.click();var ok=document.getElementById('name-ok');if(ok)ok.click();setTimeout(step,120);},150);});"
].join("\n");
fs.writeFileSync(ROOT+'preview\\_auto3.html', h.replace('</body>', '<'+'script>'+auto+'<'+'/script></body>'), 'utf8');
console.log('harness ok');

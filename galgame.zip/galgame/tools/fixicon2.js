const fs=require('fs');
const P='D:\\3333\\7117\\galgame\\tools\\mkicon.js';
let s=fs.readFileSync(P,'utf8');
// alpha 归一化：0..1 与 0..255 都能用
s=s.replace("function px(x,y,r,g,b,a){ if(x<0||y<0||x>=S||y>=S)return; const i=(y*S+x)*4; const na=(a===undefined?255:a)/255;",
            "function px(x,y,r,g,b,a){ if(x<0||y<0||x>=S||y>=S)return; const i=(y*S+x)*4; var av=(a===undefined?1:a); if(av>1) av=av/255; const na=av;");
fs.writeFileSync(P,s,'utf8');
console.log('alpha fixed:', s.indexOf('if(av>1)')>0);

/* ===========================================================
 *  svg.js —— 水彩渲染底层库
 *  生成真正的 SVG（湿边 / 纸纹 / 晕染 / 颗粒），全部离线程序化绘制
 * =========================================================== */
var ART = (function () {

  // ---------- 随机 ----------
  function mulberry32(a) {
    return function () {
      a |= 0; a = a + 0x6D2B79F5 | 0;
      var t = Math.imul(a ^ a >>> 15, 1 | a);
      t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
      return ((t ^ t >>> 14) >>> 0) / 4294967296;
    };
  }
  function makeRnd(seed) {
    var r = mulberry32(seed >>> 0);
    return {
      n: r,
      rng: function (a, b) { return a + (b - a) * r(); },
      int: function (a, b) { return Math.floor(a + (b - a + 1) * r()); },
      pick: function (arr) { return arr[Math.floor(r() * arr.length) % arr.length]; },
      sign: function () { return r() < 0.5 ? -1 : 1; }
    };
  }
  function hashStr(s) { var h = 2166136261; for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }

  // ---------- 数值 ----------
  function round2(v) { return Math.round(v * 100) / 100; }
  function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
  function lerp(a, b, t) { return a + (b - a) * t; }
  function mixHex(h1, h2, t) {
    function p(h) { h = h.replace('#', ''); if (h.length === 3) h = h[0] + h[0] + h[1] + h[1] + h[2] + h[2]; return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)]; }
    var a = p(h1), b = p(h2);
    function hex(v) { v = Math.round(clamp(v, 0, 255)).toString(16); return v.length === 1 ? '0' + v : v; }
    return '#' + hex(lerp(a[0], b[0], t)) + hex(lerp(a[1], b[1], t)) + hex(lerp(a[2], b[2], t));
  }
  function shade(hex, t) { // t>0 变亮，t<0 变深
    return t >= 0 ? mixHex(hex, '#ffffff', t) : mixHex(hex, '#1a1712', -t);
  }
  function alpha(hex, a) {
    var m = /^#?([0-9a-f]{6})$/i.exec(hex); if (!m) return hex;
    return 'rgba(' + parseInt(m[1].slice(0, 2), 16) + ',' + parseInt(m[1].slice(2, 4), 16) + ',' + parseInt(m[1].slice(4, 6), 16) + ',' + round2(a) + ')';
  }

  // ---------- 路径 ----------
  function pt(x, y) { return [x, y]; }
  function polyPath(pts, close) {
    var d = 'M' + round2(pts[0][0]) + ' ' + round2(pts[0][1]);
    for (var i = 1; i < pts.length; i++) d += 'L' + round2(pts[i][0]) + ' ' + round2(pts[i][1]);
    return d + (close !== false ? 'Z' : '');
  }
  function smoothPath(pts, close) {
    if (pts.length < 3) return polyPath(pts, close);
    var d = 'M' + round2(pts[0][0]) + ',' + round2(pts[0][1]);
    for (var i = 0; i < pts.length - 1; i++) {
      var p0 = pts[i === 0 ? 0 : i - 1], p1 = pts[i], p2 = pts[i + 1], p3 = pts[i + 2 >= pts.length ? pts.length - 1 : i + 2];
      var c1x = p1[0] + (p2[0] - p0[0]) / 6, c1y = p1[1] + (p2[1] - p0[1]) / 6;
      var c2x = p2[0] - (p3[0] - p1[0]) / 6, c2y = p2[1] - (p3[1] - p1[1]) / 6;
      d += 'C' + round2(c1x) + ',' + round2(c1y) + ' ' + round2(c2x) + ',' + round2(c2y) + ' ' + round2(p2[0]) + ',' + round2(p2[1]);
    }
    return close === false ? d : d + 'Z';
  }
  function circlePath(cx, cy, r) { return 'M' + round2(cx - r) + ',' + round2(cy) + 'a' + round2(r) + ',' + round2(r) + ' 0 1 0 ' + round2(2 * r) + ',0a' + round2(r) + ',' + round2(r) + ' 0 1 0 ' + round2(-2 * r) + ',0Z'; }
  function ellipsePath(cx, cy, rx, ry) { return 'M' + round2(cx - rx) + ',' + round2(cy) + 'a' + round2(rx) + ',' + round2(ry) + ' 0 1 0 ' + round2(2 * rx) + ',0a' + round2(rx) + ',' + round2(ry) + ' 0 1 0 ' + round2(-2 * rx) + ',0Z'; }

  // 不规则墨团（手绘感）
  function blobPath(cx, cy, rx, ry, rnd, wobble) {
    var n = rnd.int(9, 13), pts = [], i;
    wobble = wobble === undefined ? 0.11 : wobble;
    for (i = 0; i < n; i++) {
      var a = i / n * Math.PI * 2;
      var k = 1 + Math.sin(a * 3 + rnd.n() * 6) * wobble * 0.6 + (rnd.n() - 0.5) * wobble;
      pts.push([cx + Math.cos(a) * rx * k, cy + Math.sin(a) * ry * k]);
    }
    return smoothPath(pts, true);
  }
  // 手绘直线（微微抖）
  function skPath(x1, y1, x2, y2, rnd, wob) {
    wob = wob === undefined ? 2.2 : wob;
    var dx = x2 - x1, dy = y2 - y1, len = Math.hypot(dx, dy);
    var n = Math.max(2, Math.min(14, Math.round(len / 70)));
    var nx = -dy / (len || 1), ny = dx / (len || 1), pts = [];
    for (var i = 0; i <= n; i++) {
      var t = i / n, off = (rnd.n() - 0.5) * wob * (i === 0 || i === n ? 0.35 : 1);
      pts.push([x1 + dx * t + nx * off, y1 + dy * t + ny * off]);
    }
    return smoothPath(pts, false);
  }

  // ---------- 图层 ----------
  function Layer() { this.parts = []; }
  Layer.prototype.p = function (s) { this.parts.push(s); return this; };
  Layer.prototype.path = function (d, o) {
    o = o || {};
    this.parts.push('<path d="' + d + '" fill="' + (o.fill || 'none') + '"' +
      (o.stroke ? ' stroke="' + o.stroke + '" stroke-width="' + (o.sw || 1.4) + '"' : '') +
      (o.lc ? ' stroke-linecap="' + o.lc + '"' : '') + (o.lj ? ' stroke-linejoin="' + o.lj + '"' : '') +
      (o.op !== undefined ? ' opacity="' + o.op + '"' : '') +
      (o.dash ? ' stroke-dasharray="' + o.dash + '"' : '') +
      (o.fo ? ' fill-rule="' + o.fo + '"' : '') + '/>');
    return this;
  };
  Layer.prototype.rect = function (x, y, w, h, o) {
    o = o || {}; var d = 'M' + round2(x) + ',' + round2(y) + 'h' + round2(w) + 'v' + round2(h) + 'h' + round2(-w) + 'Z';
    return this.path(d, o);
  };
  Layer.prototype.ellipse = function (cx, cy, rx, ry, o) { return this.path(ellipsePath(cx, cy, rx, ry), o || {}); };
  Layer.prototype.circle = function (cx, cy, r, o) { return this.path(circlePath(cx, cy, r), o || {}); };
  Layer.prototype.blob = function (cx, cy, rx, ry, rnd, o) {
    o = o || {}; return this.path(blobPath(cx, cy, rx, ry, rnd, o.wobble), o);
  };
  Layer.prototype.sk = function (x1, y1, x2, y2, rnd, o) {
    o = o || {}; return this.path(skPath(x1, y1, x2, y2, rnd, o.wob), o);
  };
  Layer.prototype.text = function (x, y, s, o) {
    o = o || {};
    return this.p('<text x="' + round2(x) + '" y="' + round2(y) + '" font-size="' + (o.size || 24) + '" font-family="' +
      (o.family || "'Noto Serif SC','Songti SC','SimSun',serif") + '" fill="' + (o.fill || '#3a3730') + '"' +
      (o.sw ? ' stroke="' + o.sw + '" stroke-width="' + (o.sww || 0.6) + '"' : '') +
      (o.anchor ? ' text-anchor="' + o.anchor + '"' : '') +
      (o.op !== undefined ? ' opacity="' + o.op + '"' : '') +
      (o.ls ? ' letter-spacing="' + o.ls + '"' : '') + '>' + esc(s) + '</text>');
  };
  Layer.prototype.raw = function (s) { this.parts.push(s); return this; };
  Layer.prototype.g = function (attrs, inner) {
    this.parts.push('<g ' + attrs + '>' + inner + '</g>'); return this;
  };
  Layer.prototype.markup = function () { return this.parts.join(''); };

  function esc(s) { return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }

  // 水彩块：湿边 + 晕染 + 内部渐变
  function wetBlob(d, c1, c2, seed, opt) {
    opt = opt || {};
    var w = opt.w === undefined ? 7 : opt.w;          // 湿边宽度
    var f = opt.f === undefined ? 0.22 : opt.f;        // 晕染扩散
    var soft = opt.soft === undefined ? 0.4 : opt.soft;
    var iid = 'w' + (seed >>> 0).toString(36);
    return '<g>' +
      '<path d="' + d + '" fill="url(#grad-' + iid + ')" opacity="' + (opt.op === undefined ? 1 : opt.op) + '"/>' +
      '<path d="' + d + '" fill="none" stroke="' + alpha(c2, 0.5) + '" stroke-width="' + (w * 0.5) + '" opacity=".42" filter="url(#soft-' + (seed % 9) + ')"/>' +
      '<path d="' + d + '" fill="none" stroke="' + alpha(shade(c2, -0.25), 0.5) + '" stroke-width="' + (w * 0.22) + '" opacity=".3"/>' +
      '<path d="' + d + '" fill="' + alpha(c1, 0.1) + '" filter="url(#fuzz)"/>' +
      '</g>' +
      '<defs><radialGradient id="grad-' + iid + '" cx="38%" cy="30%" r="78%">' +
      '<stop offset="0%" stop-color="' + alpha(shade(c1, 0.12), 0.72) + '"/>' +
      '<stop offset="62%" stop-color="' + alpha(c1, 0.6 * (1 - soft * 0.35)) + '"/>' +
      '<stop offset="100%" stop-color="' + alpha(c2, 0.66) + '"/>' +
      '</radialGradient></defs>';
  }

  // ---------- 纸张与滤镜 ----------
  function paperDefs(w, h, seed) {
    var r = makeRnd(seed);
    return '<filter id="paper" x="-2%" y="-2%" width="104%" height="104%">' +
      '<feTurbulence type="fractalNoise" baseFrequency="' + (0.9 + r.n() * 0.2).toFixed(3) + '" numOctaves="4" seed="' + (seed % 900) + '" result="n"/>' +
      '<feColorMatrix in="n" type="saturate" values="0" result="g"/>' +
      '<feComponentTransfer in="g"><feFuncA type="linear" slope="0.13" intercept="0"/></feComponentTransfer>' +
      '</filter>' +
      '<filter id="grain">' +
      '<feTurbulence type="fractalNoise" baseFrequency="0.62" numOctaves="3" seed="' + ((seed + 7) % 900) + '" result="t"/>' +
      '<feColorMatrix in="t" type="saturate" values="0" result="tg"/>' +
      '<feComponentTransfer in="tg"><feFuncA type="linear" slope="0.055" intercept="0"/></feComponentTransfer>' +
      '</filter>' +
      '<filter id="fuzz" x="-25%" y="-25%" width="150%" height="150%"><feGaussianBlur stdDeviation="' + (w * 0.008).toFixed(1) + '"/></filter>' +
      '<filter id="soft" x="-20%" y="-20%" width="140%" height="140%"><feGaussianBlur stdDeviation="6"/></filter>' +
      '<filter id="soft2" x="-20%" y="-20%" width="140%" height="140%"><feGaussianBlur stdDeviation="14"/></filter>' +
      '<filter id="soft3" x="-20%" y="-20%" width="140%" height="140%"><feGaussianBlur stdDeviation="26"/></filter>' +
      '<filter id="soft4" x="-20%" y="-20%" width="140%" height="140%"><feGaussianBlur stdDeviation="40"/></filter>';
  }
  function paperOverlay(w, h) {
    return '<rect x="0" y="0" width="' + w + '" height="' + h + '" fill="#f7f2e6" filter="url(#paper)" opacity="0.85" style="mix-blend-mode:multiply"/>' +
      '<rect x="0" y="0" width="' + w + '" height="' + h + '" fill="#fffdf7" filter="url(#grain)" opacity="0.5"/>';
  }

  // ---------- 场景（world）----------
  function Scene(seed) {
    this.w = 1600; this.h = 900; this.seed = seed >>> 0;
    this.rnd = makeRnd(this.seed);
    this.defs = []; this.layers = []; this.cur = null;
  }
  Scene.prototype.layer = function () { this.cur = new Layer(); this.layers.push(this.cur); return this.cur; };
  Scene.prototype.top = function () { return this.layers.length ? this.layers[this.layers.length - 1] : null; };
  Scene.prototype.pushDef = function (s) { this.defs.push(s); return this; };
  // 天空/大背景渐变
  Scene.prototype.sky = function (c1, c2, opt) {
    opt = opt || {};
    var id = 'sky' + (this.seed % 9999) + this.defs.length;
    this.pushDef('<linearGradient id="' + id + '" x1="0" y1="0" x2="' + (opt.dx === undefined ? 0 : opt.dx) + '" y2="' + (opt.dy === undefined ? 1 : opt.dy) + '">' +
      '<stop offset="0%" stop-color="' + c1 + '"/><stop offset="' + (opt.mid === undefined ? 55 : opt.mid) + '%" stop-color="' + (opt.cm || mixHex(c1, c2, 0.5)) + '"/><stop offset="100%" stop-color="' + c2 + '"/></linearGradient>');
    var l = this.layer();
    l.rect(0, 0, this.w, this.h, { fill: 'url(#' + id + ')' });
    // 水彩天空的云絮
    var r = this.rnd;
    for (var i = 0; i < (opt.clouds === undefined ? 7 : opt.clouds); i++) {
      var cx = r.rng(0, this.w), cy = r.rng(0, this.h * 0.62), rx = r.rng(120, 420), ry = r.rng(26, 90);
      var col = mixHex(c1, opt.cloudColor || '#ffffff', 0.6);
      l.raw(wetBlob(blobPath(cx, cy, rx, ry, r, 0.18), col, mixHex(col, '#dfe3ea', 0.5), (this.seed + i * 31) >>> 0, { w: 3, f: 0.5, op: r.rng(0.1, 0.26) }));
    }
    return l;
  };
  // 竖直渐晕
  Scene.prototype.vignette = function (color, op) {
    var l = this.layer();
    var id = 'vig' + (this.seed % 9999) + this.defs.length;
    this.pushDef('<radialGradient id="' + id + '" cx="50%" cy="46%" r="72%"><stop offset="55%" stop-color="' + alpha(color || '#000000', 0) + '"/><stop offset="100%" stop-color="' + alpha(color || '#000000', op === undefined ? 0.3 : op) + '"/></radialGradient>');
    l.rect(0, 0, this.w, this.h, { fill: 'url(#' + id + ')' });
    return l;
  };
  Scene.prototype.done = function (opt) {
    opt = opt || {};
    var s = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + this.w + ' ' + this.h + '" width="' + this.w + '" height="' + this.h + '" preserveAspectRatio="xMidYMid slice">';
    s += '<defs>' + paperDefs(this.w, this.h, this.seed) + this.defs.join('') + '</defs>';
    s += this.layers.map(function (l) { return l.markup(); }).join('');
    if (opt.paper !== false) s += paperOverlay(this.w, this.h);
    s += '</svg>';
    return s;
  };

  return {
    makeRnd: makeRnd, hashStr: hashStr, Scene: Scene, Layer: Layer,
    mixHex: mixHex, shade: shade, alpha: alpha, lerp: lerp, clamp: clamp, round2: round2, paperOverlay: paperOverlay,
    polyPath: polyPath, smoothPath: smoothPath, ellipsePath: ellipsePath, circlePath: circlePath,
    blobPath: blobPath, skPath: skPath, wetBlob: wetBlob, esc: esc, pt: pt
  };
})();

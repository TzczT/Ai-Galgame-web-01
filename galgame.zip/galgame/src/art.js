var ARTWORK = (function () {
  var A = ART;
  var R = A.makeRnd, S = A.shade, M = A.mixHex, AL = A.alpha;

  var PAL = {
    navy: '#2b3a63', navyD: '#1d2742', navyL: '#4a5c8c',
    gold: '#e0b84c', goldD: '#b9882c', cream: '#f6efdd', paper: '#faf6ec',
    ink: '#2e2b26', skin: '#f2d9c6', skinS: '#e0b79c',
    hair: '#2c2622', hairL: '#544a43',
    wood: '#a97f52', woodD: '#6f5132', leaf: '#7d9a5f', leafD: '#4d6a3c',
    sky: '#bcd4e6', skyD: '#8fb0cc', dusk: '#e9c9a8', snow: '#eef3f7',
    stone: '#b9b6ae', stoneD: '#8d8a83', teal: '#5f8f8a', plum: '#8a5a63'
  };

  /* ---------- 通用小物件 ---------- */
  function leafSpray(l, x, y, len, ang, rnd, col, op) {
    var n = 5 + Math.floor(rnd.n() * 4);
    for (var i = 0; i < n; i++) {
      var a = ang + (i / n) * 1.5 - 0.75 + rnd.rng(-0.2, 0.2);
      var L = len * rnd.rng(0.6, 1.15);
      var ex = x + Math.cos(a) * L, ey = y + Math.sin(a) * L;
      l.path(A.skPath(x, y, ex, ey, rnd, 1.4), { stroke: S(col, -0.2), sw: 1.6, op: op === undefined ? .8 : op, lc: 'round' });
      l.raw(A.wetBlob(A.blobPath((x + ex) / 2, (y + ey) / 2, L * 0.42, L * 0.2, rnd, 0.3), col, S(col, -0.25), (rnd.int(1, 1e6)) >>> 0, { w: 3, f: 0.4, op: (op === undefined ? .5 : op * .55) }));
    }
  }

  function bigTree(l, x, groundY, rnd, opt) {
    opt = opt || {};
    var trunkW = opt.w || 78, col = opt.col || PAL.woodD;
    var topY = opt.topY || 40;
    // 树干：多边形 + 分叉
    var ptsL = [], ptsR = [];
    var seg = 9;
    for (var i = 0; i <= seg; i++) {
      var t = i / seg, y = A.lerp(groundY, topY, t);
      var w = trunkW * (1 - t * 0.55) * (1 + Math.sin(t * 5 + 1) * 0.08) + rnd.rng(-4, 4);
      var bend = Math.sin(t * 2.2) * (opt.bend || 14);
      ptsL.push([x - w / 2 + bend, y]); ptsR.push([x + w / 2 + bend, y]);
    }
    var d = A.polyPath(ptsL.concat(ptsR.reverse()), true);
    l.raw(A.wetBlob(d, S(col, 0.06), col, (rnd.int(1, 1e6)) >>> 0, { w: 6, f: 0.25 }));
    // 树皮竖纹
    for (var k = 0; k < 16; k++) {
      var tt = rnd.n(); var yy1 = A.lerp(groundY, topY, tt), yy2 = yy1 - rnd.rng(30, 130);
      var xx = x + rnd.rng(-trunkW * 0.42, trunkW * 0.42) + Math.sin(tt * 2.2) * (opt.bend || 14);
      l.path(A.skPath(xx, yy1, xx + rnd.rng(-6, 6), yy2, rnd, 2.4), { stroke: AL(S(col, -0.4), rnd.rng(.12, .3)), sw: rnd.rng(1.1, 3), lc: 'round' });
    }
    // 枝
    for (var b = 0; b < 4; b++) {
      var by = A.lerp(groundY, topY, rnd.rng(0.25, 0.92));
      var bx = x + Math.sin((groundY - by) / (groundY - topY) * 2.2) * (opt.bend || 14);
      var dir = rnd.sign(), bl = rnd.rng(120, 240);
      var ex = bx + dir * bl, ey = by - rnd.rng(30, 120);
      l.path(A.skPath(bx, by, ex, ey, rnd, 3), { stroke: col, sw: rnd.rng(6, 12), op: .75, lc: 'round' });
    }
    // 树冠
    if (opt.crown !== false) {
      for (var c = 0; c < 14; c++) {
        var cx = x + rnd.rng(-260, 260), cy = topY + rnd.rng(-40, 190);
        var cc = M(PAL.leaf, rnd.n() < .5 ? '#b9c98f' : '#5d7a44', rnd.n() * .6);
        l.raw(A.wetBlob(A.blobPath(cx, cy, rnd.rng(90, 190), rnd.rng(50, 105), rnd, .3), cc, S(cc, -0.2), (rnd.int(1, 1e6)) >>> 0, { w: 4, f: 0.5, op: rnd.rng(.2, .45) }));
      }
    }
    return l;
  }

  function stoneWall(l, x, y, w, h, rnd, col) {
    col = col || PAL.stone;
    l.raw(A.wetBlob(A.polyPath([[x, y], [x + w, y], [x + w, y + h], [x, y + h]]), S(col, .18), col, (rnd.int(1, 1e6)) >>> 0, { w: 5, f: 0.2, op: .95 }));
    // 石缝
    var rows = Math.max(2, Math.round(h / 90));
    for (var i = 1; i < rows; i++) {
      var yy = y + h * i / rows;
      l.path(A.skPath(x, yy, x + w, yy, rnd, 2), { stroke: AL(S(col, -0.45), .3), sw: 1.6 });
      for (var j = 0; j < 5; j++) {
        var xx = x + w * (j + .5) / 5 + rnd.rng(-30, 30);
        l.path(A.skPath(xx, yy, xx, yy + h / rows, rnd, 2), { stroke: AL(S(col, -0.45), .22), sw: 1.4 });
      }
    }
    // 斑驳
    for (var k = 0; k < 12; k++) {
      var px = rnd.rng(x, x + w), py = rnd.rng(y, y + h);
      l.raw(A.wetBlob(A.blobPath(px, py, rnd.rng(20, 70), rnd.rng(12, 40), rnd, .35), S(col, .3), col, (rnd.int(1, 1e6)) >>> 0, { w: 3, f: .5, op: rnd.rng(.08, .2) }));
    }
    return l;
  }

  function desk(l, x, y, w, h, rnd, col) {
    col = col || PAL.wood;
    var top = 16;
    l.raw(A.wetBlob(A.polyPath([[x, y], [x + w, y], [x + w, y + top], [x, y + top]]), S(col, .22), col, (rnd.int(1, 1e6)) >>> 0, { w: 4, f: .15 }));
    l.raw(A.wetBlob(A.polyPath([[x + 22, y + top], [x + w - 22, y + top], [x + w - 46, y + h], [x + 46, y + h]]), S(col, -0.18), S(col, -0.3), (rnd.int(1, 1e6)) >>> 0, { w: 4, f: .3, op: .9 }));
    return l;
  }

  function windowFrame(l, x, y, w, h, rnd, opt) {
    opt = opt || {};
    var g = opt.glow || '#fdf0cd';
    l.raw(A.wetBlob(A.polyPath([[x, y], [x + w, y], [x + w, y + h], [x, y + h]]), '#fdf3d8', '#e8d9ae', (rnd.int(1, 1e6)) >>> 0, { w: 6, f: .3, op: .75 }));
    var mull = opt.mull === undefined ? 3 : opt.mull;
    for (var i = 1; i < mull; i++) l.path(A.skPath(x + w * i / mull, y, x + w * i / mull, y + h, rnd, 1.6), { stroke: AL('#6b5a3e', .5), sw: 2.4 });
    l.path(A.skPath(x, y + h * .5, x + w, y + h * .5, rnd, 1.6), { stroke: AL('#6b5a3e', .4), sw: 2.2 });
    l.path(A.skPath(x, y, x + w, y, rnd, 1.2), { stroke: AL('#6b5a3e', .6), sw: 3 });
    // 光斑
    for (var k = 0; k < 5; k++) {
      l.raw(A.wetBlob(A.blobPath(x + rnd.rng(0, w), y + rnd.rng(0, h), rnd.rng(50, 170), rnd.rng(30, 90), rnd, .4), g, S(g, -0.1), (rnd.int(1, 1e6)) >>> 0, { w: 3, f: .6, op: rnd.rng(.1, .28) }));
    }
    return l;
  }

  function lightShaft(l, x, y, w, h, rnd, col, op) {
    col = col || '#fff3cf';
    l.raw(A.wetBlob(A.polyPath([[x, y], [x + w, y], [x + w * 1.5, y + h], [x - w * .3, y + h]]),
      col, S(col, -0.06), (rnd.int(1, 1e6)) >>> 0, { w: 3, f: .65, op: op === undefined ? .3 : op }));
    return l;
  }

  /* =========================================================
   *  场景
   * ========================================================= */
  var SCENES = {};

  // 图书馆四楼 靠窗
  SCENES.lib = function (st) {
    var r = st.rnd;
    st.sky('#f0e2c4', '#cbb894', { dx: .1, dy: 1, clouds: 8, cloudColor: '#fff6e0' });
    var l = st.layer();
    // 远处书架
    for (var b = 0; b < 4; b++) {
      var bx = 60 + b * 300, by = 150, bw = 250, bh = 560;
      l.raw(A.wetBlob(A.polyPath([[bx, by], [bx + bw, by], [bx + bw, by + bh], [bx, by + bh]]), '#9c7a52', '#6d5236', (100 + b) >>> 0, { w: 6, f: .2, op: .8 }));
      for (var s = 0; s < 5; s++) {
        var sy = by + 30 + s * 106;
        l.path(A.skPath(bx + 8, sy, bx + bw - 8, sy, r, 2), { stroke: AL('#4b3620', .4), sw: 3 });
        for (var k = 0; k < 12; k++) {
          var bkw = r.rng(9, 18), bkh = r.rng(44, 78), bkx = bx + 14 + k * (bw - 28) / 12;
          var bc = r.pick(['#8d4d42', '#4c6178', '#7a6a3f', '#5d5a4e', '#8a6f52', '#3f5a52']);
          l.raw(A.wetBlob(A.polyPath([[bkx, sy - bkh], [bkx + bkw, sy - bkh], [bkx + bkw, sy], [bkx, sy]]), S(bc, .16), bc, (r.int(1, 1e6)) >>> 0, { w: 3, f: .25, op: r.rng(.5, .8) }));
        }
      }
    }
    // 靠窗一侧：大窗
    var win = st.layer();
    windowFrame(win, 1020, 120, 520, 620, r, { mull: 3, glow: '#ffeec2' });
    // 窗外的树影
    for (var i = 0; i < 7; i++) {
      var cx = r.rng(1040, 1520), cy = r.rng(180, 640);
      win.raw(A.wetBlob(A.blobPath(cx, cy, r.rng(60, 150), r.rng(40, 110), r, .35), M(PAL.leaf, '#cfd8b0', .4), '#6f8850', (r.int(1, 1e6)) >>> 0, { w: 4, f: .5, op: r.rng(.12, .3) }));
    }
    // 地面
    var fl = st.layer();
    fl.raw(A.wetBlob(A.polyPath([[0, 700], [1600, 700], [1600, 900], [0, 900]]), '#c9a97a', '#9c7e56', 7, { w: 6, f: .25, op: .85 }));
    for (var j = 0; j < 9; j++) fl.path(A.skPath(0, 706 + j * 22, 1600, 700 + j * 24, r, 2), { stroke: AL('#6d5433', .16), sw: 1.4 });
    // 逆光光柱
    lightShaft(st.layer(), 1100, 130, 150, 640, r, '#fff2c9', .3);
    lightShaft(st.layer(), 1330, 140, 90, 620, r, '#ffeec2', .2);
    // 阅览桌与椅子
    var tb = st.layer();
    desk(tb, 150, 560, 620, 150, r);
    desk(tb, 830, 640, 480, 130, r);
    for (var c = 0; c < 3; c++) {
      var cxp = 230 + c * 200;
      tb.path(A.skPath(cxp, 720, cxp + 90, 720, r, 2), { stroke: '#6f5132', sw: 7, lc: 'round' });
      tb.path(A.skPath(cxp + 40, 720, cxp + 30, 800, r, 2), { stroke: '#6f5132', sw: 6, lc: 'round' });
      tb.path(A.skPath(cxp + 40, 720, cxp + 60, 800, r, 2), { stroke: '#6f5132', sw: 6, lc: 'round' });
      tb.path(A.skPath(cxp + 82, 700, cxp + 82, 600, r, 2), { stroke: '#6f5132', sw: 7, lc: 'round' });
    }
    // 桌上：台灯、钢笔、卡纸
    tb.raw(A.wetBlob(A.blobPath(250, 520, 46, 20, r, .2), '#3f6b52', '#254636', 21, { w: 4, f: .3 }));
    tb.path(A.skPath(240, 520, 262, 470, r, 2), { stroke: '#2f3f33', sw: 5, lc: 'round' });
    tb.raw(A.wetBlob(A.blobPath(268, 464, 30, 16, r, .2), '#7fa06a', '#3f6b52', 22, { w: 3, f: .4, op: .8 }));
    tb.raw(A.wetBlob(A.blobPath(520, 545, 90, 26, r, .18), '#fdf8ea', '#e4d8bc', 23, { w: 3, f: .25, op: .95 }));
    // 前排模糊桌（景深）
    var fz = st.layer();
    fz.raw('<g filter="url(#soft2)">' + new A.Layer().raw(A.wetBlob(A.polyPath([[0, 830], [520, 800], [560, 900], [0, 900]]), '#7b6141', '#57432c', 31, { w: 5, f: .3, op: .55 })).markup() + '</g>');
    // 浮尘
    var du = st.layer();
    for (var d2 = 0; d2 < 40; d2++) du.circle(r.rng(0, 1600), r.rng(80, 760), r.rng(1, 3.2), { fill: AL('#fff8e0', r.rng(.2, .7)) });
    st.vignette('#5b4a2e', .22);
    return st;
  };

  // 图书馆 · 空座位（CG 用，斜光特写）
  SCENES.libSeat = function (st) {
    var r = st.rnd;
    st.sky('#f6e7c6', '#b99f78', { dx: .2, dy: 1, clouds: 6, cloudColor: '#fff8e6' });
    lightShaft(st.layer(), 760, 60, 260, 760, r, '#fff4cf', .38);
    lightShaft(st.layer(), 1090, 80, 140, 740, r, '#ffedbb', .26);
    var bk = st.layer();
    stoneWall(bk, 0, 380, 700, 520, r, '#a98f66');
    var tb = st.layer();
    desk(tb, 300, 540, 1000, 200, r);
    // 摊开的书 + 借书卡
    var bk2 = st.layer();
    bk2.raw(A.wetBlob(A.polyPath([[520, 500], [700, 486], [706, 546], [524, 560]]), '#fdf9ec', '#e3d7ba', 41, { w: 4, f: .2, op: .95 }));
    bk2.raw(A.wetBlob(A.polyPath([[700, 486], [880, 500], [876, 562], [706, 546]]), '#fbf6e6', '#ddd0b0', 42, { w: 4, f: .2, op: .95 }));
    bk2.path(A.skPath(702, 486, 704, 548, r, 1.5), { stroke: AL('#a89madd', .0) });
    bk2.path(A.skPath(702, 486, 704, 548, r, 1.5), { stroke: '#c9bda0', sw: 3 });
    // 借书卡
    bk2.raw(A.wetBlob(A.polyPath([[742, 508], [856, 500], [862, 528], [748, 536]]), '#fefcf3', '#e8ddc4', 43, { w: 3, f: .12, op: .98 }));
    for (var i = 0; i < 5; i++) bk2.path(A.skPath(752, 512 + i * 5, 852, 508 + i * 5, r, 1.2), { stroke: AL('#8a7c5e', .35), sw: 1.2 });
    // 铅笔
    bk2.raw(A.wetBlob(A.polyPath([[600, 596], [736, 576], [742, 592], [606, 612]]), '#e9b45c', '#b8802c', 44, { w: 3, f: .15 }));
    bk2.path(A.skPath(742, 588, 766, 583, r, 1), { stroke: '#c8a06a', sw: 5, lc: 'round' });
    // 眼镜布 + 校徽
    bk2.raw(A.wetBlob(A.blobPath(960, 566, 46, 30, r, .22), '#cfe0e8', '#8fa9b6', 45, { w: 4, f: .35, op: .9 }));
    bk2.raw(A.wetBlob(A.blobPath(1052, 580, 17, 6, r, .1), S(PAL.gold, -.15), PAL.goldD, 46, { w: 3, f: .2 }));
    // 空椅子
    var ch = st.layer();
    ch.path(A.skPath(1080, 700, 1220, 690, r, 2), { stroke: '#6f5132', sw: 9, lc: 'round' });
    ch.path(A.skPath(1100, 700, 1086, 810, r, 2), { stroke: '#6f5132', sw: 8, lc: 'round' });
    ch.path(A.skPath(1200, 694, 1216, 806, r, 2), { stroke: '#6f5132', sw: 8, lc: 'round' });
    ch.path(A.skPath(1150, 690, 1152, 540, r, 2), { stroke: '#6f5132', sw: 9, lc: 'round' });
    ch.path(A.skPath(1152, 560, 1230, 556, r, 2), { stroke: '#6f5132', sw: 7, lc: 'round' });
    var du = st.layer();
    for (var d = 0; d < 46; d++) du.circle(r.rng(200, 1500), r.rng(100, 800), r.rng(1, 3.4), { fill: AL('#fffbe8', r.rng(.25, .8)) });
    st.vignette('#6b5636', .26);
    return st;
  };

  // 广播台 · 播音室
  SCENES.studio = function (st) {
    var r = st.rnd;
    st.sky('#6d6f74', '#4a4b50', { dx: 0, dy: 1, clouds: 4, cloudColor: '#9aa0a6' });
    var w = st.layer();
    // 吸音棉墙
    w.raw(A.wetBlob(A.polyPath([[0, 0], [1600, 0], [1600, 700], [0, 700]]), '#5c5548', '#3f3a32', 55, { w: 8, f: .2, op: .95 }));
    for (var i = 0; i < 16; i++) {
      for (var j = 0; j < 6; j++) {
        var x = 20 + i * 100, y = 20 + j * 96;
        var c = ((i + j) % 2 === 0) ? '#6b6252' : '#544c3e';
        w.raw(A.wetBlob(A.polyPath([[x, y], [x + 88, y], [x + 88, y + 84], [x, y + 84]]), S(c, .12), c, (i * 17 + j) >>> 0, { w: 3, f: .2, op: .5 }));
      }
    }
    // 隔音窗（望向录音间）
    var g = st.layer();
    windowFrame(g, 960, 120, 560, 420, r, { mull: 2, glow: '#cdd6d8' });
    for (var k = 0; k < 24; k++) g.circle(r.rng(970, 1510), r.rng(130, 530), r.rng(6, 26), { fill: AL('#e8eef0', r.rng(.04, .16)) });
    // 调音台
    var m = st.layer();
    desk(m, 60, 560, 900, 190, r, '#4a4136');
    m.raw(A.wetBlob(A.polyPath([[90, 470], [880, 450], [900, 570], [80, 590]]), '#585048', '#332e28', 61, { w: 6, f: .18 }));
    for (var ch = 0; ch < 10; ch++) {
      var cx = 130 + ch * 78;
      m.path(A.skPath(cx, 480, cx, 500, r, 1.2), { stroke: AL('#e8e2d2', .5), sw: 3 });
      m.circle(cx, 512, 7, { fill: AL('#d8d2c2', .8) });
      m.rect(cx - 5, 524, 10, 40, { fill: AL('#2b2722', .8) });
      // 电平灯
      m.circle(cx, 462, 4.5, { fill: ch < 6 ? AL('#8fd48a', .85) : AL('#d8b06a', .7) });
    }
    // 磁带机
    var tp = st.layer();
    tp.raw(A.wetBlob(A.polyPath([[980, 560], [1400, 546], [1416, 700], [972, 714]]), '#4e4a44', '#2f2c28', 71, { w: 6, f: .18 }));
    tp.circle(1080, 630, 34, { fill: AL('#d9d2c2', .35), stroke: AL('#eee8d8', .5), sw: 3 });
    tp.circle(1220, 626, 34, { fill: AL('#d9d2c2', .35), stroke: AL('#eee8d8', .5), sw: 3 });
    tp.rect(1300, 600, 70, 40, { fill: AL('#1f1d1a', .6) });
    tp.rect(1300, 650, 70, 20, { fill: AL('#8a6a3a', .5) });
    // 磁带盒子
    var bx = st.layer();
    for (var b = 0; b < 9; b++) {
      var bxx = 60 + b * 62, byy = 760 + (b % 2) * 8;
      bx.raw(A.wetBlob(A.polyPath([[bxx, byy], [bxx + 52, byy], [bxx + 52, byy + 74], [bxx, byy + 74]]), '#8d7f68', '#5e5342', (b + 3) >>> 0, { w: 3, f: .2, op: .85 }));
      bx.rect(bxx + 8, byy + 14, 36, 22, { fill: AL('#efe7d2', .5) });
    }
    // 墙上合影
    var f = st.layer();
    f.raw(A.wetBlob(A.polyPath([[1180, 250], [1420, 244], [1424, 390], [1184, 396]]), '#d9cdb4', '#9d8f76', 81, { w: 4, f: .2, op: .9 }));
    for (var p = 0; p < 9; p++) {
      var px = 1204 + (p % 5) * 46, py = 300 + Math.floor(p / 5) * 62;
      f.raw(A.wetBlob(A.blobPath(px, py, 16, 22, r, .3), '#7a6f5e', '#4a4237', (p + 9) >>> 0, { w: 2, f: .3, op: .7 }));
    }
    st.layer().rect(0, 0, 1600, 900, { fill: M('#c9bda4', '#ffffff', .5), op: .14 });
    st.vignette('#241f19', .34);
    return st;
  };

  // 广播台 · 修复特写（磁带 / 棉签 / 磁头）
  SCENES.repair = function (st) {
    var r = st.rnd;
    st.sky('#4f4a42', '#2c2925', { clouds: 3, cloudColor: '#6d655a' });
    var t = st.layer();
    t.raw(A.wetBlob(A.polyPath([[0, 420], [1600, 400], [1600, 900], [0, 900]]), '#6b5f4c', '#3b342b', 91, { w: 8, f: .2, op: .95 }));
    lightShaft(st.layer(), 700, 60, 260, 700, r, '#ffeec2', .22);
    // 打开的磁带
    var c = st.layer();
    c.raw(A.wetBlob(A.polyPath([[420, 380], [1180, 360], [1200, 700], [400, 720]]), '#5a5346', '#322d26', 93, { w: 7, f: .18 }));
    c.raw(A.wetBlob(A.polyPath([[470, 410], [1130, 392], [1146, 668], [452, 686]]), '#c9c0aa', '#8d846e', 94, { w: 5, f: .2, op: .8 }));
    // 两个磁带轮
    [620, 980].forEach(function (cx, idx) {
      c.circle(cx, 530, 86, { fill: AL('#e6dfcd', .35), stroke: AL('#f2ecd8', .55), sw: 4 });
      c.circle(cx, 530, 52, { fill: AL('#3a352d', .55) });
      for (var k = 0; k < 6; k++) {
        var a = k / 6 * Math.PI * 2;
        c.rect(cx + Math.cos(a) * 30 - 6, 530 + Math.sin(a) * 30 - 6, 12, 12, { fill: AL('#e6dfcd', .5) });
      }
      c.circle(cx, 530, 10, { fill: AL('#7a6f5c', .9) });
      // 磁带卷
      c.circle(cx, 530, 78 - idx * 8, { fill: 'none', stroke: AL('#5f5340', .55), sw: 26 });
    });
    // 断带
    var br = st.layer();
    for (var i = 0; i < 30; i++) {
      var px = 780 + i * 14 + Math.sin(i * .7) * 10, py = 640 + Math.sin(i * .4) * 26;
      br.circle(px, py, 4.4, { fill: AL('#3d2f22', .85) });
    }
    br.raw(A.wetBlob(A.blobPath(1180, 600, 60, 30, r, .4), '#6b3a2c', '#3d2018', 97, { w: 4, f: .5, op: .5 }));
    // 铅笔 / 棉签
    var tool = st.layer();
    tool.raw(A.wetBlob(A.polyPath([[1150, 760], [1480, 690], [1492, 726], [1162, 796]]), '#e9b45c', '#a9782a', 98, { w: 4, f: .15 }));
    tool.raw(A.wetBlob(A.polyPath([[120, 700], [420, 760], [412, 796], [112, 736]]), '#f2ece0', '#b8b0a0', 99, { w: 4, f: .2 }));
    tool.raw(A.wetBlob(A.circlePath(430, 782, 26), '#ffffff', '#ddd6c8', 100, { w: 3, f: .3 }));
    st.layer().rect(0, 0, 1600, 900, { fill: M('#c9bda4', '#ffffff', .55), op: .16 });
    st.vignette('#181512', .4);
    return st;
  };

  // 校道 · 梧桐
  SCENES.road = function (st) {
    var r = st.rnd;
    st.sky('#cfe0ea', '#eee0c2', { dx: .3, dy: 1, clouds: 9, cloudColor: '#fffdf4' });
    var l = st.layer();
    for (var i = 0; i < 6; i++) {
      var tx = 90 + i * 300 + r.rng(-40, 40);
      bigTree(l, tx, 700, r, { w: 70, bend: r.rng(-18, 18), topY: 120 + r.rng(-40, 40), crown: i < 3 });
    }
    // 教学楼侧影
    var bd = st.layer();
    bd.raw(A.wetBlob(A.polyPath([[1080, 180], [1600, 150], [1600, 700], [1080, 700]]), '#cfc6b4', '#93897a', 111, { w: 6, f: .18, op: .85 }));
    for (var w = 0; w < 4; w++) for (var h = 0; h < 5; h++) {
      bd.raw(A.wetBlob(A.polyPath([[1120 + w * 118, 240 + h * 88], [1198 + w * 118, 240 + h * 88], [1198 + w * 118, 300 + h * 88], [1120 + w * 118, 300 + h * 88]]), '#8fa5b4', '#5f7484', (w * 7 + h) >>> 0, { w: 3, f: .25, op: r.rng(.4, .75) }));
    }
    // 地面 + 路缘
    var g = st.layer();
    g.raw(A.wetBlob(A.polyPath([[0, 690], [1600, 690], [1600, 900], [0, 900]]), '#cbb894', '#9a8663', 112, { w: 7, f: .22, op: .9 }));
    g.raw(A.wetBlob(A.polyPath([[0, 760], [1600, 740], [1600, 900], [0, 900]]), '#b6a888', '#8a7d60', 113, { w: 6, f: .2, op: .7 }));
    for (var k = 0; k < 24; k++) {
      var px = r.rng(0, 1600), py = r.rng(700, 890);
      g.raw(A.wetBlob(A.blobPath(px, py, r.rng(14, 42), r.rng(5, 14), r, .4), M(PAL.gold, PAL.leaf, r.n()), '#9a7a3c', (k + 5) >>> 0, { w: 2, f: .4, op: r.rng(.2, .5) }));
    }
    // 布告栏
    var nb = st.layer();
    nb.raw(A.wetBlob(A.polyPath([[120, 470], [430, 462], [436, 640], [126, 648]]), '#6d5a3e', '#443522', 121, { w: 5, f: .2 }));
    for (var p = 0; p < 6; p++) {
      var px2 = 142 + (p % 3) * 96, py2 = 492 + Math.floor(p / 3) * 76;
      nb.raw(A.wetBlob(A.polyPath([[px2, py2], [px2 + 80, py2], [px2 + 80, py2 + 60], [px2, py2 + 60]]), '#fbf5e4', '#ded2b6', (p + 30) >>> 0, { w: 3, f: .2, op: r.rng(.75, .95) }));
    }
    st.vignette('#5a5030', .2);
    return st;
  };

  // 食堂三楼
  SCENES.canteen = function (st) {
    var r = st.rnd;
    st.sky('#f4e9d2', '#d8c9a8', { dx: .2, dy: 1, clouds: 6, cloudColor: '#fffaf0' });
    var l = st.layer();
    // 瓷砖墙
    for (var i = 0; i < 10; i++) for (var j = 0; j < 5; j++) {
      var c = (i + j) % 2 ? '#e6dcc4' : '#dcd0b4';
      l.raw(A.wetBlob(A.polyPath([[i * 160, 60 + j * 120], [i * 160 + 156, 60 + j * 120], [i * 160 + 156, 60 + j * 120 + 116], [i * 160, 60 + j * 120 + 116]]), S(c, .08), c, (i * 11 + j) >>> 0, { w: 2, f: .15, op: .5 }));
    }
    // 大窗与午后的光
    windowFrame(st.layer(), 900, 100, 620, 460, r, { mull: 3, glow: '#fff3cd' });
    lightShaft(st.layer(), 980, 110, 200, 600, r, '#fff0c0', .32);
    // 窗口价目牌
    var pr = st.layer();
    pr.raw(A.wetBlob(A.polyPath([[80, 120], [560, 110], [566, 300], [86, 310]]), '#3f4a52', '#232b31', 131, { w: 5, f: .18 }));
    for (var k = 0; k < 5; k++) pr.path(A.skPath(110, 164 + k * 30, 520, 158 + k * 30, r, 1.6), { stroke: AL('#f0e8d4', .5), sw: 4, lc: 'round' });
    pr.raw(A.wetBlob(A.polyPath([[80, 330], [420, 322], [424, 420], [84, 428]]), '#8d4d42', '#5a2c25', 132, { w: 4, f: .2, op: .8 }));
    // 地板
    var fl = st.layer();
    fl.raw(A.wetBlob(A.polyPath([[0, 620], [1600, 620], [1600, 900], [0, 900]]), '#cbbfa2', '#98896b', 133, { w: 6, f: .2, op: .9 }));
    // 餐盘 + 面碗（你慢慢说 CG 的实景版）
    var tb = st.layer();
    desk(tb, 300, 560, 700, 170, r, '#b08a5c');
    tb.raw(A.wetBlob(A.ellipsePath(560, 592, 96, 30), '#fdf8ea', '#cfc2a4', 141, { w: 4, f: .18 }));
    tb.raw(A.wetBlob(A.ellipsePath(560, 588, 78, 22), '#e8c98e', '#b98a4a', 142, { w: 4, f: .3, op: .9 }));
    // 热气
    var st2 = st.layer();
    for (var s = 0; s < 5; s++) st2.raw(A.wetBlob(A.blobPath(540 + r.rng(-20, 40), 540 - s * 30, r.rng(16, 30), r.rng(10, 20), r, .4), '#ffffff', '#e6e0d0', (s + 60) >>> 0, { w: 3, f: .7, op: .18 }));
    tb.raw(A.wetBlob(A.ellipsePath(790, 600, 66, 22), '#efe9d8', '#c2b89e', 143, { w: 3, f: .18 }));
    // 餐盘（斜前方）
    var pl = st.layer();
    pl.raw(A.wetBlob(A.ellipsePath(1120, 660, 130, 40), '#f6f1e0', '#c9bfa4', 145, { w: 4, f: .2, op: .7 }));
    pl.raw(A.wetBlob(A.ellipsePath(1090, 656, 42, 16), '#c8a05c', '#8a6a34', 146, { w: 3, f: .3, op: .7 }));
    pl.raw(A.wetBlob(A.ellipsePath(1160, 660, 46, 17), '#8fae6a', '#5c7a42', 147, { w: 3, f: .3, op: .7 }));
    st.vignette('#5f5232', .18);
    return st;
  };

  // 操场 / 看台（黄昏）
  SCENES.field = function (st) {
    var r = st.rnd;
    st.sky('#f6d9a8', '#7f9ec2', { dx: 0, dy: -1, clouds: 12, cloudColor: '#fff0d0' });
    var sun = st.layer();
    sun.raw(A.wetBlob(A.blobPath(1180, 300, 130, 110, r, .16), '#ffe9a8', '#f2b45c', 151, { w: 6, f: .7, op: .55 }));
    // 跑道
    var f = st.layer();
    f.raw(A.wetBlob(A.polyPath([[0, 520], [1600, 500], [1600, 900], [0, 900]]), '#b9694f', '#7d4433', 152, { w: 7, f: .22, op: .9 }));
    for (var i = 0; i < 6; i++) {
      f.path(A.skPath(0, 540 + i * 60, 1600, 520 + i * 60, r, 3), { stroke: AL('#f4e6cc', .5), sw: 3.4 });
    }
    f.raw(A.wetBlob(A.polyPath([[620, 620], [1600, 580], [1600, 900], [560, 900]]), '#7fa060', '#4d6c3e', 153, { w: 6, f: .25, op: .8 }));
    // 看台
    var g = st.layer();
    for (var k = 0; k < 6; k++) {
      var y = 420 - k * 52, c = k % 2 ? '#c9bfa8' : '#b5ab95';
      g.raw(A.wetBlob(A.polyPath([[0, y], [520, y - 14], [520, y + 30], [0, y + 44]]), S(c, .1), c, (k + 7) >>> 0, { w: 4, f: .15, op: .85 }));
    }
    // 看台上稀疏的人影
    for (var p = 0; p < 6; p++) {
      var px = 80 + p * 78 + r.rng(-20, 20), py = 410 - Math.floor(r.n() * 4) * 52;
      g.raw(A.wetBlob(A.blobPath(px, py - 26, 11, 26, r, .3), '#4b4a45', '#2c2b28', (p + 20) >>> 0, { w: 3, f: .35, op: .5 }));
      g.circle(px, py - 58, 9, { fill: AL('#3e3d38', .55) });
    }
    // 远处灯杆
    var lp = st.layer();
    [300, 900, 1400].forEach(function (x, idx) {
      lp.path(A.skPath(x, 520, x, 200, r, 2), { stroke: AL('#4a4a46', .7), sw: 6, lc: 'round' });
      lp.raw(A.wetBlob(A.blobPath(x + 40, 200, 60, 14, r, .2), '#4a4a46', '#2f2f2c', (idx + 90) >>> 0, { w: 3, f: .2, op: .8 }));
      lp.raw(A.wetBlob(A.blobPath(x + 70, 214, 40, 22, r, .3), '#ffeeb4', '#e0b84c', (idx + 91) >>> 0, { w: 3, f: .6, op: .4 }));
    });
    st.vignette('#6b4c2a', .26);
    return st;
  };

  // 湖边（黄昏 → 夜）
  SCENES.lake = function (st) {
    var r = st.rnd;
    st.sky('#f3d3a8', '#69809e', { dx: 0, dy: -1, clouds: 10, cloudColor: '#ffeccd' });
    var l = st.layer();
    l.raw(A.wetBlob(A.blobPath(1240, 260, 120, 96, r, .14), '#fff0b8', '#eaa84f', 161, { w: 6, f: .75, op: .5 }));
    // 对岸树线
    var t = st.layer();
    for (var i = 0; i < 16; i++) {
      var cx = i * 108 + r.rng(-30, 30);
      t.raw(A.wetBlob(A.blobPath(cx, 470, r.rng(60, 110), r.rng(40, 70), r, .3), M('#6f8a5a', '#3f5a48', r.n()), '#33452f', (i + 40) >>> 0, { w: 4, f: .5, op: r.rng(.35, .6) }));
    }
    // 湖面
    var w = st.layer();
    w.raw(A.wetBlob(A.polyPath([[0, 500], [1600, 500], [1600, 900], [0, 900]]), '#9db6c9', '#4f6f8c', 162, { w: 8, f: .22, op: .92 }));
    for (var k = 0; k < 26; k++) {
      var y = 510 + k * 15, x = r.rng(0, 1400), len = r.rng(80, 340);
      w.path(A.skPath(x, y, x + len, y + r.rng(-3, 3), r, 2), { stroke: AL(k % 3 === 0 ? '#f6dfae' : '#e6eef4', r.rng(.2, .55)), sw: r.rng(2, 5) });
    }
    // 阳光倒影
    w.raw(A.wetBlob(A.polyPath([[1150, 500], [1340, 500], [1420, 900], [1080, 900]]), '#ffe9b0', '#dba85a', 163, { w: 4, f: .7, op: .35 }));
    // 木栈道
    var d = st.layer();
    d.raw(A.wetBlob(A.polyPath([[0, 660], [700, 640], [720, 760], [0, 790]]), '#9a7a52', '#5f4a30', 164, { w: 6, f: .2, op: .95 }));
    for (var b = 0; b < 12; b++) d.path(A.skPath(-20 + b * 62, 648 + b * 1.2, -20 + b * 62, 786, r, 2), { stroke: AL('#3f3020', .3), sw: 2.4 });
    // 栏杆
    var rl = st.layer();
    rl.path(A.skPath(0, 600, 720, 586, r, 2), { stroke: AL('#6b5636', .8), sw: 6 });
    for (var q = 0; q < 8; q++) rl.path(A.skPath(10 + q * 96, 600, 10 + q * 96, 660, r, 2), { stroke: AL('#6b5636', .7), sw: 5 });
    st.vignette('#4a3f2e', .3);
    return st;
  };

  // 天台（初雪 / 铅灰）
  SCENES.roof = function (st) {
    var r = st.rnd;
    st.sky('#cfd8e0', '#9aa8b6', { clouds: 14, cloudColor: '#f4f7fa' });
    var c = st.layer();
    for (var i = 0; i < 18; i++) {
      var cx = r.rng(0, 1600), cy = r.rng(40, 400), sc = r.rng(90, 300);
      c.raw(A.wetBlob(A.blobPath(cx, cy, sc, sc * r.rng(.2, .4), r, .3), '#ffffff', '#c3ceda', (i + 50) >>> 0, { w: 4, f: .6, op: r.rng(.14, .4) }));
    }
    // 远处城市 / 校园轮廓
    var sky2 = st.layer();
    for (var b = 0; b < 22; b++) {
      var bw = r.rng(50, 130), bh = r.rng(60, 210), bx = b * 78 - 20;
      sky2.raw(A.wetBlob(A.polyPath([[bx, 560 - bh], [bx + bw, 560 - bh], [bx + bw, 560], [bx, 560]]), '#8794a4', '#5f6b7a', (b + 80) >>> 0, { w: 3, f: .2, op: r.rng(.2, .45) }));
    }
    // 天台地面
    var g = st.layer();
    g.raw(A.wetBlob(A.polyPath([[0, 560], [1600, 552], [1600, 900], [0, 900]]), '#b4b9bd', '#7d838a', 171, { w: 8, f: .2, op: .95 }));
    for (var k = 0; k < 10; k++) g.path(A.skPath(0, 580 + k * 32, 1600, 574 + k * 32, r, 3), { stroke: AL('#5f666d', .18), sw: 2 });
    // 女儿墙
    var wl = st.layer();
    wl.raw(A.wetBlob(A.polyPath([[0, 500], [1600, 492], [1600, 560], [0, 570]]), '#c8ccd0', '#93999f', 172, { w: 5, f: .18, op: .95 }));
    // 水塔 / 通风管
    var t = st.layer();
    t.raw(A.wetBlob(A.polyPath([[1200, 300], [1420, 296], [1424, 500], [1196, 504]]), '#a9adb2', '#6f757b', 173, { w: 5, f: .2, op: .85 }));
    t.raw(A.wetBlob(A.ellipsePath(1310, 296, 112, 26), '#c2c6ca', '#83898f', 174, { w: 4, f: .2 }));
    t.raw(A.wetBlob(A.polyPath([[200, 460], [340, 456], [344, 552], [196, 556]]), '#9aa0a6', '#666c72', 175, { w: 4, f: .2, op: .8 }));
    // 雪
    var sn = st.layer();
    for (var s = 0; s < 150; s++) sn.circle(r.rng(0, 1600), r.rng(0, 900), r.rng(1.4, 4.6), { fill: AL('#ffffff', r.rng(.35, .95)) });
    // 雪光
    lightShaft(st.layer(), 500, 0, 260, 900, r, '#ffffff', .16);
    st.vignette('#4f5860', .28);
    return st;
  };

  // 小礼堂
  SCENES.hall = function (st) {
    var r = st.rnd;
    st.sky('#3d342c', '#241e19', { clouds: 4, cloudColor: '#6b5a48' });
    var l = st.layer();
    // 木墙
    l.raw(A.wetBlob(A.polyPath([[0, 0], [1600, 0], [1600, 900], [0, 900]]), '#6b4f34', '#3a291c', 181, { w: 8, f: .2, op: .95 }));
    for (var i = 0; i < 22; i++) l.path(A.skPath(i * 76, 0, i * 76 + r.rng(-6, 6), 900, r, 3), { stroke: AL('#2a1d12', .25), sw: 3 });
    // 红丝绒幕
    var cu = st.layer();
    cu.raw(A.wetBlob(A.polyPath([[0, 0], [300, 0], [260, 620], [0, 660]]), '#7d2f36', '#4a1a1f', 182, { w: 7, f: .25, op: .95 }));
    cu.raw(A.wetBlob(A.polyPath([[1600, 0], [1300, 0], [1340, 620], [1600, 660]]), '#7d2f36', '#4a1a1f', 183, { w: 7, f: .25, op: .95 }));
    for (var k = 0; k < 7; k++) {
      cu.path(A.skPath(30 + k * 34, 0, 40 + k * 30, 620, r, 3), { stroke: AL('#3d1418', .3), sw: 6 });
      cu.path(A.skPath(1580 - k * 34, 0, 1570 - k * 30, 620, r, 3), { stroke: AL('#3d1418', .3), sw: 6 });
    }
    // 舞台
    var s = st.layer();
    s.raw(A.wetBlob(A.polyPath([[240, 560], [1360, 560], [1440, 720], [160, 720]]), '#7a5a38', '#3f2e1c', 184, { w: 6, f: .18, op: .95 }));
    // 讲台 / 麦克风
    var m = st.layer();
    m.path(A.skPath(700, 560, 700, 400, r, 1.6), { stroke: AL('#b8b2a4', .6), sw: 4, lc: 'round' });
    m.raw(A.wetBlob(A.blobPath(700, 384, 16, 24, r, .2), '#c9c3b4', '#6f6a5e', 185, { w: 4, f: .3, op: .9 }));
    m.raw(A.wetBlob(A.polyPath([[560, 560], [860, 556], [856, 620], [564, 624]]), '#8d6a42', '#4a3520', 186, { w: 4, f: .18, op: .9 }));
    // 录音机红灯
    var rc = st.layer();
    rc.raw(A.wetBlob(A.polyPath([[880, 520], [1010, 516], [1014, 570], [884, 574]]), '#4a453e', '#2a2622', 187, { w: 4, f: .18 }));
    rc.circle(898, 534, 5, { fill: AL('#e0503c', .95) });
    rc.raw(A.wetBlob(A.blobPath(898, 534, 26, 26, r, .3), '#e0503c', '#8a2418', 188, { w: 3, f: .8, op: .35 }));
    // 观众席
    var a = st.layer();
    for (var rw = 0; rw < 4; rw++) {
      var y = 720 + rw * 46;
      a.raw(A.wetBlob(A.polyPath([[0, y], [1600, y - 6], [1600, y + 46], [0, y + 52]]), '#5f4a34', '#33261a', (rw + 30) >>> 0, { w: 5, f: .2, op: .8 }));
      for (var p = 0; p < 14; p++) {
        var px = 40 + p * 112 + r.rng(-26, 26);
        a.raw(A.wetBlob(A.blobPath(px, y - 40, 22 + rw * 3, 34 + rw * 3, r, .3), '#3f3630', '#221c18', (rw * 20 + p) >>> 0, { w: 3, f: .4, op: r.rng(.3, .6) }));
        a.circle(px, y - 78 - rw * 4, 12 + rw * 2, { fill: AL('#2c2622', .6) });
      }
    }
    // 顶灯
    var lg = st.layer();
    for (var q = 0; q < 4; q++) {
      var lx = 400 + q * 280;
      lg.raw(A.wetBlob(A.blobPath(lx, 90, 90, 40, r, .25), '#ffeec2', '#e0b84c', (q + 60) >>> 0, { w: 4, f: .7, op: .35 }));
      lg.path(A.skPath(lx, 130, lx, 210, r, 2), { stroke: AL('#ffeec2', .3), sw: 8 });
    }
    lightShaft(st.layer(), 620, 120, 180, 460, r, '#ffeec2', .22);
    st.layer().rect(0, 0, 1600, 900, { fill: M('#c9bda4', '#ffffff', .5), op: .12 });
    st.vignette('#000000', .38);
    return st;
  };

  // 宿舍夜景（灯泡下）
  SCENES.dorm = function (st) {
    var r = st.rnd;
    st.sky('#3a3730', '#25231f', { clouds: 3, cloudColor: '#5a554c' });
    var w = st.layer();
    w.raw(A.wetBlob(A.polyPath([[0, 0], [1600, 0], [1600, 780], [0, 780]]), '#4a443a', '#2c2823', 191, { w: 7, f: .2, op: .9 }));
    // 台灯光锥
    lightShaft(w, 560, 220, 300, 620, r, '#ffe2a8', .34);
    // 桌面
    var d = st.layer();
    d.raw(A.wetBlob(A.polyPath([[0, 620], [1600, 610], [1600, 900], [0, 900]]), '#8a6a44', '#4a3722', 192, { w: 7, f: .2, op: .95 }));
    // 台灯
    var lp = st.layer();
    lp.raw(A.wetBlob(A.blobPath(560, 560, 60, 22, r, .2), '#3f6b52', '#22402f', 193, { w: 4, f: .3 }));
    lp.path(A.skPath(548, 560, 578, 460, r, 2), { stroke: '#28402f', sw: 6, lc: 'round' });
    lp.raw(A.wetBlob(A.blobPath(592, 448, 44, 26, r, .22), '#ffe9b0', '#cf9a3c', 194, { w: 4, f: .5, op: .8 }));
    // 磁带盒 / 笔记本 / 听力报告
    var bx = st.layer();
    bx.raw(A.wetBlob(A.polyPath([[240, 560], [420, 552], [426, 640], [246, 648]]), '#8d7f68', '#5e5342', 195, { w: 4, f: .2 }));
    bx.rect(258, 574, 144, 34, { fill: AL('#efe7d2', .55) });
    bx.raw(A.wetBlob(A.polyPath([[700, 570], [960, 560], [966, 660], [706, 670]]), '#fbf5e4', '#ded2b6', 196, { w: 4, f: .18, op: .95 }));
    for (var i = 0; i < 6; i++) bx.path(A.skPath(720, 590 + i * 12, 946, 584 + i * 12, r, 1.6), { stroke: AL('#8a7c5e', .4), sw: 1.6 });
    // 医院报告单（一角）
    bx.raw(A.wetBlob(A.polyPath([[1080, 600], [1300, 592], [1306, 700], [1086, 708]]), '#f4f7f8', '#c8d2d6', 197, { w: 3, f: .18, op: .9 }));
    bx.path(A.skPath(1100, 630, 1284, 624, r, 2), { stroke: AL('#5f8f8a', .5), sw: 2 });
    bx.path(A.skPath(1100, 656, 1260, 650, r, 2), { stroke: AL('#5f8f8a', .35), sw: 2 });
    st.vignette('#000000', .48);
    return st;
  };

  // 教室（通识课）
  SCENES.classroom = function (st) {
    var r = st.rnd;
    st.sky('#eef1e6', '#cfd6c2', { clouds: 5, cloudColor: '#fbfdf7' });
    var l = st.layer();
    l.raw(A.wetBlob(A.polyPath([[0, 0], [1600, 0], [1600, 620], [0, 620]]), '#dfe4d2', '#b8c0a6', 201, { w: 6, f: .2, op: .85 }));
    // 黑板
    var b = st.layer();
    b.raw(A.wetBlob(A.polyPath([[420, 120], [1240, 110], [1246, 470], [426, 480]]), '#3f4a42', '#24302a', 202, { w: 6, f: .18 }));
    b.raw(A.wetBlob(A.polyPath([[440, 140], [1220, 132], [1226, 456], [446, 464]]), '#4c5a50', '#2c3a32', 203, { w: 4, f: .2, op: .8 }));
    for (var i = 0; i < 6; i++) b.path(A.skPath(480 + i * 40, 190 + i * 8, 1100 - i * 30, 200 + i * 42, r, 3), { stroke: AL('#edf0e6', .5), sw: 3.4, lc: 'round' });
    // 窗
    windowFrame(st.layer(), 1290, 110, 300, 380, r, { mull: 2, glow: '#fff6d8' });
    lightShaft(st.layer(), 1300, 120, 140, 520, r, '#fff6d8', .28);
    // 课桌阵列
    var d = st.layer();
    for (var row = 0; row < 3; row++) {
      for (var col = 0; col < 5; col++) {
        var x = 60 + col * 310 + row * 40, y = 520 + row * 120;
        d.raw(A.wetBlob(A.polyPath([[x, y], [x + 230, y], [x + 236, y + 26], [x - 6, y + 26]]), '#c69a62', '#7a5a32', (row * 11 + col) >>> 0, { w: 4, f: .18, op: .9 }));
        d.raw(A.wetBlob(A.polyPath([[x + 16, y + 26], [x + 214, y + 26], [x + 200, y + 110], [x + 30, y + 110]]), '#b08a52', '#6a4a28', (row * 7 + col + 3) >>> 0, { w: 4, f: .2, op: .8 }));
      }
    }
    st.vignette('#5a5a3a', .2);
    return st;
  };

  // 资料室 / 档案架
  SCENES.archive = function (st) {
    var r = st.rnd;
    st.sky('#e5e0d2', '#b8b2a0', { clouds: 4, cloudColor: '#f6f3ea' });
    var l = st.layer();
    for (var i = 0; i < 4; i++) {
      var x = 40 + i * 400;
      l.raw(A.wetBlob(A.polyPath([[x, 120], [x + 340, 120], [x + 340, 760], [x, 760]]), '#9c8a6a', '#5f5236', (i + 10) >>> 0, { w: 6, f: .2, op: .85 }));
      for (var s = 0; s < 5; s++) {
        var y = 160 + s * 120;
        l.path(A.skPath(x + 10, y, x + 330, y, r, 2), { stroke: AL('#4a3c22', .4), sw: 4 });
        for (var k = 0; k < 14; k++) {
          var bw = r.rng(14, 26), bh = r.rng(70, 104), bx = x + 18 + k * 22;
          var c = r.pick(['#7a5a3a', '#5a6b7a', '#6b6a52', '#8a5a52']);
          l.raw(A.wetBlob(A.polyPath([[bx, y - bh], [bx + bw, y - bh], [bx + bw, y], [bx, y]]), S(c, .15), c, (i * 100 + s * 14 + k) >>> 0, { w: 2, f: .25, op: r.rng(.5, .8) }));
        }
      }
    }
    // 检索卡片柜
    var c = st.layer();
    c.raw(A.wetBlob(A.polyPath([[1220, 560], [1480, 552], [1486, 760], [1226, 768]]), '#8d7f68', '#4f4432', 211, { w: 5, f: .18 }));
    for (var d = 0; d < 4; d++) for (var e = 0; e < 3; e++) {
      c.raw(A.wetBlob(A.polyPath([[1240 + e * 78, 580 + d * 44], [1306 + e * 78, 578 + d * 44], [1306 + e * 78, 610 + d * 44], [1240 + e * 78, 612 + d * 44]]), '#e8e0c8', '#b0a488', (d * 5 + e) >>> 0, { w: 2, f: .2, op: .8 }));
    }
    lightShaft(st.layer(), 900, 60, 200, 700, r, '#fff6dc', .22);
    st.vignette('#5f5640', .24);
    return st;
  };

  // 宿舍阳台 · 夜
  SCENES.balcony = function (st) {
    var r = st.rnd;
    st.sky('#1f2a3a', '#3b4a5f', { clouds: 8, cloudColor: '#4a5c72' });
    var m = st.layer();
    m.raw(A.wetBlob(A.blobPath(1300, 160, 70, 62, r, .12), '#f6f1d8', '#cfc7a0', 221, { w: 5, f: .5, op: .5 }));
    for (var i = 0; i < 70; i++) m.circle(r.rng(0, 1600), r.rng(0, 420), r.rng(.7, 2.1), { fill: AL('#ffffff', r.rng(.2, .8)) });
    // 远处宿舍楼窗
    var b = st.layer();
    for (var x = 0; x < 12; x++) for (var y = 0; y < 6; y++) {
      var lit = r.n() < .45;
      b.raw(A.wetBlob(A.polyPath([[60 + x * 128, 380 + y * 74], [60 + x * 128 + 70, 380 + y * 74], [70 + x * 128 + 70, 380 + y * 74 + 50], [70 + x * 128, 380 + y * 74 + 50]]), lit ? '#ffe6a8' : '#3f4a5a', lit ? '#d8a850' : '#2a323e', (x * 7 + y) >>> 0, { w: 2, f: .3, op: lit ? r.rng(.4, .8) : .5 }));
    }
    // 阳台栏杆与地面
    var g = st.layer();
    g.raw(A.wetBlob(A.polyPath([[0, 620], [1600, 620], [1600, 900], [0, 900]]), '#5a5750', '#33312c', 222, { w: 7, f: .2, op: .95 }));
    g.path(A.skPath(0, 560, 1600, 556, r, 3), { stroke: AL('#c9c4b6', .5), sw: 6 });
    for (var k = 0; k < 14; k++) g.path(A.skPath(40 + k * 116, 556, 40 + k * 116, 640, r, 2), { stroke: AL('#c9c4b6', .4), sw: 4 });
    // 晾着的衣服
    g.path(A.skPath(0, 400, 1600, 392, r, 3), { stroke: AL('#d8d2c2', .35), sw: 3 });
    var cloth = st.layer();
    [200, 520, 900, 1300].forEach(function (x, idx) {
      cloth.raw(A.wetBlob(A.polyPath([[x, 400], [x + 130, 396], [x + 150, 640], [x + 10, 644]]), '#b9c4cc', '#6f7c88', (idx + 70) >>> 0, { w: 4, f: .25, op: .5 }));
    });
    st.vignette('#000000', .4);
    return st;
  };

  // 雪中校道
  SCENES.snowRoad = function (st) {
    var r = st.rnd;
    st.sky('#dde6ee', '#b0bec9', { clouds: 12, cloudColor: '#ffffff' });
    var l = st.layer();
    for (var i = 0; i < 5; i++) bigTree(l, 120 + i * 340, 700, r, { w: 60, col: '#4a4238', crown: false, bend: r.rng(-14, 14) });
    // 雪覆枝
    var sn = st.layer();
    for (var b = 0; b < 40; b++) sn.raw(A.wetBlob(A.blobPath(r.rng(40, 1560), r.rng(80, 420), r.rng(30, 90), r.rng(6, 16), r, .4), '#ffffff', '#c8d4e0', (b + 10) >>> 0, { w: 3, f: .5, op: r.rng(.25, .6) }));
    var g = st.layer();
    g.raw(A.wetBlob(A.polyPath([[0, 700], [1600, 690], [1600, 900], [0, 900]]), '#e8eef4', '#b8c4d0', 231, { w: 8, f: .22, op: .95 }));
    for (var k = 0; k < 20; k++) g.raw(A.wetBlob(A.blobPath(r.rng(0, 1600), r.rng(700, 890), r.rng(60, 200), r.rng(10, 30), r, .35), '#ffffff', '#cdd8e2', (k + 30) >>> 0, { w: 3, f: .6, op: r.rng(.15, .4) }));
    // 脚印
    for (var p = 0; p < 9; p++) {
      var px = 300 + p * 110 + r.rng(-20, 20), py = 760 + p * 14;
      g.raw(A.wetBlob(A.blobPath(px, py, 22, 30, r, .3), '#b6c2ce', '#8f9daa', (p + 50) >>> 0, { w: 2, f: .5, op: .35 }));
    }
    for (var s2 = 0; s2 < 180; s2++) sn.circle(r.rng(0, 1600), r.rng(0, 900), r.rng(1.4, 4.4), { fill: AL('#ffffff', r.rng(.4, .95)) });
    st.vignette('#5f6b76', .26);
    return st;
  };

  // 标题画面 · 晨光水彩
  SCENES.title = function (st) {
    var r = st.rnd;
    st.sky('#f7ecd4', '#9fb6c9', { dx: .4, dy: 1, clouds: 14, cloudColor: '#fffdf2' });
    var l = st.layer();
    // 光晕
    l.raw(A.wetBlob(A.blobPath(1180, 220, 320, 260, r, .16), '#fff3cd', '#e8b96a', 241, { w: 8, f: .8, op: .45 }));
    // 抽象的纸面水彩块（呼应广播 / 磁带）
    for (var i = 0; i < 16; i++) {
      var c = r.pick([PAL.navy, PAL.navyL, PAL.gold, PAL.teal, '#c98f82', '#8fa8bf']);
      var d = A.blobPath(r.rng(-100, 1700), r.rng(-60, 960), r.rng(120, 420), r.rng(70, 260), r, .35);
      l.raw(A.wetBlob(d, S(c, .18), c, (i * 13 + 7) >>> 0, { w: 6, f: .6, op: r.rng(.08, .22) }));
    }
    // 落叶
    for (var k = 0; k < 26; k++) {
      var x = r.rng(0, 1600), y = r.rng(0, 900), a = r.rng(0, 6.28);
      leafSpray(l, x, y, r.rng(16, 40), a, r, r.pick(['#c9a24c', '#a8813a', '#7d9a5f']), r.rng(.2, .5));
    }
    // 磁带轮廓
    var tp = st.layer();
    tp.raw(A.wetBlob(A.polyPath([[560, 560], [1040, 546], [1048, 760], [568, 774]]), '#f2ece0', '#b8ae98', 243, { w: 6, f: .2, op: .55 }));
    tp.circle(700, 660, 44, { fill: 'none', stroke: AL('#8a8068', .7), sw: 5 });
    tp.circle(900, 656, 44, { fill: 'none', stroke: AL('#8a8068', .7), sw: 5 });
    tp.rect(760, 700, 80, 32, { fill: AL('#8a8068', .35) });
    st.vignette('#5f5136', .3);
    return st;
  };

    /* =========================================================
   *  女主立绘 longer  （画布 900 x 1180，人物约 300~620 宽）
   *  参考实拍：及肩偏长黑发 / 圆框金丝细边眼镜 / 白领深藏青短袖 /
   *            米色菱形绗缝帆布书包 / 老树与灰石墙
   * ========================================================= */
  var EXPR = ['calm', 'serious', 'smile', 'troubled', 'solemn'];

  var GLASS = { lx: 390, rx: 512, ey: 360, r: 62, gold: '#c9a75c', goldD: '#9d7c36' };

  function spriteParts(e) {
    var o = { eye: '', brow: '', mouth: '', blush: '', extra: '', tilt: 0, shine: false };
    var lash = '#2b2420';
    function eye(cx, cy, w, h, hi) {
      hi = hi || 0;
      return '<path d="M' + (cx - w) + ',' + (cy + h * 0.12) + ' Q' + cx + ',' + (cy - h * 1.28) + ' ' + (cx + w) + ',' + (cy - h * 0.06) +
        ' Q' + cx + ',' + (cy + h * 0.96) + ' ' + (cx - w) + ',' + (cy + h * 0.12) + ' Z" fill="#fdf9f0"/>' +
        '<ellipse cx="' + (cx + hi) + '" cy="' + (cy - h * 0.04) + '" rx="' + (w * 0.74) + '" ry="' + (h * 0.92) + '" fill="#8a6f46"/>' +
        '<ellipse cx="' + (cx + hi) + '" cy="' + (cy - h * 0.02) + '" rx="' + (w * 0.6) + '" ry="' + (h * 0.84) + '" fill="#5c4527"/>' +
        '<ellipse cx="' + (cx + hi) + '" cy="' + (cy + h * 0.02) + '" rx="' + (w * 0.4) + '" ry="' + (h * 0.62) + '" fill="#241c14"/>' +
        '<ellipse cx="' + (cx + hi) + '" cy="' + (cy + h * 0.34) + '" rx="' + (w * 0.36) + '" ry="' + (h * 0.26) + '" fill="#b9a06a" opacity=".45"/>' +
        '<circle cx="' + (cx - w * 0.36 + hi) + '" cy="' + (cy - h * 0.42) + '" r="' + (w * 0.3) + '" fill="#ffffff" opacity=".98"/>' +
        '<circle cx="' + (cx + w * 0.38 + hi) + '" cy="' + (cy + h * 0.4) + '" r="' + (w * 0.15) + '" fill="#ffffff" opacity=".7"/>' +
        '<path d="M' + (cx - w * 1.05) + ',' + (cy + h * 0.14) + ' Q' + cx + ',' + (cy - h * 1.34) + ' ' + (cx + w * 1.05) + ',' + (cy - h * 0.08) +
        '" fill="none" stroke="#2a2320" stroke-width="' + (w * 0.2).toFixed(2) + '" stroke-linecap="round"/>' +
        '<path d="M' + (cx + w * 1.0) + ',' + (cy - h * 0.06) + ' q' + (w * 0.3) + ',-' + (h * 0.1) + ' ' + (w * 0.46) + ',-' + (h * 0.46) +
        '" fill="none" stroke="' + lash + '" stroke-width="' + (w * 0.14).toFixed(2) + '" stroke-linecap="round"/>' +
        '<path d="M' + (cx - w * 0.58) + ',' + (cy - h * 0.92) + ' Q' + cx + ',' + (cy - h * 1.74) + ' ' + (cx + w * 0.72) + ',' + (cy - h * 0.8) +
        '" fill="none" stroke="' + AL(lash, .2) + '" stroke-width="1.5" stroke-linecap="round"/>';
    }
    function brow(cx, cy, w, tilt) {
      return '<path d="M' + (cx - w / 2) + ',' + (cy + tilt) + ' q' + (w * 0.5) + ',-' + (w * 0.3) + ' ' + w + ',' + (-tilt * 0.4) +
        '" fill="none" stroke="#3a3129" stroke-width="3.4" stroke-linecap="round" opacity=".8"/>';
    }
    function blush(cx, cy, s, op) {
      return '<ellipse cx="' + cx + '" cy="' + cy + '" rx="' + (40 * s) + '" ry="' + (19 * s) + '" fill="url(#blushG)" opacity="' + op + '"/>';
    }
    var EY = 360;
    if (e === 'calm') {
      o.eye = eye(390, EY, 33, 25, 0) + eye(512, EY, 33, 25, 0);
      o.brow = brow(392, 310, 80, 3) + brow(510, 310, 80, 3);
      o.mouth = '<path d="M442,474 q13,11 26,0" fill="#b5705f" opacity=".5"/>' +
        '<path d="M442,474 q13,11 26,0" fill="none" stroke="#9a5b50" stroke-width="3" stroke-linecap="round"/>';
      o.blush = blush(338, 424, .95, .16) + blush(564, 424, .95, .16);
    } else if (e === 'serious') {
      o.eye = eye(390, EY, 32, 26, 1) + eye(512, EY, 32, 26, 1);
      o.brow = brow(392, 304, 80, 9) + brow(510, 304, 80, 9);
      o.mouth = '<path d="M448,474 q12,-6 22,2" fill="none" stroke="#98574a" stroke-width="3.2" stroke-linecap="round"/>';
      o.blush = blush(338, 424, .85, .1) + blush(564, 424, .85, .1);
      o.shine = true;
    } else if (e === 'smile') {
      o.eye = eye(390, EY + 4, 33, 19, -1) + eye(512, EY + 4, 33, 19, -1);
      o.brow = brow(392, 306, 82, -3) + brow(510, 306, 82, -3);
      o.mouth = '<path d="M438,466 q19,23 46,-2 q-23,10 -46,2 Z" fill="#a5584c"/>' +
        '<path d="M440,467 q18,21 42,-2 q-21,8 -42,2 Z" fill="#f4ded2"/>' +
        '<path d="M452,472 q5,7 11,2 q-6,4 -11,-2 Z" fill="#c9756a" opacity=".5"/>' +
        '<path d="M436,464 q20,25 48,-1" fill="none" stroke="#8e4a41" stroke-width="2.4" stroke-linecap="round"/>';
      o.blush = blush(332, 420, 1.15, .3) + blush(570, 420, 1.15, .3);
      o.shine = true;
    } else if (e === 'troubled') {
      o.eye = eye(390, EY + 8, 31, 19, -4) + eye(512, EY + 8, 31, 19, -4);
      o.brow = brow(392, 314, 76, -9) + brow(510, 308, 76, 7);
      o.mouth = '<path d="M444,478 q13,-8 26,2" fill="none" stroke="#a06054" stroke-width="2.8" stroke-linecap="round"/>';
      o.blush = blush(330, 424, 1.2, .32) + blush(572, 424, 1.2, .32);
      o.tilt = -4;
      o.extra = '<path d="M600,320 q16,-18 32,0" fill="none" stroke="#8fa3ab" stroke-width="2.2" stroke-linecap="round" opacity=".45"/>';
    } else if (e === 'solemn') {
      o.eye = eye(390, EY, 34, 26, 0) + eye(512, EY, 34, 26, 0);
      o.brow = brow(392, 302, 86, 1) + brow(510, 302, 86, 1);
      o.mouth = '<path d="M442,474 q14,5 28,0" fill="none" stroke="#8e4a41" stroke-width="3.2" stroke-linecap="round"/>';
      o.blush = blush(338, 424, .75, .07) + blush(564, 424, .75, .07);
      o.shine = true;
    }
    return o;
  }

  var SPR_DEFS = [
    '<radialGradient id="blushG" cx="50%" cy="50%" r="50%">',
    '<stop offset="0%" stop-color="#e0897a" stop-opacity=".9"/>',
    '<stop offset="65%" stop-color="#e0897a" stop-opacity=".28"/>',
    '<stop offset="100%" stop-color="#e0897a" stop-opacity="0"/>',
    '</radialGradient>',
    '<linearGradient id="hairG" x1="0" y1="0" x2="0" y2="1">',
    '<stop offset="0%" stop-color="#4a423c"/><stop offset="38%" stop-color="#332c27"/>',
    '<stop offset="100%" stop-color="#1a1614"/></linearGradient>',
    '<linearGradient id="clothG" x1="0" y1="0" x2="0.2" y2="1">',
    '<stop offset="0%" stop-color="#3d5080"/><stop offset="70%" stop-color="#26314f"/>',
    '<stop offset="100%" stop-color="#1b2338"/></linearGradient>',
    '<linearGradient id="skinG" x1="0.3" y1="0" x2="0.6" y2="1">',
    '<stop offset="0%" stop-color="#fceadd"/><stop offset="70%" stop-color="#f4d8c2"/>',
    '<stop offset="100%" stop-color="#eac6ad"/></linearGradient>',
    '<linearGradient id="bagG" x1="0" y1="0" x2="0.4" y2="1">',
    '<stop offset="0%" stop-color="#e8dfc9"/><stop offset="100%" stop-color="#c6bba0"/></linearGradient>',
    '<linearGradient id="collarG" x1="0" y1="0" x2="0" y2="1">',
    '<stop offset="0%" stop-color="#fefcf5"/><stop offset="100%" stop-color="#eae3d2"/></linearGradient>',
    '<filter id="sSoft" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="7"/></filter>',
    '<filter id="sSoft2" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="16"/></filter>'
  ].join('');

  function hairStrands(l, rnd, pts) {
    for (var i = 0; i < 26; i++) {
      var a = pts[i % pts.length], b = pts[(i + 1) % pts.length];
      var x1 = A.lerp(a[0], b[0], rnd.rng(0.1, 0.9)), y1 = A.lerp(a[1], b[1], rnd.rng(0.1, 0.9));
      l.path(A.skPath(x1, y1, x1 + rnd.rng(-24, 24), y1 + rnd.rng(60, 190), rnd, 4), { stroke: AL(rnd.n() < .5 ? '#6d6058' : '#1a1614', rnd.rng(.07, .2)), sw: rnd.rng(1.4, 3.6) });
    }
    return l;
  }

  function sprite(e) {
    var seed = 7001;
    var r = R(seed);
    var p = spriteParts(e);
    var st = new A.Scene(seed);
    st.defs.push(SPR_DEFS);
    st.pushDef('<clipPath id="spClip"><path d="' + A.polyPath([
      [300, 300], [268, 470], [258, 640], [268, 900], [266, 1180], [700, 1180], [700, 900], [652, 640], [644, 470], [612, 300]
    ], true) + '"/></clipPath>');
    var l = st.layer();

    var hairBack = A.smoothPath([
      [294, 330], [266, 430], [252, 580], [262, 730], [292, 880], [320, 1010],
      [368, 1064], [452, 1078], [540, 1062], [600, 1010], [636, 880],
      [652, 730], [652, 580], [634, 430], [612, 330]
    ], true);
    var neck = A.smoothPath([[400, 552], [392, 610], [406, 648], [468, 656], [500, 646], [512, 606], [506, 552]], true);
    var torso = A.smoothPath([
      [334, 644], [300, 684], [276, 776], [266, 930], [262, 1180],
      [700, 1180], [700, 930], [694, 776], [674, 684],
      [648, 640], [612, 630], [560, 612], [524, 656], [452, 656], [420, 612], [368, 626]
    ], true);
    var collar = A.smoothPath([[420, 612], [452, 658], [524, 656], [562, 610], [546, 668], [524, 700], [452, 702], [430, 668]], true);
    var bagL = A.smoothPath([[368, 622], [340, 706], [322, 826], [332, 900], [364, 892], [380, 800], [396, 690], [402, 624]], true);
    var bagR = A.smoothPath([[562, 620], [592, 706], [610, 826], [600, 900], [568, 892], [552, 800], [536, 690], [530, 624]], true);
    var hairFront = A.smoothPath([[290, 352], [276, 268], [298, 200], [356, 162], [432, 156], [500, 178], [540, 220], [558, 292], [538, 250], [498, 208], [434, 196], [366, 212], [318, 262]], true);
    var sideL = A.smoothPath([[296, 306], [272, 412], [268, 560], [292, 690], [318, 762], [330, 668], [326, 520], [330, 402]], true);
    var sideR = A.smoothPath([[548, 300], [576, 406], [582, 556], [560, 686], [534, 758], [522, 664], [524, 516], [518, 396]], true);

    // 1. 后发
    l.path(hairBack, { fill: 'url(#hairG)' });
    l.raw(A.wetBlob(hairBack, '#372f2a', '#141110', 900, { w: 8, f: 0.4, op: 0.3 }));
    l.raw('<g filter="url(#sSoft)">' + hairStrands(new A.Layer(), r, [[292, 340], [258, 560], [268, 800], [330, 1030], [450, 1070], [580, 1020], [648, 780], [650, 540], [606, 340]]).markup() + '</g>');
    l.path(A.smoothPath([[292, 880], [306, 1010], [338, 1064], [372, 1030], [406, 1078], [452, 1046], [496, 1080], [530, 1028], [566, 1062], [600, 1006], [632, 880]], true), { fill: '#241e1a' });
    l.raw('<g filter="url(#sSoft2)">' + A.wetBlob(A.blobPath(452, 980, 170, 90, r, .3), '#2c2621', '#171412', 911, { w: 5, f: .6, op: .5 }) + '</g>');

    // 2. 身体
    l.path(neck, { fill: '#eecfb8' });
    l.raw(A.wetBlob(A.smoothPath([[392, 604], [512, 606], [516, 660], [388, 658]], true), '#dcb29a', '#bd9078', 901, { w: 4, f: .4, op: .5 }));
    l.path(torso, { fill: 'url(#clothG)' });
    l.raw(A.wetBlob(torso, '#41548a', '#151d31', 902, { w: 7, f: .35, op: .34 }));
    l.path(A.smoothPath([[300, 684], [276, 776], [268, 930], [286, 1180], [356, 1180], [344, 920], [352, 780], [366, 692]], true), { fill: '#31446e' });
    l.path(A.smoothPath([[674, 684], [694, 776], [700, 930], [700, 1180], [630, 1180], [618, 920], [628, 780], [612, 692]], true), { fill: '#2f4069' });
    l.path(collar, { fill: '#232a3e' });
    l.path(A.smoothPath([[420, 612], [452, 658], [430, 674], [400, 618]], true), { fill: 'url(#collarG)' });
    l.path(A.smoothPath([[562, 610], [524, 656], [548, 676], [584, 616]], true), { fill: 'url(#collarG)' });
    l.path(A.smoothPath([[420, 612], [452, 658], [430, 674], [400, 620]], true), { stroke: '#b9b098', sw: 1.6, fill: 'none' });
    l.path(A.smoothPath([[562, 610], [524, 656], [548, 676], [584, 618]], true), { stroke: '#b9b098', sw: 1.6, fill: 'none' });
    for (var k = 0; k < 9; k++) {
      var yy = 700 + k * 52;
      l.path(A.skPath(320 + r.rng(-16, 16), yy, 420 + r.rng(-24, 24), yy + r.rng(-10, 12), r, 4), { stroke: AL('#0f1729', r.rng(.1, .26)), sw: r.rng(2, 4.6) });
      l.path(A.skPath(690 - r.rng(-16, 16), yy, 560 + r.rng(-24, 24), yy + r.rng(-10, 12), r, 4), { stroke: AL('#0f1729', r.rng(.08, .22)), sw: r.rng(2, 4.4) });
    }
    l.path(bagL, { fill: 'url(#bagG)' });
    l.path(bagR, { fill: 'url(#bagG)' });
    for (var s = 0; s < 11; s++) {
      l.path(A.skPath(372 + s * 1.6, 640 + s * 24, 344 + s * 1.6, 660 + s * 24, r, 2), { stroke: AL('#a89b80', .45), sw: 1.6 });
      l.path(A.skPath(560 - s * 1.6, 638 + s * 24, 588 - s * 1.6, 658 + s * 24, r, 2), { stroke: AL('#a89b80', .45), sw: 1.6 });
    }
    l.raw(A.wetBlob(A.blobPath(330, 852, 17, 12, r, .16), '#e8da9e', '#a8873c', 903, { w: 3, f: .3 }));
    l.raw(A.wetBlob(A.blobPath(602, 852, 17, 12, r, .16), '#e8da9e', '#a8873c', 904, { w: 3, f: .3 }));
    l.path(A.smoothPath([[290, 860], [272, 960], [286, 1060], [330, 1074], [348, 1010], [336, 920]], true), { fill: '#efe4d4' });
    l.path(A.smoothPath([[286, 1030], [330, 1044], [356, 1014], [356, 978], [316, 966], [288, 986]], true), { fill: '#fae6d7' });
    for (var f = 0; f < 4; f++) l.path(A.skPath(300 + f * 15, 1046 - f * 3, 306 + f * 15, 990 + f * 4, r, 2), { stroke: AL('#d9a98f', .55), sw: 2 });

    // 3. 头 / 脸
    l.path(A.ellipsePath(450, 400, 126, 152), { fill: 'url(#skinG)' });
    l.path(A.smoothPath([[328, 386], [342, 480], [400, 540], [452, 556], [504, 540], [564, 480], [574, 386]], true), { fill: 'url(#skinG)', op: .85 });
    l.raw(A.wetBlob(A.ellipsePath(450, 400, 126, 152), '#fbe4d4', '#d8a78d', 905, { w: 5, f: .45, op: .26 }));
    l.path(A.ellipsePath(326, 402, 18, 30), { fill: '#eecdb6' });
    l.path(A.ellipsePath(576, 402, 18, 30), { fill: '#eecdb6' });
    l.path(A.smoothPath([[326, 388], [342, 396], [342, 414]], false), { stroke: AL('#c9947a', .5), sw: 2 });

    // 4. 五官
    var face = new A.Layer();
    face.raw(p.blush);
    face.raw(A.wetBlob(A.blobPath(452, 428, 9, 12, r, .25), '#d79c85', '#b87f68', 906, { w: 2, f: .4, op: .5 }));
    face.path(A.skPath(444, 432, 458, 437, r, 1), { stroke: AL('#b87f68', .5), sw: 1.8, lc: 'round' });
    face.raw(p.brow); face.raw(p.eye); face.raw(p.mouth); face.raw(p.extra);
    l.raw(face.markup());

    // 5. 眼镜
    var gl = new A.Layer();
    var gy = GLASS.ey, gr = GLASS.r;
    gl.path(A.ellipsePath(GLASS.lx, gy, gr, gr * 1.02), { fill: AL('#eaf4f8', .035), stroke: GLASS.gold, sw: 3.4 });
    gl.path(A.ellipsePath(GLASS.rx, gy, gr, gr * 1.02), { fill: AL('#eaf4f8', .035), stroke: GLASS.gold, sw: 3.4 });
    gl.path(A.ellipsePath(GLASS.lx, gy, gr - 2, gr * 1.02 - 2), { fill: 'none', stroke: AL(GLASS.goldD, .45), sw: 1.2 });
    gl.path(A.ellipsePath(GLASS.rx, gy, gr - 2, gr * 1.02 - 2), { fill: 'none', stroke: AL(GLASS.goldD, .45), sw: 1.2 });
    gl.path(A.skPath(GLASS.lx + gr - 2, gy - 6, GLASS.rx - gr + 2, gy - 6, r, 1.2), { stroke: GLASS.gold, sw: 3.4 });
    gl.path(A.skPath(GLASS.lx - gr + 2, gy - 8, 320, gy - 14, r, 1.4), { stroke: GLASS.gold, sw: 3.2 });
    gl.path(A.skPath(GLASS.rx + gr - 2, gy - 8, 582, gy - 14, r, 1.4), { stroke: GLASS.gold, sw: 3.2 });
    gl.path(A.polyPath([[GLASS.lx - 34, gy - 44], [GLASS.lx + 16, gy - 50], [GLASS.lx - 4, gy + 30], [GLASS.lx - 44, gy + 16]]), { fill: AL('#ffffff', p.shine ? .34 : .22) });
    gl.path(A.polyPath([[GLASS.rx - 34, gy - 44], [GLASS.rx + 16, gy - 50], [GLASS.rx - 4, gy + 30], [GLASS.rx - 44, gy + 16]]), { fill: AL('#ffffff', p.shine ? .3 : .16) });
    l.raw(gl.markup());

    // 6. 前发 / 侧发
    l.path(hairFront, { fill: '#332c27' });
    l.raw(A.wetBlob(hairFront, '#4a423c', '#1c1815', 907, { w: 5, f: .35, op: .5 }));
    l.path(A.smoothPath([[290, 300], [326, 220], [390, 186], [452, 188], [514, 214], [552, 282], [520, 238], [452, 218], [386, 226], [326, 262]], true), { fill: '#2f2925' });
    l.path(A.smoothPath([[326, 226], [368, 196], [388, 244], [372, 318], [352, 292]], true), { fill: '#282220', op: .95 });
    l.path(A.smoothPath([[394, 192], [448, 198], [436, 262], [410, 316], [394, 258]], true), { fill: '#282220', op: .95 });
    l.path(A.smoothPath([[466, 206], [512, 232], [496, 288], [466, 264]], true), { fill: '#282220', op: .92 });
    l.path(A.smoothPath([[524, 262], [552, 296], [540, 340], [514, 312]], true), { fill: '#282220', op: .9 });
    l.path(sideL, { fill: '#312a25' });
    l.path(sideR, { fill: '#312a25' });
    l.raw(A.wetBlob(sideL, '#3c342e', '#171412', 908, { w: 5, f: .4, op: .35 }));
    l.raw(A.wetBlob(sideR, '#3c342e', '#171412', 909, { w: 5, f: .4, op: .35 }));
    l.raw(A.wetBlob(A.blobPath(440, 214, 96, 24, r, .3), '#8d8073', '#3d3630', 910, { w: 5, f: .65, op: .38 }));
    for (var h = 0; h < 8; h++) {
      var hx = 356 + h * 24;
      l.path(A.skPath(hx, 192 + Math.abs(h - 3.5) * 9, hx + r.rng(-14, 20), 302 + r.rng(-70, 30), r, 3), { stroke: AL('#9b8e82', r.rng(.12, .32)), sw: r.rng(1.6, 3.8) });
    }
    for (var w2 = 0; w2 < 6; w2++) {
      l.path(A.skPath(536 + w2 * 6, 232 + w2 * 12, 600 + r.rng(0, 34), 262 + w2 * 28, r, 3), { stroke: AL('#3b342e', r.rng(.3, .6)), sw: r.rng(2, 3.6), lc: 'round' });
    }

    if (p.tilt) l.parts.unshift('<g transform="rotate(' + p.tilt + ' 450 700)">');
    var inner = l.markup();
    if (p.tilt) inner += '</g>';
    var out = st.layer();
    out.raw(inner);
    // 立绘去掉整张画布的底色与纸纹（否则会在背景上留下一个方块接缝）
    var svg = st.done({ paper: false });
    // 只在人物轮廓内补一层极淡的水彩纸纹（不使用 mix-blend-mode，避免影响背景）
    svg = svg.replace('</svg>',
      '<g clip-path="url(#spClip)" opacity="0.22">' +
      A.paperOverlay(1600, 900) + '</g></svg>');
    return svg.replace(/viewBox="0 0 1600 900" width="1600" height="900"/,
      'viewBox="150 60 620 1130" width="620" height="1130"');
  }

  /* =========================================================
   *  CG（5 张关键场景 + 通用大图）
   * ========================================================= */
  function r0(seed, k) { return R(seed + k); }

  var CG = {};

  CG.seat = function () { return SCENES.libSeat(new A.Scene(5101)); };
  CG.rec = function () {
    var st = new A.Scene(5102);
    SCENES.studio(st);
    st.layer().raw('<g transform="translate(170,20) scale(0.9)">' + bustInline('serious') + '</g>');
    return st.done();
  };
  CG.food = function () {
    var st = new A.Scene(5103);
    SCENES.canteen(st);
    st.layer().raw('<g transform="translate(360,20) scale(0.88)">' + bustInline('smile') + '</g>');
    var l = st.layer();
    l.raw(A.wetBlob(A.blobPath(1000, 648, 30, 15, r0(5103, 9), .28), '#ece4cf', '#a89c80', 512, { w: 3, f: .3, op: .92 }));
    l.path(A.skPath(982, 648, 958, 636, r0(5103, 10), 1.4), { stroke: '#a89c80', sw: 2.6, lc: 'round' });
    l.raw(A.wetBlob(A.blobPath(1000, 648, 46, 22, r0(5103, 11), .3), '#f6f0dc', '#c2b89e', 513, { w: 2, f: .6, op: .3 }));
    return st.done();
  };
  CG.snow = function () {
    var st = new A.Scene(5104);
    SCENES.roof(st);
    var l = st.layer();
    l.raw('<g transform="translate(60,30) scale(0.86)">' + bustInline('solemn') + '</g>');
    l.raw('<g transform="translate(620,40) scale(0.84)">' + bustInline('calm') + '</g>');
    var um = new A.Layer();
    var dome = A.smoothPath([[380, 430], [470, 300], [660, 262], [860, 316], [960, 436], [660, 392], [500, 404]], true);
    um.path(dome, { fill: '#3d4d72' });
    um.raw(A.wetBlob(dome, '#4a5c8c', '#1d2742', 601, { w: 6, f: .3, op: .5 }));
    for (var i = 0; i < 5; i++) um.path(A.skPath(660, 386, 420 + i * 132, 402 + i * 6, r0(5104, i), 3), { stroke: AL('#1d2742', .45), sw: 2.2 });
    um.path(A.skPath(660, 262, 660, 196, r0(5104, 20), 2), { stroke: '#3d4d72', sw: 7, lc: 'round' });
    um.path(A.skPath(660, 386, 660, 500, r0(5104, 21), 2), { stroke: '#6b5636', sw: 5, lc: 'round' });
    l.raw(um.markup());
    return st.done();
  };
  CG.autumn = function () { return autumnCG('true'); };
  CG.autumn2 = function () { return autumnCG('normal'); };
  function autumnCG(variant) {
    var st = new A.Scene(variant === 'normal' ? 5106 : 5105);
    var r = st.rnd;
    st.sky('#f7edd6', '#c6d4dc', { dx: .2, dy: 1, clouds: 12, cloudColor: '#fffdf4' });
    var l = st.layer();
    for (var i = 0; i < 16; i++) {
      var c = r.pick(['#c9a24c', '#a8813a', '#7d9a5f', '#e0b84c']);
      leafSpray(l, r.rng(60, 1540), r.rng(40, 620), r.rng(30, 70), r.rng(0, 6.28), r, c, r.rng(.3, .6));
    }
    var w = st.layer();
    w.raw(A.wetBlob(A.polyPath([[380, 90], [1240, 70], [1260, 600], [400, 620]]), '#f2e6c8', '#c8b48c', 521, { w: 8, f: .25, op: .5 }));
    for (var m = 1; m < 3; m++) w.path(A.skPath(380 + m * 288, 80, 386 + m * 288, 614, r, 3), { stroke: AL('#6b5a3e', .35), sw: 4 });
    var d = st.layer();
    d.raw(A.wetBlob(A.polyPath([[0, 640], [1600, 620], [1600, 900], [0, 900]]), '#c9a97a', '#8a6a44', 522, { w: 8, f: .22, op: .95 }));
    if (variant === 'normal') {
      d.raw(A.wetBlob(A.polyPath([[560, 690], [980, 676], [990, 840], [572, 856]]), '#e8dfc8', '#a89c80', 523, { w: 6, f: .2, op: .95 }));
      d.circle(690, 758, 40, { fill: AL('#c9bfa4', .7), stroke: AL('#8a8068', .8), sw: 4 });
      d.circle(860, 754, 40, { fill: AL('#c9bfa4', .7), stroke: AL('#8a8068', .8), sw: 4 });
      d.raw(A.wetBlob(A.polyPath([[1040, 690], [1420, 676], [1428, 800], [1048, 814]]), '#fbf5e4', '#ded2b6', 524, { w: 4, f: .18, op: .95 }));
      d.text(1090, 760, '如果……', { size: 46, fill: AL('#5f5340', .82), ls: 4 });
      d.path(A.skPath(1090, 782, 1240, 776, r, 2), { stroke: AL('#8a7c5e', .5), sw: 2 });
    } else {
      var hp = A.smoothPath([[560, 790], [590, 700], [640, 668], [700, 664], [760, 668], [812, 700], [844, 790], [700, 812]], true);
      d.raw(A.wetBlob(hp, '#2b3a63', '#16203a', 525, { w: 6, f: .25, op: .92 }));
      d.path(A.smoothPath([[560, 790], [516, 716], [536, 636], [596, 604]], false), { stroke: '#2b3a63', sw: 13, lc: 'round' });
      d.path(A.smoothPath([[844, 790], [890, 716], [866, 636], [806, 604]], false), { stroke: '#2b3a63', sw: 13, lc: 'round' });
      d.circle(700, 738, 62, { fill: AL('#4a5c8c', .5), stroke: AL('#e0b84c', .55), sw: 3 });
      d.raw(A.wetBlob(A.blobPath(700, 738, 96, 46, r, .18), '#3b4d79', '#1f2a49', 526, { w: 4, f: .5, op: .35 }));
      d.raw(A.wetBlob(A.blobPath(760, 470, 70, 34, r, .3), '#e0b84c', '#a8813a', 527, { w: 4, f: .4, op: .92 }));
      d.path(A.skPath(680, 486, 838, 458, r, 3), { stroke: AL('#8a6a2a', .6), sw: 2.4 });
      d.path(A.skPath(760, 480, 736, 570, r, 3), { stroke: AL('#a8813a', .6), sw: 2 });
    }
    lightShaft(st.layer(), 760, 100, 220, 520, r, '#fff3cf', .3);
    st.vignette('#5f5136', .24);
    return st.done();
  }

  CG.lake = function () { return SCENES.lake(new A.Scene(5107)); };
  CG.studio = function () { return SCENES.studio(new A.Scene(5108)); };
  CG.hall = function () { return SCENES.hall(new A.Scene(5109)); };
  CG.classroom = function () { return SCENES.classroom(new A.Scene(5110)); };
  CG.archive = function () { return SCENES.archive(new A.Scene(5111)); };
  CG.dorm = function () { return SCENES.dorm(new A.Scene(5112)); };
  CG.road = function () { return SCENES.road(new A.Scene(5113)); };
  CG.field = function () { return SCENES.field(new A.Scene(5114)); };
  CG.canteen = function () { return SCENES.canteen(new A.Scene(5115)); };
  CG.balcony = function () { return SCENES.balcony(new A.Scene(5116)); };
  CG.snowRoad = function () { return SCENES.snowRoad(new A.Scene(5117)); };
  CG.title = function () { return SCENES.title(new A.Scene(5118)); };
  CG.roof = function () { return SCENES.roof(new A.Scene(5119)); };
  CG.repair = function () { return SCENES.repair(new A.Scene(5120)); };
  CG.lib = function () { return SCENES.lib(new A.Scene(5121)); };

  var cache = {};
  function unwrap(v) {
    // 场景函数返回 Scene 对象，需要 .done() 得到 SVG 字符串
    return (v && typeof v.done === 'function') ? v.done() : v;
  }
  function get(key) {
    if (cache[key]) return cache[key];
    var fn = CG[key];
    var v = fn ? fn() : SCENES.lib(new A.Scene(5121));
    cache[key] = unwrap(v);
    return cache[key];
  }
  function spriteCached(e) {
    if (!cache['sp_' + e]) cache['sp_' + e] = sprite(e);
    return cache['sp_' + e];
  }
  function bust(e) {
    var s = spriteCached(e);
    return s.replace(/^[\s\S]*?<svg[^>]*>/, '').replace(/<\/svg>\s*$/, '');
  }

  // 供 CG 内联使用：连同 defs 一起返回
  function bustInline(e) {
    var src = spriteCached(e);
    var d = (/<defs>([\s\S]*?)<\/defs>/.exec(src) || [, ''])[1];
    var fs = d.match(/<filter id="paper"[^>]*>[\s\S]*?<\/filter>/);
    if (fs) d = d.replace(fs[0], '');
    var body = src.replace(/^[\s\S]*?<svg[^>]*>/, '').replace(/<\/svg>\s*$/, '').replace(/<defs>[\s\S]*?<\/defs>/, '');
    return '<defs>' + d + '</defs>' + body;
  }
  function spriteSVG(e, mirror) {
    var src = spriteCached(e);
    if (!mirror) return src;
    var vm = /viewBox="([^"]+)"/.exec(src);
    var vb = vm ? vm[1].split(/\s+/).map(Number) : [0, 0, 620, 1130];
    var d = (/<defs>([\s\S]*?)<\/defs>/.exec(src) || [, ''])[1];
    var body = src.replace(/^[\s\S]*?<svg[^>]*>/, '').replace(/<\/svg>\s*$/, '').replace(/<defs>[\s\S]*?<\/defs>/, '');
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="' + vb.join(' ') + '" width="' + vb[2] + '" height="' + vb[3] + '">' +
      '<defs>' + d + '</defs>' +
      '<g transform="translate(' + (vb[0] * 2 + vb[2]) + ',0) scale(-1,1)">' + body + '</g></svg>';
  }
  function spriteBust(e, mirror) { return spriteSVG(e, mirror); }

  return { get: get, sprite: spriteCached, spriteSVG: spriteSVG, spriteBust: spriteBust, bust: bust, bustInline: bustInline, EXPR: EXPR, PAL: PAL, SCENES: SCENES };
})();

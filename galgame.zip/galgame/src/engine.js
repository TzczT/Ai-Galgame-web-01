/* ===========================================================
 *  engine.js —— 视觉小说引擎（对话 / 选项 / 存读档 / 鉴赏 / 回顾 / 自动跳过）
 * =========================================================== */
var Game = (function () {
  var VERSION = 'save_v1';
  var G = {
    name: '江知远', chapter: '序章',
    flags: {}, mem: [], love: 0,
    idx: 0, owner: null, seen: {}, cgs: {}, mus: {}, choiceLog: [],
    autoTimer: null, skipTimer: null, typing: false,
    settings: { speed: 22, music: 0.5, sfx: 0.6, autoWait: 1500, effect: true },
    playing: 'gold'
  };
  var BG = { bg: 'lib', sprite: null, cg: null, music: null, lamp: false, speaker: '', heroine: false };
  var META = null;
  var bgEl, spriteEl, cgEl, textEl, spkEl, nextEl, choiceEl, chapterEl, endingEl, hudEl, toastEl;
  var typingTimer = null, fullText = '', typePos = 0, textDone = true, lineStart = 0;

  function $(id) { return document.getElementById(id); }
  function esc(s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }
  function applyName(s) {
    return String(s).replace(/\{name\}/g, G.name).replace(/\{name1\}/g, G.name.charAt(0));
  }

  /* ---------------- 存档 ---------------- */
  function store(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { } }
  function load(k) { try { var s = localStorage.getItem(k); return s ? JSON.parse(s) : null; } catch (e) { return null; } }
  function snapshot(label) {
    return {
      v: VERSION, name: G.name, idx: G.idx, flags: JSON.parse(JSON.stringify(G.flags)),
      mem: G.mem.slice(), love: G.love, chapter: G.chapter, ts: Date.now(),
      label: label || (META.script[G.idx] && META.script[G.idx].s ? String(META.script[G.idx].s).slice(0, 14) : '')
    };
  }
  function applySnapshot(s) {
    G.name = s.name || G.name; G.idx = s.idx || 0; G.flags = s.flags || {}; G.mem = s.mem || []; G.love = s.love || 0;
    G.chapter = s.chapter || '序章';
    renderFromScratch();
  }
  function autoSave() { store(VERSION + '_auto', snapshot('自动存档')); }
  function saveSlot(i) { store(VERSION + '_s' + i, snapshot()); }
  function loadSlot(i) { var s = load(VERSION + '_s' + i); return s; }
  function lastSave() { return load(VERSION + '_auto') || load(VERSION + '_quick') || null; }

  /* ---------------- 条件 ---------------- */
  function cond(c) {
    if (!c) return true;
    if (typeof c === 'function') return !!c(G);
    // 注意：内联 script 里 '&' 可能被 HTML 解析转义，所以条件用逗号分隔的 AND 列表
    c = String(c).replace(/&amp;/g, '&').replace(/s*&&s*/g, ',');
    return c.split(',').every(function (one) {
      one = one.trim();
      var m;
      if ((m = /^flags\.(\w+)$/.exec(one))) return !!G.flags[m[1]];
      if ((m = /^!flags\.(\w+)$/.exec(one))) return !G.flags[m[1]];
      if ((m = /^love>=(-?\d+)$/.exec(one))) return G.love >= parseInt(m[1], 10);
      if ((m = /^mem>=(\d+)$/.exec(one))) return G.mem.length >= parseInt(m[1], 10);
      if ((m = /^has:(.+)$/.exec(one))) return G.mem.indexOf(m[1]) >= 0;
      return true;
    });
  }
  var LABELS = null;
  function buildLabels() {
    LABELS = {};
    for (var i = 0; i < META.script.length; i++) {
      var n = META.script[i];
      if (n && n.t === 'label' && n.label && LABELS[n.label] === undefined) LABELS[n.label] = i;
    }
  }
  function labelIndex(name) {
    if (!LABELS) buildLabels();
    return LABELS[name] === undefined ? -1 : LABELS[name];
  }

  /* ---------------- 渲染 ---------------- */
  function setBG(bg, opt) {
    if (!bg || BG.bg === bg) return;
    BG.bg = bg;
    var svg = ARTWORK.get(bg);
    bgEl.innerHTML = svg;
    if (G.settings.effect) {
      bgEl.animate ? bgEl.animate([{ opacity: 0, transform: 'scale(1.04)' }, { opacity: 1, transform: 'scale(1)' }], { duration: 700, easing: 'ease-out' }) : 0;
    }
  }
  function setSprite(expr, opt) {
    opt = opt || {};
    if (!expr) { spriteEl.innerHTML = ''; BG.sprite = null; return; }
    var key = expr + (opt.mirror ? 'm' : '');
    if (BG.sprite === key) return;
    BG.sprite = key;
    spriteEl.innerHTML = '<div class="sprite">' + ARTWORK.spriteSVG(expr, opt.mirror) + '</div>';
    spriteEl.classList.remove('out');
  }
  function setCG(key, opt) {
    if (!key) { cgEl.innerHTML = ''; cgEl.style.display = 'none'; BG.cg = null; return; }
    BG.cg = key; G.cgs[key] = 1; store(VERSION + '_cg', G.cgs);
    cgEl.style.display = 'block';
    cgEl.innerHTML = '<div class="cg-wrap">' + ARTWORK.get(key) + '</div>';
    cgEl.style.opacity = 0;
    requestAnimationFrame(function () { cgEl.style.transition = 'opacity .8s'; cgEl.style.opacity = 1; });
    spriteEl.innerHTML = ''; BG.sprite = null;
  }
  function setMusic(name) {
    if (!name || BG.music === name) return;
    BG.music = name; G.mus[name] = 1; store(VERSION + '_mus', G.mus);
    SOUND.play(name);
    G.playing = name;
  }
  function lamp(on) {
    BG.lamp = on;
    $('tape-lamp').classList.toggle('on', !!on);
  }
  function toast(msg) {
    toastEl.textContent = msg; toastEl.classList.add('on');
    clearTimeout(toastEl._t); toastEl._t = setTimeout(function () { toastEl.classList.remove('on'); }, 1500);
  }

  /* ---------------- 打字机 ---------------- */
  function typeWrite(s) {
    fullText = applyName(s);
    typePos = 0; textDone = false;
    lineStart = Date.now();
    nextEl.classList.remove('on');
    textEl.textContent = '';
    clearInterval(typingTimer);
    var speed = G.settings.speed;
    if (speed <= 0) { finishText(); return; }
    typingTimer = setInterval(function () {
      typePos += Math.min(2, fullText.length - typePos);
      textEl.textContent = fullText.slice(0, typePos);
      if (typePos >= fullText.length) finishText();
    }, speed);
    // 看门狗：任何异常导致打字停摆时，1.2 秒后强制补全，绝不让玩家卡在"文字不动"
    if (G._wd) clearTimeout(G._wd);
    G._wd = setTimeout(function () { if (!textDone) finishText(); }, 1200 + fullText.length * speed * 0.6);
  }
  function finishText() {
    clearInterval(typingTimer);
    textEl.textContent = fullText;
    textDone = true;
    if (speedZero()) { }
    nextEl.classList.add('on');
  }
  function speedZero() { return G.settings.speed <= 0; }

  /* ---------------- 主循环 ---------------- */
  function run() {
    try {
      // 推进环看门狗：同一节点短时间内被反复到达，强制往后走，保证任何情况下都能继续
      var now = Date.now();
      if (G.__lastIdx === G.idx) {
        if (now - (G.__lastAt || 0) > 650) {
          if (G.__loopCount === undefined) G.__loopCount = 0;
          G.__loopCount++;
          if (G.__loopCount > 2) { G.__loopCount = 0; G.idx++; }
          G.__lastAt = now;
        }
      } else { G.__lastIdx = G.idx; G.__lastAt = now; G.__loopCount = 0; }
      runInner();
    } catch (e) {
      // 任何异常都不能让剧情停住：记录后强制推进一格
      if (window.console && console.warn) console.warn('[galgame] run() 异常，已强制推进：', e);
      G.idx++;
    }
  }
  function runInner() {
    if (G.endingLock) return; // 结局卡播放期间冻结流程，避免两次 run 竞态穿透到另一个结局
    clearTimeout(G.autoTimer);
    var guard = 0;
    while (guard++ < 20000) {
      if (G.idx >= META.script.length) {
        // 剧本播完：回到标题，给出明确提示
        toast('这一期播完了。回到标题可以重录。');
        showScreen('title-screen');
        return;
      }
      if (G.idx < 0) G.idx = 0;
      var n = META.script[G.idx];
      if (typeof n === 'string') { G.idx++; continue; }
      var next = false;
      switch (n.t) {
        case 'label': G.idx++; next = true; break;
        case 'chapter':
          G.chapter = n.name;
          showChapter(n.name, n.sub, function () { G.idx++; run(); });
          return;
        case 'bg': setBG(n.name); G.idx++; next = true; break;
        case 'sprite': setSprite(n.e, { mirror: n.mirror }); G.idx++; next = true; break;
        case 'hide': setSprite(null); G.idx++; next = true; break;
        case 'cg': setCG(n.name); G.idx++; next = true; break;
        case 'cgEnd': setCG(null); G.idx++; next = true; break;
        case 'music': setMusic(n.name); G.idx++; next = true; break;
        case 'lamp': lamp(n.on); G.idx++; next = true; break;
        case 'sfx': SOUND.sfx(n.name); G.idx++; next = true; break;
        case 'fx': if (n.name === 'shake' && G.settings.effect) { document.getElementById('app').animate([{ transform: 'translate(0,0)' }, { transform: 'translate(-7px,4px)' }, { transform: 'translate(6px,-3px)' }, { transform: 'translate(0,0)' }], { duration: 420 }); } G.idx++; next = true; break;
        case 'set': G.flags[n.k] = (n.v === undefined ? 1 : n.v); if (n.love) G.love += n.love; if (n.mem && G.mem.indexOf(n.mem) < 0) G.mem.push(n.mem); G.idx++; next = true; break;
        case 'mem': if (G.mem.indexOf(n.s) < 0) G.mem.push(n.s); G.idx++; next = true; break;
        case 'jump':
          var ti = labelIndex(n.target || n.label);
          if (ti < 0) { console.warn('missing label', n.label); G.idx++; } else G.idx = ti;
          next = true; break;
        case 'if':
        case 'route':
          var tIdx = labelIndex(cond(n.cond) ? n.then : n.else);
          G.idx = tIdx >= 0 ? tIdx : G.idx + 1;
          next = true; break;
        case 'ending':
          showEnding(n.kind, n.title, n.sub, n.after);
          return;
        case 'choice':
          showChoice(n); return;
        case 'say':
        default:
          if (n.t === 'say' || n.speak !== undefined || n.text !== undefined) {
            var who = n.who === undefined ? (n.t === 'say' ? '' : '') : n.who;
            var isH = who === 'longer' || who === '她';
            spkEl.className = 'speaker' + (who ? (isH ? ' heroine' : '') : ' narr');
            if (!who) { spkEl.className = 'speaker empty'; spkEl.textContent = ''; }
            else spkEl.textContent = who === 'longer' ? (n.label2 || 'longer') : who;
            G.seen[G.idx] = 1;
            G.history = G.history || [];
            G.history.push({ s: who, x: applyName(n.text || ''), c: G.chapter });
            if (G.history.length > 400) G.history.shift();
            typeWrite(n.text || '');
            autoSave();
            if (G.skipOn && G.seen[G.idx]) { G.skipTimer = setTimeout(function () { if (G.skipOn) { finishText(); click(); } }, 26); }
            else if (G.autoOn) {
              var dur = Math.min(9000, 900 + (n.text || '').length * (G.settings.speed + 42));
              G.autoTimer = setTimeout(function () { if (G.autoOn) click(); }, dur + G.settings.autoWait);
            }
            return;
          }
          G.idx++; next = true;
      }
      if (!next) return;
    }
  }
  function click() {
    G.clicks = (G.clicks || 0) + 1;
    try { SOUND.resume(); } catch (e) { }
    if (chapterEl.classList.contains('on')) { if (G.chapterDismiss) G.chapterDismiss(); return; }
    if (!textDone) {
      finishText();
      // 这一句已经显示了足够久，说明玩家是在"往下读"，同一次点击直接推进
      if (Date.now() - lineStart > 90) { /* 继续往下走 */ } else { return; }
    }
    if (choiceEl.classList.contains('on')) return;
    if (endingEl.classList.contains('on')) return;
    try { SOUND.sfx('click'); } catch (e) { }
    G.idx++; run();
  }

  function showChoice(n) {
    choiceEl.innerHTML = '';
    var opts = n.options.filter(function (o) { return cond(o.cond); });
    opts.forEach(function (o, i) {
      var b = document.createElement('div');
      b.className = 'choice';
      b.innerHTML = (o.tag ? '<span class="tag">' + esc(o.tag) + '</span>' : '') + esc(applyName(o.text));
      b.onclick = function () {
        SOUND.sfx('select');
        choiceEl.classList.remove('on'); choiceEl.innerHTML = '';
        if (o.set) { for (var k in o.set) G.flags[k] = o.set[k]; }
        if (o.love) G.love += o.love;
        if (o.mem && G.mem.indexOf(o.mem) < 0) G.mem.push(o.mem);
        G.choiceLog.push({ c: G.chapter, text: o.text, at: Date.now() });
        var ti = labelIndex(o.goto);
        if (ti < 0) { console.warn('bad goto ' + o.goto); G.idx++; } else G.idx = ti;
        autoSave();
        run();
      };
      choiceEl.appendChild(b);
    });
    choiceEl.classList.add('on');
  }

  function showChapter(name, sub, cb) {
    if (!G.settings.effect) { cb(); return; }
    chapterEl.innerHTML = '<div class="cc-k">CHAPTER</div><div class="cc-t">' + esc(name) + '</div>' +
      (sub ? '<div class="cc-s">' + esc(sub) + '</div>' : '') +
      '<div class="cc-hint">点击任意处继续</div>';
    chapterEl.classList.add('on');
    var fired = false, started = Date.now();
    function done() {
      if (fired) return; fired = true;
      clearTimeout(t1);
      chapterEl.classList.remove('on');
      setTimeout(cb, 320);
    }
    var t1 = setTimeout(done, 1900);
    // 点击章节卡立即进入正文（至少要显示 350ms，避免误触）
    G.chapterDismiss = function () { if (Date.now() - started > 350) { done(); return true; } return false; };
  }
  function showEnding(kind, title, sub, after) {
    G.endingLock = true;
    endingEl.innerHTML = '<div class="e-k">' + (kind === 'true' ? 'TRUE END' : 'NORMAL END') + '</div>' +
      '<div class="e-t">' + esc(title) + '</div><div class="e-s">' + esc(sub) + '</div>';
    endingEl.classList.add('on');
    endingEl.style.pointerEvents = 'auto';
    G.ending = kind;
    store(VERSION + '_end_' + kind, { ts: Date.now(), name: G.name, love: G.love, mem: G.mem.slice(), choices: G.choiceLog });
    setTimeout(function () {
      endingEl.classList.remove('on');
      endingEl.style.pointerEvents = '';
      setTimeout(function () {
        var ti = after ? labelIndex(after) : -1;
        G.idx = ti >= 0 ? ti : G.idx + 1;
        G.endingLock = false;
        run();
      }, 1400);
    }, 5200 + (after ? 0 : 0));
  }

  /* ---------------- 弹层 ---------------- */
  function modal(title, html) {
    $('modal-head').innerHTML = '<span>' + esc(title) + '</span><button class="cls">关闭</button>';
    $('modal-body').innerHTML = html;
    $('modal').classList.add('on');
    $('modal-head').querySelector('.cls').onclick = function () { SOUND.sfx('back'); closeModal(); };
  }
  function closeModal() { $('modal').classList.remove('on'); }

  function openGallery() {
    var list = (META.cglist || []);
    var h = '<div class="m-row">';
    list.forEach(function (c) {
      var got = !!G.cgs[c.key];
      h += '<div class="m-card' + (got ? '' : ' locked') + '" data-cg="' + c.key + '">' +
        '<div class="thumb' + (got ? '' : ' locked') + '">' + ARTWORK.get(c.key) + '</div>' +
        '<div class="cap">' + esc(got ? c.name : '？？？') + '<small>' + esc(c.desc || '') + '</small></div></div>';
    });
    h += '</div>';
    modal('CG 鉴赏 ' + Object.keys(G.cgs).length + ' / ' + list.length, h);
    Array.prototype.forEach.call($('modal-body').querySelectorAll('[data-cg]'), function (el) {
      el.onclick = function () {
        var k = el.getAttribute('data-cg');
        if (!G.cgs[k]) { toast('这段录音还没有被翻出来'); return; }
        SOUND.sfx('select');
        var big = document.createElement('div');
        big.style.cssText = 'position:absolute;inset:0;background:rgba(8,8,10,.94);z-index:70;display:flex;align-items:center;justify-content:center';
        big.innerHTML = '<div style="width:92vw;height:86vh">' + ARTWORK.get(k) + '</div>';
        big.onclick = function () { big.remove(); };
        document.getElementById('app').appendChild(big);
      };
    });
  }
  function openMusic() {
    var list = META.musiclist || [];
    var h = '';
    list.forEach(function (m) {
      var got = !!G.mus[m.key] || m.key === 'gold';
      h += '<div class="m-track' + (G.playing === m.key ? ' playing' : '') + '" data-m="' + m.key + '" data-lock="' + (got ? 0 : 1) + '">' +
        '<div><div class="tt"><span class="eq">♪</span> ' + esc(got ? m.name : '？？？') + '</div><div class="td">' + esc(m.desc || '') + '</div></div>' +
        '<div class="tp">' + (got ? (G.playing === m.key ? '正在播放' : '播放') : '未解锁') + '</div></div>';
    });
    modal('音乐鉴赏', h);
    Array.prototype.forEach.call($('modal-body').querySelectorAll('[data-m]'), function (el) {
      el.onclick = function () {
        if (el.getAttribute('data-lock') === '1') { toast('听到之后才能收录'); return; }
        var k = el.getAttribute('data-m');
        BG.music = null; setMusic(k); G.playing = k;
        SOUND.sfx('select');
        openMusic();
      };
    });
  }
  function openLog() {
    var h = '<div class="hist">';
    (G.history || []).slice(-220).forEach(function (e) {
      var cls = e.s === 'longer' ? 'hz' : (e.s ? '' : 'nr');
      h += '<div class="hi ' + cls + '">' + (e.s ? '<b>' + esc(e.s === 'longer' ? 'longer' : e.s) + '</b>' : '') + esc(e.x) + '</div>';
    });
    h += '</div>';
    modal('历史回顾', h);
    var b = $('modal-body'); b.scrollTop = b.scrollHeight;
  }
  function openSave(mode) {
    var h = '';
    for (var i = 1; i <= 5; i++) {
      var s = loadSlot(i);
      var head = s ? (s.chapter + ' · ' + (s.label || '')) : '空';
      var ti = s ? new Date(s.ts).toLocaleString('zh-CN') : '';
      h += '<div class="slot"><div><div class="sn">第 ' + i + ' 槽 · ' + esc(head) + '</div><div class="si">' + esc(ti) + '</div></div>' +
        '<div>' + (mode === 'save' ? '<button data-save="' + i + '">存档</button>' : '') +
        '<button data-load="' + i + '"' + (s ? '' : ' disabled') + '>读档</button>' +
        '<button data-del="' + i + '"' + (s ? '' : ' disabled') + '>删除</button></div></div>';
    }
    modal(mode === 'save' ? '存档' : '读档', h);
    var body = $('modal-body');
    Array.prototype.forEach.call(body.querySelectorAll('button'), function (b) {
      b.onclick = function () {
        var i = parseInt(b.getAttribute('data-save') || b.getAttribute('data-load') || b.getAttribute('data-del'), 10);
        if (b.hasAttribute('data-save')) { saveSlot(i); SOUND.sfx('select'); toast('已存档：第 ' + i + ' 槽'); openSave('save'); }
        else if (b.hasAttribute('data-load')) { var s = loadSlot(i); if (s) { SOUND.sfx('select'); closeModal(); applySnapshot(s); toast('已读取：第 ' + i + ' 槽'); } }
        else { localStorage.removeItem(VERSION + '_s' + i); SOUND.sfx('back'); openSave(mode); }
      };
    });
  }
  function openConfig() {
    var s = G.settings;
    var h = '<div class="set-row"><label>文字速度</label><input type="range" id="cfg-speed" min="0" max="90" step="2" value="' + s.speed + '"/><span class="val" id="v-speed">' + (s.speed <= 0 ? '瞬间' : s.speed + 'ms') + '</span></div>' +
      '<div class="set-row"><label>音乐音量</label><input type="range" id="cfg-music" min="0" max="100" value="' + Math.round(s.music * 100) + '"/><span class="val" id="v-music">' + Math.round(s.music * 100) + '</span></div>' +
      '<div class="set-row"><label>音效音量</label><input type="range" id="cfg-sfx" min="0" max="100" value="' + Math.round(s.sfx * 100) + '"/><span class="val" id="v-sfx">' + Math.round(s.sfx * 100) + '</span></div>' +
      '<div class="set-row"><label>演出特效</label><input type="checkbox" id="cfg-fx" ' + (s.effect ? 'checked' : '') + '/><span class="val"></span></div>' +
      '<div class="set-row"><label>自动播放间隔</label><input type="range" id="cfg-auto" min="400" max="4000" step="200" value="' + s.autoWait + '"/><span class="val" id="v-auto">' + s.autoWait + 'ms</span></div>';
    modal('设置', h);
    function bind(id, fn, vid, fmt) {
      var el = $(id); if (!el) return;
      el.oninput = el.onchange = function () { fn(el); if (vid) $(vid).textContent = fmt(el); };
    }
    bind('cfg-speed', function (el) { s.speed = parseInt(el.value, 10); }, 'v-speed', function (el) { return parseInt(el.value, 10) <= 0 ? '瞬间' : el.value + 'ms'; });
    bind('cfg-music', function (el) { s.music = parseInt(el.value, 10) / 100; SOUND.setMusicVol(s.music); }, 'v-music', function (el) { return el.value; });
    bind('cfg-sfx', function (el) { s.sfx = parseInt(el.value, 10) / 100; SOUND.setSfxVol(s.sfx); }, 'v-sfx', function (el) { return el.value; });
    bind('cfg-auto', function (el) { s.autoWait = parseInt(el.value, 10); }, 'v-auto', function (el) { return el.value + 'ms'; });
    var fx = $('cfg-fx'); if (fx) fx.onchange = function () { s.effect = fx.checked; };
    persistSettings();
  }
  function persistSettings() { store(VERSION + '_cfg', G.settings); }
  function openHelp() {
    modal('关于 / 操作', '<div class="help">' +
      '<h4>操作</h4>' +
      '<p>鼠标左键 / 空格 / 回车：推进对话 · 打字中点击＝立即显示全部</p>' +
      '<p>Ctrl（按住）：跳过已读 · A：自动播放 · H：历史回顾 · Esc：设置</p>' +
      '<p>存档为 5 槽手动 + 1 自动，进度实时写入浏览器本地存储。</p>' +
      '<h4>玩法</h4>' +
      '<p>本作共 4 个关键选项，只影响「好感」「记忆碎片」与 True Flag，不改变单线框架。' +
      'True End《下一个秋天》需要四个关键选项全部选对；否则进入 Normal End《把磁带交给下一个秋天》。</p>' +
      '<h4>主题</h4>' +
      '<p>全年龄 · 单女主 · 无后宫 · 无三角恋 · 场景限定在中国大学校园内。</p>' +
      '<h4>构成</h4>' +
      '<p>全部立绘、场景、CG 由程序化水彩 SVG 现场绘制；全部 BGM 由 WebAudio 实时合成。无任何外部素材文件。</p>' +
      '</div>');
  }

  // 渲染"当前所在节点"（用于开局 / 读档后，避免文本框空白）
  function renderCurrentNode() {
    var n = META.script[G.idx];
    if (!n || typeof n === 'string') return;
    if (n.text !== undefined) {
      var who = n.s || '';
      var isH = who === 'longer' || who === '她';
      spkEl.className = 'speaker' + (who ? (isH ? ' heroine' : '') : ' narr');
      if (!who) { spkEl.className = 'speaker empty'; spkEl.textContent = ''; }
      else spkEl.textContent = who === 'longer' ? 'longer' : who;
      typeWrite(n.text);
    }
  }

  /* ---------------- 从剧本重建画面 ---------------- */
  function renderFromScratch() {
    // 从当前位置向前回溯，恢复 bg / sprite / music / lamp
    BG.bg = null; BG.sprite = null; BG.music = null;
    setCG(null);
    spriteEl.innerHTML = '';
    var bg = null, spr = null, mus = null, lampOn = false, mirror = false, i, n;
    // 背景从当前节点往回找（BGM 早期设定，背景常常中途切换）
    for (i = Math.min(G.idx, META.script.length - 1); i >= 0; i--) {
      n = META.script[i]; if (typeof n === 'string') continue;
      if (n.t === 'bg') { bg = n.name; break; }
    }
    // 立绘 / 音乐 / 录音灯 从头顺序还原
    for (i = 0; i <= G.idx && i < META.script.length; i++) {
      n = META.script[i]; if (typeof n === 'string') continue;
      if (n.t === 'cg' || n.t === 'cgEnd') { spr = spr; }
      if (n.t === 'sprite') { spr = n.e; mirror = !!n.mirror; }
      else if (n.t === 'hide') spr = null;
      else if (n.t === 'music') mus = n.name;
      else if (n.t === 'lamp') lampOn = !!n.on;
    }
    setBG(bg);
    setSprite(spr, { mirror: mirror });
    if (mus) setMusic(mus);
    lamp(lampOn);
    // 若当前位置正是一句台词，先把台词显示出来，再继续流程
    var cur = META.script[G.idx];
    if (cur && typeof cur !== 'string' && cur.text !== undefined && cur.t === undefined && cur.s === undefined) {
      renderCurrentNode();
      return;
    }
    if (cur && typeof cur !== 'string' && cur.text !== undefined) { renderCurrentNode(); return; }
    run();
  }

  /* ---------------- 启动 ---------------- */
  function startNew() {
    G.flags = {}; G.mem = []; G.love = 0; G.history = []; G.choiceLog = []; G.idx = 0; G.chapter = '序章';
    BG.bg = null; BG.sprite = null; BG.music = null; BG.cg = null;
    cgEl.innerHTML = ''; spriteEl.innerHTML = '';
    showScreen('game-screen');
    renderFromScratch();
  }
  function showScreen(id) {
    Array.prototype.forEach.call(document.querySelectorAll('.screen'), function (s) { s.classList.remove('active'); });
    $(id).classList.add('active');
    if (id === 'game-screen' && G.rebind) { try { G.rebind(); } catch (e) { } }
  }
  function bindHud() {
    Array.prototype.forEach.call(document.querySelectorAll('.hbtn'), function (b) {
      b.onclick = function (e) {
        e.stopPropagation();
        var a = b.getAttribute('data-act');
        SOUND.resume();
        if (a === 'auto') { G.autoOn = !G.autoOn; b.classList.toggle('active', G.autoOn); toast(G.autoOn ? '自动播放：开' : '自动播放：关'); if (G.autoOn) click(); }
        else if (a === 'skip') { G.skipOn = !G.skipOn; b.classList.toggle('active', G.skipOn); toast(G.skipOn ? '跳过：开（仅已读）' : '跳过：关'); if (G.skipOn) click(); }
        else if (a === 'log') openLog();
        else if (a === 'save') openSave('save');
        else if (a === 'load') openSave('load');
        else if (a === 'config') openConfig();
        else if (a === 'title') { autoSave(); showScreen('title-screen'); }
      };
    });
  }
  function bindInput() {
    window.__bind = (window.__bind || 0) + 1;
    document.addEventListener('keydown', function (e) {
      if ($('modal').classList.contains('on')) { if (e.key === 'Escape') closeModal(); return; }
      if (!$('game-screen').classList.contains('active')) {
        if (e.key === ' ' || e.key === 'Enter') { var b = document.querySelector('.t-btn.primary'); if (b && $('title-screen').classList.contains('active')) b.click(); }
        return;
      }
      if (e.key === ' ' || e.key === 'Enter') { e.preventDefault(); click(); }
      else if (e.key === 'a' || e.key === 'A') { G.autoOn = !G.autoOn; toast(G.autoOn ? '自动播放：开' : '自动播放：关'); if (G.autoOn) click(); }
      else if (e.key === 'h' || e.key === 'H') openLog();
      else if (e.key === 'Escape') openConfig();
      else if (e.key === 'Control') G.skipOn = true;
    });
    document.addEventListener('keyup', function (e) { if (e.key === 'Control') G.skipOn = false; });
    // 舞台点击：同时挂在 game-screen 与 document 上，双保险；用 rAF 做重复触发保护
    function stageClick(e) {
      if (!document.getElementById('game-screen').classList.contains('active')) return;
      if (e.target && e.target.classList && e.target.classList.contains('hbtn')) return;
      if (choiceEl.classList.contains('on')) return;
      var now = Date.now();
      if (now - (G._lastClickAt || 0) < 30) return;   // 两个监听别重复触发
      G._lastClickAt = now;
      click();
    }
    document.getElementById('game-screen').addEventListener('click', stageClick);
    document.addEventListener('click', stageClick);
    document.getElementById('choice-layer').addEventListener('click', function (e) { e.stopPropagation(); });
    G.rebind = function () {
      var gs = document.getElementById('game-screen');
      gs.removeEventListener('click', stageClick);
      gs.addEventListener('click', stageClick);
      document.removeEventListener('click', stageClick);
      document.addEventListener('click', stageClick);
    };
  }
  function bindTitle() {
    Array.prototype.forEach.call(document.querySelectorAll('[data-act]'), function (b) {
      if (b.classList.contains('hbtn')) return;
      var a = b.getAttribute('data-act');
      if (a === 'start') b.onclick = function () { SOUND.init(); SOUND.resume(); SOUND.sfx('select'); showScreen('name-screen'); $('name-input').focus(); };
      else if (a === 'continue') b.onclick = function () {
        SOUND.init(); SOUND.resume();
        var s = lastSave();
        if (!s) { toast('还没有任何存档'); return; }
        showScreen('game-screen');
        if (s.name) G.name = s.name;
        applySnapshot(s);
        toast('继续收听 · ' + s.chapter);
      };
      else if (a === 'gallery') b.onclick = function () { SOUND.init(); SOUND.sfx('select'); openGallery(); };
      else if (a === 'music') b.onclick = function () { SOUND.init(); SOUND.resume(); SOUND.sfx('select'); openMusic(); };
      else if (a === 'help') b.onclick = function () { SOUND.sfx('select'); openHelp(); };
    });
    $('name-ok').onclick = function () {
      var v = ($('name-input').value || '').trim();
      G.name = v || '江知远';
      SOUND.sfx('select'); startNew();
    };
    $('name-default').onclick = function () { $('name-input').value = '江知远'; $('name-ok').click(); };
    $('name-input').addEventListener('keydown', function (e) { if (e.key === 'Enter') $('name-ok').click(); });
  }
  function bootScript(meta) {
    META = meta;
    bgEl = $('bg-layer'); spriteEl = $('sprite-layer'); cgEl = $('cg-layer');
    textEl = $('text'); spkEl = $('speaker'); nextEl = $('nextmark');
    choiceEl = $('choice-layer'); chapterEl = $('chapter-card'); endingEl = $('ending-card');
    toastEl = $('toast');
    cgEl.style.display = 'none';
    // 读取进度
    G.cgs = load(VERSION + '_cg') || {};
    G.mus = load(VERSION + '_mus') || {};
    var cfg = load(VERSION + '_cfg'); if (cfg) for (var k in cfg) G.settings[k] = cfg[k];
    // 标题背景
    $('title-art').innerHTML = ARTWORK.get('title');
    bindHud(); bindInput(); bindTitle();
    // 调试：?jump=节点序号  直接跳到某句台词（供截图/自测）
    var q = /[?&]jump=(\d+)/.exec(location.search);
    if (q) {
      var n = parseInt(q[1], 10);
      G.flags = {}; G.mem = []; G.love = 0; G.history = [];
      var fq = /[?&]flags=([a-z_,0-9]+)/.exec(location.search);
      if (fq) fq[1].split(',').forEach(function (k) { if (k) G.flags[k] = 1; });
      var lq = /[?&]love=(\d+)/.exec(location.search);
      if (lq) G.love = parseInt(lq[1], 10);
      var nq = /[?&]player=([^&]+)/.exec(location.search);
      if (nq) G.name = decodeURIComponent(nq[1]);
      G.idx = n; G.chapter = '调试';
      showScreen('game-screen');
      renderFromScratch();
      // ?local=1 时禁用「继续收听」，避免自动存档覆盖调试状态
      if (/[?&]local=1/.test(location.search)) {
        var cb = document.querySelector('[data-act="continue"]');
        if (cb) cb.style.display = 'none';
      }
    }
    // 空格推进已绑定
    document.addEventListener('mousedown', function () { SOUND.resume(); }, { once: true });
  }
  return { boot: bootScript, get state() { return G; }, showScreen: showScreen };
})();
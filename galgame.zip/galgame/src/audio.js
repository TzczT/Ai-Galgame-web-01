/* ===========================================================
 *  audio.js —— 全程序化 BGM / 音效（WebAudio，无任何外部音频文件）
 *  5 首主题曲：金线 / 四楼的斜光 / 磁头与棉签 / 高频先走的蝉 / 最后一次广播
 * =========================================================== */
var SOUND = (function () {
  var ctx = null, master, busMusic, busSfx, ready = false;
  var noiseBuf = null;

  function init() {
    if (ready) return true;
    var AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return false;
    ctx = new AC();
    master = ctx.createGain(); master.gain.value = 0.9;
    var comp = ctx.createDynamicsCompressor ? ctx.createDynamicsCompressor() : null;
    busMusic = ctx.createGain(); busMusic.gain.value = 0.5;
    busSfx = ctx.createGain(); busSfx.gain.value = 0.6;
    busMusic.connect(master); busSfx.connect(master);
    if (comp) { master.connect(comp); comp.connect(ctx.destination); } else master.connect(ctx.destination);
    // 噪声缓冲（雨 / 磁带嘶声 / 沙锤）
    var len = ctx.sampleRate * 2;
    noiseBuf = ctx.createBuffer(1, len, ctx.sampleRate);
    var d = noiseBuf.getChannelData(0);
    for (var i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    ready = true;
    return true;
  }
  function resume() { if (!ctx) init(); if (ctx && ctx.state === 'suspended') ctx.resume(); }
  function now() { return ctx.currentTime; }

  function setMusicVol(v) { if (busMusic) busMusic.gain.value = v; }
  function setSfxVol(v) { if (busSfx) busSfx.gain.value = v; }

  // ---------- 音名 ----------
  var SEMI = { c: 0, 'c#': 1, db: 1, d: 2, 'd#': 3, eb: 3, e: 4, f: 5, 'f#': 6, gb: 6, g: 7, 'g#': 8, ab: 8, a: 9, 'a#': 10, bb: 10, b: 11 };
  function freq(n) {
    if (typeof n === 'number') return n;
    var m = /^([a-g][#b]?)(-?\d)$/.exec(String(n).toLowerCase());
    if (!m) return 440;
    var midi = 12 * (parseInt(m[2], 10) + 1) + SEMI[m[1]];
    return 440 * Math.pow(2, (midi - 69) / 12);
  }

  // ---------- 乐器 ----------
  function out(bus, gain) { var g = ctx.createGain(); g.gain.value = gain === undefined ? 1 : gain; g.connect(bus || busMusic); return g; }
  function env(g, t, a, d, s, r, sus, peak) {
    g.gain.cancelScheduledValues(t);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(peak, t + a);
    g.gain.exponentialRampToValueAtTime(Math.max(0.0002, peak * (sus === undefined ? 0.55 : sus)), t + a + d);
    if (r) g.gain.exponentialRampToValueAtTime(0.0001, t + a + d + r);
  }
  function piano(f, t, dur, vel) {
    var g = out(busMusic, 0); g.gain.value = vel === undefined ? 0.5 : vel;
    var a = Math.min(0.012, dur * 0.1), d = Math.max(0.25, dur * 0.8), r = Math.max(0.5, dur * 1.6);
    env(g, t, a, d, 0.35, r, 0.35, 0.5);
    var o1 = ctx.createOscillator(); o1.type = 'triangle'; o1.frequency.value = f;
    var o2 = ctx.createOscillator(); o2.type = 'sine'; o2.frequency.value = f * 2.005;
    var o3 = ctx.createOscillator(); o3.type = 'sine'; o3.frequency.value = f * 3.01;
    var g2 = ctx.createGain(); g2.gain.value = 0.22; var g3 = ctx.createGain(); g3.gain.value = 0.1;
    var lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 2600 + Math.min(2400, 300 / a);
    o1.connect(g); o2.connect(g2); g2.connect(g); o3.connect(g3); g3.connect(g); g.connect(lp); lp.connect(out(busMusic, 1));
    [o1, o2, o3].forEach(function (o) { o.start(t); o.stop(t + a + d + r + 0.1); });
  }
  function clarinet(f, t, dur, vel) {
    var g = out(busMusic, 0); g.gain.value = vel === undefined ? 0.34 : vel;
    var a = 0.09, d = dur, r = 0.35;
    env(g, t, a, d, 0.8, r, 0.85, 0.42);
    var o = ctx.createOscillator(); o.type = 'sawtooth'; o.frequency.value = f;
    var lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 1200; lp.Q.value = 6;
    var lfo = ctx.createOscillator(); lfo.frequency.value = 5.2;
    var lg = ctx.createGain(); lg.gain.value = f * 0.004; lfo.connect(lg); lg.connect(o.frequency);
    o.connect(lp); lp.connect(g); g.connect(out(busMusic, 1));
    o.start(t); lfo.start(t); o.stop(t + a + d + r); lfo.stop(t + a + d + r);
  }
  function pluck(f, t, dur, vel) {
    var g = out(busMusic, 0); g.gain.value = vel === undefined ? 0.36 : vel;
    env(g, t, 0.004, Math.max(0.2, dur * 0.7), 0.35, 0.4, 0.3, 0.45);
    var o = ctx.createOscillator(); o.type = 'triangle'; o.frequency.value = f;
    var o2 = ctx.createOscillator(); o2.type = 'sine'; o2.frequency.value = f * 2;
    var lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 3800;
    o.connect(g); var g2 = ctx.createGain(); g2.gain.value = 0.3; o2.connect(g2); g2.connect(g);
    g.connect(lp); lp.connect(out(busMusic, 1));
    o.start(t); o2.start(t); o.stop(t + dur + 0.4); o2.stop(t + dur + 0.4);
  }
  function bell(f, t, dur, vel) {
    var g = out(busMusic, 0); g.gain.value = vel === undefined ? 0.24 : vel;
    env(g, t, 0.006, dur, 0.25, 0.9, 0.2, 0.3);
    [1, 2.76, 5.4].forEach(function (m, i) {
      var o = ctx.createOscillator(); o.type = 'sine'; o.frequency.value = f * m;
      var gg = ctx.createGain(); gg.gain.value = [1, 0.35, 0.12][i];
      o.connect(gg); gg.connect(g); o.start(t); o.stop(t + dur + 1);
    });
    g.connect(out(busMusic, 1));
  }
  function pad(f, t, dur, vel) {
    var g = out(busMusic, 0); g.gain.value = vel === undefined ? 0.12 : vel;
    env(g, t, 0.5, dur, 0.7, 1.2, 0.8, 0.16);
    [1, 1.005, 0.5].forEach(function (m, i) {
      var o = ctx.createOscillator(); o.type = i === 2 ? 'triangle' : 'sawtooth'; o.frequency.value = f * m;
      var lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 900;
      o.connect(lp); lp.connect(g); o.start(t); o.stop(t + dur + 1.4);
    });
    g.connect(out(busMusic, 1));
  }
  function bass(f, t, dur, vel) {
    var g = out(busMusic, 0); g.gain.value = vel === undefined ? 0.22 : vel;
    env(g, t, 0.02, dur, 0.5, 0.3, 0.5, 0.28);
    var o = ctx.createOscillator(); o.type = 'sine'; o.frequency.value = f;
    var o2 = ctx.createOscillator(); o2.type = 'triangle'; o2.frequency.value = f * 2;
    var g2 = ctx.createGain(); g2.gain.value = 0.18;
    o.connect(g); o2.connect(g2); g2.connect(g);
    g.connect(out(busMusic, 1));
    o.start(t); o2.start(t); o.stop(t + dur + 0.5); o2.stop(t + dur + 0.5);
  }
  function noise(t, dur, filt, q, vel, type) {
    var s = ctx.createBufferSource(); s.buffer = noiseBuf; s.loop = true;
    s.playbackRate.value = 1 + (Math.random() - 0.5) * 0.06;
    var bp = ctx.createBiquadFilter(); bp.type = type || 'bandpass'; bp.frequency.value = filt; bp.Q.value = q || 1;
    var g = out(busMusic, 0); g.gain.value = vel === undefined ? 0.12 : vel;
    env(g, t, 0.01, dur, 0.5, 0.25, 0.6, 0.14);
    s.connect(bp); bp.connect(g); g.connect(out(busMusic, 1));
    s.start(t); s.stop(t + dur + 0.5);
  }
  // 磁带嘶声（循环）
  var hissNode = null;
  function hiss(on, vol) {
    if (!ready) return;
    if (on && !hissNode) {
      var s = ctx.createBufferSource(); s.buffer = noiseBuf; s.loop = true;
      var hp = ctx.createBiquadFilter(); hp.type = 'highpass'; hp.frequency.value = 2600;
      var lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 7200;
      var g = ctx.createGain(); g.gain.value = 0;
      var lfo = ctx.createOscillator(); lfo.frequency.value = 0.7;
      var lg = ctx.createGain(); lg.gain.value = 0.4; lfo.connect(lg); lg.connect(g.gain);
      s.connect(hp); hp.connect(lp); lp.connect(g); g.connect(out(busSfx, 1));
      s.start(); lfo.start();
      hissNode = { s: s, g: g, lfo: lfo };
      g.gain.linearRampToValueAtTime(vol === undefined ? 0.05 : vol, ctx.currentTime + 0.6);
    } else if (!on && hissNode) {
      try {
        hissNode.g.gain.cancelScheduledValues(ctx.currentTime);
        hissNode.g.gain.linearRampToValueAtTime(0, ctx.currentTime + 0.5);
        hissNode.s.stop(ctx.currentTime + 0.7); hissNode.lfo.stop(ctx.currentTime + 0.7);
      } catch (e) { }
      hissNode = null;
    }
  }

  /* =========================================================
   *  曲目（16 分音符网格，4/4）
   * ========================================================= */
  // 记谱小助手：'c4' 等；'-' 延音 ；'.' 休止
  var TRACKS = {
    // 1. 金线 —— 主题曲（钢琴 + 单簧管 + 弦垫）
    gold: {
      bpm: 68, len: 64, base: 0,
      maps: {
        lead: ['.', '.', '.', '.', 'e5', '.', '.', '.', 'd5', '.', '.', '.', 'c5', '.', '.', '.',
          'b4', '.', '.', '.', '.', '.', '.', '.', 'a4', '.', '.', '.', 'c5', '.', '.', '.',
          'e5', '.', '.', '.', '.', '.', '.', '.', 'g5', '.', '.', '.', 'e5', '.', '.', '.',
          'd5', '.', '.', '.', '.', '.', '.', '.', 'c5', '.', '.', '.', '.', '.', '.', '.'],
        arp: ['e4', '.', 'g4', '.', 'b4', '.', 'g4', '.', 'd4', '.', 'f#4', '.', 'a4', '.', 'f#4', '.',
          'g3', '.', 'b3', '.', 'd4', '.', 'b3', '.', 'a3', '.', 'c4', '.', 'e4', '.', 'c4', '.',
          'e4', '.', 'g4', '.', 'b4', '.', 'g4', '.', 'c4', '.', 'e4', '.', 'g4', '.', 'e4', '.',
          'd4', '.', 'f#4', '.', 'a4', '.', 'f#4', '.', 'e4', '.', 'g4', '.', 'b4', '.', 'g4', '.'],
        bass: ['e2', '.', '.', '.', '.', '.', '.', '.', 'd2', '.', '.', '.', '.', '.', '.', '.',
          'g2', '.', '.', '.', '.', '.', '.', '.', 'a2', '.', '.', '.', '.', '.', '.', '.',
          'e2', '.', '.', '.', '.', '.', '.', '.', 'c2', '.', '.', '.', '.', '.', '.', '.',
          'd2', '.', '.', '.', '.', '.', '.', '.', 'e2', '.', '.', '.', '.', '.', '.', '.'],
        clar: ['.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.',
          '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.',
          'b4', '.', '.', '.', '.', '.', '.', '.', 'c5', '.', '.', '.', '.', '.', '.', '.',
          '.', '.', '.', '.', '.', '.', '.', '.', 'a4', '.', '.', '.', '.', '.', '.', '.'],
        pad: ['.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.',
          '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.',
          '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.',
          '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.']
      },
      padChords: [[0, 16, ['e3', 'b3', 'g4']], [16, 16, ['g3', 'd4', 'b4']], [32, 16, ['c3', 'g3', 'e4']], [48, 16, ['d3', 'a3', 'f#4']]]
    },
    // 2. 四楼的斜光 —— 日常（木吉他拨奏 + 钢片琴）
    sun: {
      bpm: 104, len: 64,
      maps: {
        arp: ['c4', 'e4', 'g4', 'e4', 'a3', 'c4', 'e4', 'c4', 'f3', 'a3', 'c4', 'a3', 'g3', 'b3', 'd4', 'b3',
          'c4', 'e4', 'g4', 'e4', 'a3', 'c4', 'e4', 'c4', 'f3', 'a3', 'c4', 'a3', 'g3', 'b3', 'd4', 'g4',
          'a3', 'c4', 'e4', 'c4', 'f3', 'a3', 'c4', 'a3', 'g3', 'b3', 'd4', 'b3', 'c4', 'e4', 'g4', 'e4',
          'd4', 'f4', 'a4', 'f4', 'c4', 'e4', 'g4', 'e4', 'g3', 'b3', 'd4', 'g4', 'c4', 'e4', 'g4', 'c5'],
        bass: ['c2', '.', 'g2', '.', 'a2', '.', 'e2', '.', 'f2', '.', 'c3', '.', 'g2', '.', 'd3', '.',
          'c2', '.', 'g2', '.', 'a2', '.', 'e2', '.', 'f2', '.', 'c3', '.', 'g2', '.', 'd3', '.',
          'a2', '.', 'e3', '.', 'f2', '.', 'c3', '.', 'g2', '.', 'd3', '.', 'c3', '.', 'g3', '.',
          'd3', '.', 'a3', '.', 'c3', '.', 'g3', '.', 'g2', '.', 'd3', '.', 'c3', '.', 'g3', '.'],
        bell: ['.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.',
          'e5', '.', '.', '.', 'c5', '.', '.', '.', 'a4', '.', '.', '.', 'b4', '.', '.', '.',
          '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.',
          'g5', '.', '.', '.', '.', '.', '.', '.', 'a4', '.', '.', '.', '.', '.', '.', '.'],
        lead: ['.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.',
          '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.',
          'c5', '.', 'b4', '.', 'a4', '.', '.', '.', 'g4', '.', 'a4', '.', 'b4', '.', '.', '.',
          '.', '.', '.', '.', 'a4', '.', 'g4', '.', '.', '.', '.', '.', '.', '.', '.', '.']
      }
    },
    // 3. 磁头与棉签 —— 修复（低音拨奏 + 磁带嘶声 + 电子脉冲）
    fix: {
      bpm: 92, len: 64, hiss: true,
      maps: {
        bass: ['a1', '.', 'a1', '.', 'e2', '.', 'a1', '.', 'a1', '.', 'a1', '.', 'c2', '.', 'd2', '.',
          'a1', '.', 'a1', '.', 'e2', '.', 'a1', '.', 'f2', '.', 'f2', '.', 'e2', '.', 'd2', '.',
          'a1', '.', 'a1', '.', 'e2', '.', 'a1', '.', 'g2', '.', 'g2', '.', 'e2', '.', 'c2', '.',
          'd2', '.', 'd2', '.', 'a2', '.', 'd2', '.', 'e2', '.', 'e2', '.', 'e2', '.', 'e2', '.'],
        arp: ['.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.',
          'a3', '.', 'c4', '.', 'e4', '.', '.', '.', 'f3', '.', 'a3', '.', 'c4', '.', '.', '.',
          '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.',
          'g3', '.', 'b3', '.', 'd4', '.', '.', '.', 'e4', '.', '.', '.', 'a3', '.', '.', '.'],
        lead: ['.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.',
          '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.',
          'e4', '.', '.', '.', 'g4', '.', '.', '.', 'a4', '.', '.', '.', 'e4', '.', '.', '.',
          '.', '.', '.', '.', '.', '.', '.', '.', 'd4', '.', '.', '.', 'c4', '.', '.', '.']
      },
      clicks: [4, 12, 20, 28, 36, 44, 52, 60]
    },
    // 4. 高频先走的蝉 —— 回忆 / 独白（单簧管 + 环境声）
    cicada: {
      bpm: 60, len: 48, hiss: true,
      maps: {
        clar: ['e4', '.', '.', '.', 'g4', '.', '.', '.', 'a4', '.', '.', '.', '.', '.', '.', '.',
          'f4', '.', '.', '.', 'a4', '.', '.', '.', 'c5', '.', '.', '.', '.', '.', '.', '.',
          'g4', '.', '.', '.', 'b4', '.', '.', '.', 'a4', '.', '.', '.', '.', '.', '.', '.'],
        pad: ['.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.',
          '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.',
          '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.'],
        bass: ['a1', '.', '.', '.', '.', '.', '.', '.', 'f1', '.', '.', '.', '.', '.', '.', '.',
          'c2', '.', '.', '.', '.', '.', '.', '.', 'e2', '.', '.', '.', '.', '.', '.', '.',
          'a1', '.', '.', '.', '.', '.', '.', '.', 'g1', '.', '.', '.', 'e2', '.', '.', '.'],
        arp: ['.', '.', 'e4', '.', '.', '.', 'b3', '.', '.', '.', 'f4', '.', '.', '.', 'c4', '.',
          '.', '.', 'g4', '.', '.', '.', 'd4', '.', '.', '.', 'a4', '.', '.', '.', 'e4', '.',
          '.', '.', 'a3', '.', '.', '.', 'e4', '.', '.', '.', 'b3', '.', '.', '.', 'g4', '.']
      },
      padChords: [[0, 16, ['a2', 'e3', 'c4']], [16, 16, ['f2', 'c3', 'a3']], [32, 16, ['e2', 'b2', 'g3']]],
      cricket: true
    },
    // 5. 最后一次广播 —— 高潮（弦垫 + 电钢 + 弦乐）
    last: {
      bpm: 76, len: 64,
      maps: {
        lead: ['.', '.', '.', '.', '.', '.', '.', '.', 'e5', '.', '.', '.', 'f#5', '.', '.', '.',
          'a5', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', 'g5', '.', '.', '.',
          'f#5', '.', '.', '.', '.', '.', '.', '.', 'e5', '.', '.', '.', 'c#5', '.', '.', '.',
          'd5', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', 'e5', '.', '.', '.'],
        arp: ['a3', '.', 'c#4', '.', 'e4', '.', 'a4', '.', 'd4', '.', 'f#4', '.', 'a4', '.', 'd5', '.',
          'f#3', '.', 'a3', '.', 'c#4', '.', 'f#4', '.', 'd3', '.', 'f#3', '.', 'a3', '.', 'd4', '.',
          'a3', '.', 'c#4', '.', 'e4', '.', 'a4', '.', 'b3', '.', 'd4', '.', 'f#4', '.', 'b4', '.',
          'e3', '.', 'g#3', '.', 'b3', '.', 'e4', '.', 'a3', '.', 'c#4', '.', 'e4', '.', 'a4', '.'],
        bass: ['a1', '.', '.', '.', '.', '.', '.', '.', 'd2', '.', '.', '.', '.', '.', '.', '.',
          'f#1', '.', '.', '.', '.', '.', '.', '.', 'd2', '.', '.', '.', '.', '.', '.', '.',
          'a1', '.', '.', '.', '.', '.', '.', '.', 'b1', '.', '.', '.', '.', '.', '.', '.',
          'e2', '.', '.', '.', '.', '.', '.', '.', 'a1', '.', '.', '.', '.', '.', '.', '.'],
        pad: ['.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.',
          '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.',
          '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.',
          '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.']
      },
      padChords: [[0, 16, ['a2', 'e3', 'c#4']], [16, 16, ['d3', 'a3', 'f#4']], [32, 16, ['b2', 'f#3', 'd4']], [48, 16, ['a2', 'e3', 'c#4']]]
    }
  };

  var cur = null; // { name, t0, step, len, spb }
  var timer = null;

  function stepDur(track) { return 60 / track.bpm / 4; }

  function schedule(fromStep, toStep, t0, spb) {
    var tr = TRACKS[cur.name]; if (!tr) return;
    tr.name = cur.name;
    for (var i = fromStep; i < toStep; i++) {
      var s = i % tr.len, t = t0 + i * spb;
      var m = tr.maps;
      if (m.lead && m.lead[s] !== '.') note(m.lead[s], t, spb, tr, 'lead');
      if (m.arp && m.arp[s] !== '.') note(m.arp[s], t, spb, tr, 'arp');
      if (m.bass && m.bass[s] !== '.') bass(freq(m.bass[s]) / 2, t, spb * 4, 0.2);
      if (m.clar && m.clar[s] !== '.') clarinet(freq(m.clar[s]), t, spb * (tr.name === 'cicada' ? 6 : 3), 0.3);
      if (m.pad && m.pad[s] !== '.') pad(freq(m.pad[s]), t, spb * 8, 0.1);
      if (m.bell && m.bell[s] !== '.') bell(freq(m.bell[s]), t, spb * 4, 0.18);
      if (tr.clicks && tr.clicks.indexOf(s) >= 0) noise(t, 0.05, 1600, 6, 0.06);
      if (tr.cricket && s % 12 === 5) noise(t, 0.12, 4200, 12, 0.035, 'bandpass');
      if (tr.padChords) {
        for (var c = 0; c < tr.padChords.length; c++) {
          var pc = tr.padChords[c];
          if (pc[0] === s) for (var k = 0; k < pc[2].length; k++) pad(freq(pc[2][k]), t, spb * pc[1] * 0.9, 0.075);
        }
      }
    }
  }
  function note(n, t, spb, tr, role) {
    var f = freq(n);
    if (role === 'lead') {
      if (tr.name === 'gold' || tr.name === 'cicada') clarinet(f, t, spb * 6, 0.26);
      else if (tr.name === 'last') { piano(f, t, spb * 4, 0.42); pad(f * 2, t, spb * 6, 0.06); }
      else piano(f, t, spb * 3, 0.34);
    } else if (role === 'arp') {
      if (tr.name === 'sun') pluck(f, t, spb * 1.6, 0.28);
      else if (tr.name === 'last') piano(f, t, spb * 2.2, 0.3);
      else piano(f, t, spb * 2, 0.24);
    }
  }

  function play(name) {
    if (!ready && !init()) return;
    resume();
    if (cur && cur.name === name) return;
    stopMusic(0.4);
    var tr = TRACKS[name]; if (!tr) return;
    cur = { name: name, t0: ctx.currentTime + 0.12, step: 0 };
    if (tr.hiss) hiss(true, name === 'cicada' ? 0.035 : 0.05);
    var spb = stepDur(tr);
    var tick = function () {
      if (!cur) return;
      var elapsed = ctx.currentTime - cur.t0;
      var want = Math.floor(elapsed / spb) + 8;
      if (want > cur.step) { schedule(cur.step, want, cur.t0, spb); cur.step = want; }
    };
    tick();
    timer = setInterval(tick, 60);
  }
  function stopMusic(fade) {
    if (timer) { clearInterval(timer); timer = null; }
    if (cur) {
      var t = ctx.currentTime;
      try {
        busMusic.gain.cancelScheduledValues(t);
        busMusic.gain.setValueAtTime(busMusic.gain.value, t);
        busMusic.gain.linearRampToValueAtTime(0.0001, t + (fade || 0.5));
        setTimeout(function () { if (busMusic) busMusic.gain.value = 0.5; }, (fade || 0.5) * 1000 + 60);
      } catch (e) { }
    }
    cur = null;
  }
  function switchTo(name) { play(name); }
  function current() { return cur ? cur.name : null; }

  /* ---------- 音效 ---------- */
  function sfx(name) {
    if (!ready && !init()) return; resume();
    var t = now();
    if (name === 'click') { noise(t, 0.02, 2600, 3, 0.05); }
    else if (name === 'select') { pluckTone(880, t, 0.09, 0.16, busSfx); pluckTone(1320, t + 0.05, 0.12, 0.12, busSfx); }
    else if (name === 'back') { pluckTone(520, t, 0.12, 0.14, busSfx); }
    else if (name === 'page') { noise(t, 0.18, 1800, 0.8, 0.07, 'lowpass'); }
    else if (name === 'record') { pluckTone(1200, t, 0.05, 0.1, busSfx); noise(t + 0.05, 0.5, 3000, 1, 0.05); }
    else if (name === 'snow') { [1320, 1760, 2640].forEach(function (f, i) { bellTone(f, t + i * 0.18, 1.1, 0.1, busSfx); }); }
    else if (name === 'tape') { hiss(true, 0.06); setTimeout(function () { hiss(false); }, 1800); }
  }
  function pluckTone(f, t, dur, vel, bus) {
    var g = out(bus, 0); g.gain.value = vel;
    env(g, t, 0.004, dur, 0.3, dur * 3, 0.3, 0.4);
    var o = ctx.createOscillator(); o.type = 'triangle'; o.frequency.value = f;
    o.connect(g); g.connect(out(bus, 1)); o.start(t); o.stop(t + dur * 4);
  }
  function bellTone(f, t, dur, vel, bus) {
    var g = out(bus, 0); g.gain.value = vel;
    env(g, t, 0.004, dur, 0.2, dur, 0.2, 0.3);
    var o = ctx.createOscillator(); o.type = 'sine'; o.frequency.value = f;
    o.connect(g); g.connect(out(bus, 1)); o.start(t); o.stop(t + dur * 2.2);
  }

  return {
    init: init, resume: resume, play: play, stop: stopMusic, current: current,
    sfx: sfx, setMusicVol: setMusicVol, setSfxVol: setSfxVol, tracks: Object.keys(TRACKS)
  };
})();
